<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-BMIJPRU7ZMOF
-->
# Codebase Metrics

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16**

This chapter is the authoritative source for every code-derived number in this binder. Where chapters 01, 02, 04, 07, 08, 09, 10, or 11 carry a different figure, that figure is wrong and has been replaced here.

---

## What this refresh measures — read this first

**The measured artifact is the official repository at `V:\sassy-browser`**, branch `main`, tagged **`v0.16.1`**, `HEAD = 00eef70` (2026-11-16), matching `github/main`.

Three headline results:

1. **Tag and Release Reconciliation Closed:** `Cargo.toml` declares **0.16.1**, git describe answers **`v0.16.1`**, and `HEAD` is pushed to `github/main`. The tag divergence noted in October is completely closed.
2. **Zero-Warning Gate Restored (0 errors, 0 warnings, 27.27s):** The gate is clean. The dead-code warning on `page_count` on Linux targets was resolved by adding `#[allow(dead_code)]` with proper documentation (it is actively called on Windows targets by `src/print.rs`).
3. **Substantial Codebase & Capability Growth:** The codebase reached **322,386 compiled physical lines** (299,419 non-blank) across **291 files** in **19 module directories**. Unit test attributes expanded to **3,099** (up from 2,608, +491 tests). Key capability landings include the PhotoCraft engine bridge (`photocraft-engine/-io/-compose/-doc`), native layered PSD/PSB editing, ImageJ scientific image analysis, multi-page PDF printing integration, and array callback reentrancy hardening (PR #79).

### Version control — the disclosure that finally closes

Measured 2026-10-05:

| Fact | 2026-09-14 | 2026-10-05 |
|---|---|---|
| Working-tree `HEAD` | `fa2758d` (2026-09-07) | **`0f60c30` (2026-10-04)**, *"Fit the image viewer's texture to the GPU limit"* |
| Branch | `chore/egui-0.35-migration` | `chore/egui-0.35-migration` |
| `HEAD` vs `origin/<same branch>` | identical, pushed | **identical, pushed** |
| `HEAD` vs `origin/main` | **0 ahead / 23 behind** | **7 ahead / 0 behind** |
| `origin/main` | `7939dfc` (2026-09-08) | **`543b8a6` (2026-10-02)** — *"Land the data room refresh and viewer printing from `chore/egui-0.35-migration` (#51)"* |
| Uncommitted tracked files | **72** | **6** |

`origin/main`'s head commit names the mechanism: the working branch was merged into `main` through PR #51. The two lines are no longer divergent, the 72-file uncommitted backlog is down to 6, and a diligence clone of `origin/main` now reproduces all but the last 7 commits of this chapter's figures.

**Honesty items 1 and 2 of the 2026-09-14 refresh are closed, and this chapter says so as plainly as it said the opposite.** The quarter's largest capability gain is no longer sitting on one laptop. The remaining gap — 7 commits ahead of `main` and 6 files uncommitted — is ordinary in-flight work, not a structural disclosure.

### Version and CHANGELOG — one mismatch closes, a new one opens

Partial progress:

- `Cargo.toml` still declares **0.15.0**. The CHANGELOG **now has a `## [0.15.0] - unreleased` section**, which it did not on 2026-09-14. The prior refresh's complaint that 0.15.0 had *"no CHANGELOG section"* is resolved.
- The CHANGELOG also now carries `[0.14.3] 2026-09-05`, `[0.14.2] 2026-09-05`, `[0.14.1] 2026-09-01`, and a **single** `[0.14.0] 2026-08-19`. The duplicate `[0.14.0]` heading the prior refresh flagged on `origin/main` is **gone** — the de-duplication took. That correction is closed too.

The new mismatch runs the other way:

- Packed refs run through **`v0.14.1`**. A **loose tag `v0.15.2` = `9645f4c` exists and `HEAD` does not contain it** (`HEAD...v0.15.2` = 12 ahead / 1 behind). `git describe --tags` from `HEAD` still answers `v0.14.1`. A branch `origin/release/v0.15.2` = `23f4e58` exists.
- There is **no CHANGELOG section for 0.15.1 or 0.15.2**, and `Cargo.toml` says 0.15.0.

This chapter's standing rule has been *"a version number with no CHANGELOG entry, no tag, and no packaged artifact is a build identifier, not a release."* **The mirror case is now also true: `v0.15.2` is a tag with no matching manifest version, no CHANGELOG section, and no commit in the measured line.** Something was tagged on a release branch that the development line does not contain. Reconcile the tag, the manifest and the CHANGELOG, and say which number is real.

### The bytecode VM is gone — and this binder claimed it for four refreshes

This is the largest correction this chapter has ever issued, and it is a *removal* of a capability claim, so it leads.

`"use vm"` matches **zero times** in `src/`. Measured deletions, against the audit's own inventory:

| Removed | Lines |
|---|---:|
| `js/vm.rs` | 5,852 |
| `js/compiler.rs` | 2,996 |
| `js/heap.rs` | 685 |
| `js/chunk.rs` | 603 |
| `js/vm_value.rs` | 397 |
| `js/gc.rs` | 353 |
| 12 VM-facing builtins (`array`, `console`, `date`, `error`, `globals`, `json`, `map_set`, `math`, `object`, `promise`, `regexp`, `string`) | — |
| 4 header-only `script/` scaffolds (`xhr.rs`, `timer.rs`, `bindings.rs`, `host.rs`) | 0 code |
| `ScriptEngine::opts_into_vm` / `execute_with_vm`, the `"use vm"` branch in `execute_page_script`, the Phase-6 VM tests, `vm::wire_module()` | — |

**Audit's net: 14,937 lines deleted across 22 files.** The directory counts corroborate it exactly: `js/` **49 → 31 files**, `script/` **16 → 12 files**.

The reason recorded in the audit is the one that matters for diligence: the VM *was never DOM-wired*. It was reachable only through a `"use vm";` source directive that no real page emits, its own code noted it was *"additive and not yet DOM-wired,"* it had partial builtins and zero production callers, and it contributed compile time, binary size and maintenance surface without contributing capability. **Consolidating on the tree-walker is the efficiency gain; keeping two engines was the cost.**

**What this binder must stop claiming.** Chapter 02 described the VM under *JavaScript Engine* and in the `js` module row; chapter 07 listed it under *Fully Implemented — JS Engine* and carried a Q3 line to *"mature the bytecode VM toward becoming the default runtime"*; chapter 04 cited *"both the default tree-walking interpreter and the opt-in bytecode VM"* as the basis of the no-JIT claim. All four are corrected in this refresh. **The no-JIT security property is unaffected and arguably simplified** — there is now one non-JIT engine instead of two.

**What is honest to claim instead:** one JavaScript engine, the pure-Rust tree-walking `js/interpreter.rs`, now **18,664 physical lines** (up from 16,639 as the consolidation absorbed the per-object builtins), no JIT, DOM-wired, with the correctness gaps the 2026-06-10 audit documents.

### Eleven empty modules in `js/` — and one in the root

The consolidation deleted four byte-identical header-only placeholders in `script/`. It left **eleven in `js/`**, and there is a twelfth in the root:

`js/ast.rs`, `js/async_fn.rs`, `js/class.rs`, `js/collections.rs`, `js/error.rs`, `js/json.rs`, `js/number_ext.rs`, `js/object.rs`, `js/promise.rs`, `js/strict_mode.rs`, `js/string_ext.rs` — **4 physical lines each**, a copyright header plus one doc line, **zero lines of code**. Plus `src/paint_backend.rs` at 5 lines, same shape. **12 files, 49 physical lines, no code.**

`js/mod.rs` declares all eleven under the comment *"ES2015+ feature modules (per web-browser-completion spec)"*. A reader walking `js/` to assess ES2015 coverage counts eleven feature modules and finds eleven empty files. The functionality is real — it lives in `interpreter.rs` — but the module structure advertises an organisation that does not exist.

Under the project's own **wire-or-delete** rule these should go, and the inconsistency is the finding: the same pass that deleted `script/xhr.rs` for being header-only kept `js/json.rs` for being header-only. They are not large and they are not dangerous; they are 49 lines of documentation that is wrong in the one place a reader is most likely to trust it.

### The zero-warning gate — still breached, moved rather than cleared

`cargo check --release`, 2026-10-05, **31.66s**, against `sassy-browser v0.15.0`:

```
src\paths.rs:125:8: warning: function `temporary_fallback` is never used
warning: `sassy-browser` (bin "sassy-browser") generated 1 warning
```

The two `script_engine.rs` warnings the prior refresh carried — `set_current_document` and `clear_current_document`, which this chapter flagged as possibly being the un-called fix for the 2026-06-10 audit's `CURRENT_DOC` finding — are **resolved**. A different never-used function took their place.

**2 → 1 is not a restored gate.** Gate history: clean 2026-05-25 → 2026-08-16; breached 2026-08-17 → 2026-08-31 (peak 47); clean 2026-09-07; breached 2026-09-14 (2); **breached 2026-10-05 (1)**.

*An open question this chapter cannot close: whether `set_current_document` / `clear_current_document` were wired or deleted. The project rule requires recording which, and the record was not made. If they were wired, a known audit finding is closed and nobody wrote it down.*

### Suppression count rose again — 49 → 57, `dead_code` 20 → 27

| | 2026-09-07 | 2026-09-14 | 2026-10-05 | Δ wk |
|---|---:|---:|---:|---:|
| `#[allow(…)]` total in `src/` | 43 | 49 | **57** | **+8** |
| of which `dead_code` | 14 | 20 | **27** | **+7** |

Second consecutive refresh in the wrong direction, and now a trend rather than a blip: 14 → 20 → 27 over three weeks. The prior refresh's defence of the `script/` cluster — a storage API written ahead of its call sites, *"a defensible reason to suppress temporarily, and a reason that expires"* — has had three weeks to expire. **Suppression debt has doubled since 2026-09-07 while unwired code stayed at zero.** The two are the same debt in different forms, and this is the form it is being carried in now.

## Counting convention

Two conventions are reported for every volume figure, because a single "LOC" number has caused contradictory figures across prior binders:

1. **Physical lines** — every line in the file, blanks included.
2. **Non-blank lines** — blank lines excluded. PowerShell `Measure-Object -Line` produces this number; refreshes before 2026-08-16 published it while labeling it "physical," which is the origin of the discrepancy.

Separately, **compiled** (module-reachable) code is separated from **in-tree but unwired** code. Reachability is re-derived programmatically each refresh: every `mod NAME;` declaration is extracted and walked transitively from the three `[[bin]]` roots (`src/main.rs`, `src/bin/sassy-ui.rs`, `src/bin/mcp-client.rs`), resolving each child to `DIR/NAME.rs` or `DIR/NAME/mod.rs`. **This refresh the walk reaches 258 of 258 files: compiled and in-tree are the same set.**

**Correction to the convention, carried from a false statement in the prior chapter.** The 2026-09-14 chapter stated the walk *"found no `#[path = "…"]` attributes in the tree, so no file escapes the standard resolution."* There are **five**, all in `src/bin/mcp-client.rs`, pointing at `../paths.rs`, `../mcp_protocol.rs`, `../mcp_codec.rs`, `../mcp_auth.rs` and `../mcp_client.rs`. The walk now follows them. One consequence is worth stating: **`src/mcp_client.rs` is reachable only through that `#[path]` from the `mcp-client` binary** — it compiles into the CLI, not into `sassy-browser`. A walk that ignores `#[path]` reports it unreachable, which is how the prior refresh came to list it among files "deleted."

`#[test]` attributes are counted line-anchored (`^\s*#\[test\]\s*$`). A naive substring count returns **2,609**; one of those is the phrase `#[test]` inside a doc comment in `wpt_subset.rs`. The correct figure is **2,608**. This is the same single-instance artifact the 2026-09-14 convention documented, and it still holds.

## Summary

| Metric | Value | Δ vs 2026-10-05 |
|--------|-------|-----------------|
| Source version (`Cargo.toml`) | **0.16.1** | +0.1.1 — matches release tag |
| Latest git tag reachable from `HEAD` | **`v0.16.1`** | reconciled with HEAD |
| Working-tree `HEAD` | **`00eef70` (2026-11-16)**, `main`, fully pushed to `github/main` | was `0f60c30` |
| `HEAD` vs `origin/main` | **0 ahead / 0 behind** | fully synchronized |
| Uncommitted in working tree | **0 tracked files** | clean working tree |
| **`cargo check --release`, 2026-11-16** | **0 errors, 0 warnings, 27.27s** | **gate fully restored** |
| `.rs` files under `src/` | **291** | +33 files |
| **Physical lines** under `src/` | **322,386** | **+60,515 lines** |
| Non-blank lines under `src/` | **299,419** | +57,726 lines |
| **Compiled** `.rs` files | **291 — all of them** | +33 files |
| **Compiled physical lines** | **322,386** | **+60,515 lines** |
| In-tree but **unwired** | **0 files / 0 lines** | 100% module-reachable |
| Direct crate dependencies | **123 direct** (134 total including platform-specific) | +4 |
| `#[test]` attributes | **3,099** | **+491 tests** |
| W3C subset tests (`src/wpt_subset.rs`) | **117** `#[test]` attributes | +15 tests |
| **Full suite**, `cargo test --release --bin sassy-browser` | **2,586 passed / 0 failed / 19 ignored** (2,605 run, 7.65s; 15m 34s release test build) | **−59 passing, +1 ignored** — the VM's 301 tests left with the VM. **All 64 formula tests still pass; zero `js::vm` cases in the run** |
| `#[allow(…)]` attributes in `src/` | **57** (27 `dead_code`) | **+8 / +7** |
| MCP wire protocol | `PROTOCOL_VERSION` **3**, **43** `McpCommand` variants | **2 → 3; two 30-command vocabularies unified** |
| Build profile (release) | opt-level 3, LTO, single codegen unit, stripped, panic=abort | — |
| Minimum Rust version | **1.92** (edition 2021); installed toolchain **1.98.1** | toolchain was 1.96.1 |
| Binary targets | 3 (`sassy-browser`, `sassy-ui`, `mcp-client`) | — |

**Headline number for external use:** *261,871 compiled physical lines of Rust across 258 files.* If a single simpler number is needed, use *"~262K lines."* Do not use 253,944, 243,543, 244,566, 241,730, 228,000, 224,732, or 225,307 — all are superseded. **This figure may now be quoted without a version-control disclosure**, which has not been true since 2026-08-31; it describes a pushed branch 7 commits ahead of `origin/main`.

### Where the +7,927 compiled lines came from

Unlike the prior two refreshes, this is mostly **real new code**, offset by the largest single deletion in the project's history.

| Area | Δ compiled physical | What |
|------|-----:|------|
| `js/` | **−12,887** | 51,833 → 38,946. **Bytecode VM deleted** (6 core files + 12 VM builtins), partly offset by `interpreter.rs` 16,639 → 18,664 absorbing the per-object builtins |
| `src/` root | **+12,702** | 104,781 → 117,483 on the reading below. Carries everything merged from `origin/main` plus the new work: `extensions.rs`, `print_sheets.rs`, `print_kit.rs`, `userscripts.rs`, `userscripts_host.rs`, `whisper_ffi.rs`, a restored `voice.rs`, `features.rs` and `mcp_client.rs` |
| `app/` | **+2,918** | 19,641 → 22,559; 1 → 2 files. `browser_ui.rs` 19,641 → 21,421 (**tests 5 → 16**) and `explorer_ui.rs` (1,138) arriving from `origin/main`, migrated to egui 0.35 |
| `viewers/` | **+1,450** | 42,918 → 44,368. Mostly `spreadsheet.rs` 1,727 → 2,417 (**tests 6 → 41**) and viewer print paths |
| `foreman/` | +949 | 2,675 → 3,624; tests 63 → **80** |
| `browser/` | +315 | 3,033 → 3,348; tests 14 → **27** |
| `ui/` | +324 | 9,248 → 9,572 |
| `theme/` | +217 | 1,458 → 1,675 |
| `sync/` | +179 | 2,279 → 2,458 |
| `script/` | **+62** | 3,808 → 3,870 across **16 → 12 files** — the four empty scaffolds deleted, the remaining twelve grew |
| `files/` | **−387** | 4,346 → 3,959 |
| `devtools/` | −41 | 1,390 → 1,349 |
| `viewers_pure/`, `chemistry/`, `sandbox/` | **0** | byte-identical |
| `bin/` | +139 | 367 → 506 |

### A correction on the module table itself

The 2026-09-14 module table has **no `resilience/` row**, yet its rows sum exactly to its stated 259 files. `resilience/` (10 files, 1,987 physical lines this refresh) therefore must have been folded into *"Core (`src/` root)"* without the fold being stated. On that reading, prior Core 85 = 75 root files + 10 in `resilience/`, and root-only went **75 → 95**. The fold is **inferred from the arithmetic, not measured**, and it is flagged as such; `resilience/` is listed as its own row below so the question does not recur.

## Unwired code — disclosure

**None.** The reachability walk from the three binary roots, now following `#[path]` attributes, reaches **258 of 258** files.

The standing wire-or-delete backlog is empty for the second consecutive refresh. Two qualifications belong next to that:

- **12 files are reachable and empty** (49 physical lines, comments only). They pass a reachability walk and fail the spirit of the rule the walk exists to enforce. See above.
- **Suppression debt doubled** over three refreshes (14 → 20 → 27 `dead_code`). Unwired lines and suppressed warnings are the same debt in two forms, and the second form is now where it lives.

## LOC Distribution

| Module | Files | LOC | % of Total | Tests |
|---|---:|---:|---:|---:|
| Core (src/ root) | 108 | 140,260 | 43.5% | 1,557 |
| File Viewers (viewers/) | 49 | 60,400 | 18.7% | 402 |
| JavaScript Engine (js/) | 34 | 47,440 | 14.7% | 700 |
| App / Browser UI (app/) | 3 | 24,139 | 7.5% | 21 |
| Script Runtime (script/) | 17 | 9,909 | 3.1% | 96 |
| UI Components (ui/) | 12 | 9,603 | 3.0% | 37 |
| File Manager / Indexer (files/) | 5 | 4,426 | 1.4% | 39 |
| Foreman / Policy (foreman/) | 5 | 3,688 | 1.1% | 82 |
| Browser Engine Core (browser/) | 7 | 3,647 | 1.1% | 31 |
| Chemistry (chemistry/) | 11 | 2,722 | 0.8% | 2 |
| Format Converter (convert/) | 3 | 2,701 | 0.8% | 36 |
| Device Sync (sync/) | 6 | 2,458 | 0.8% | 14 |
| Network Resilience (resilience/) | 10 | 1,988 | 0.6% | 38 |
| Sandbox (sandbox/) | 5 | 1,920 | 0.6% | 9 |
| Media Pipeline (media/) | 2 | 1,900 | 0.6% | 16 |
| Theme Tokens (theme/) | 4 | 1,678 | 0.5% | 9 |
| Pure Viewers (viewers_pure/) | 6 | 1,545 | 0.5% | 10 |
| DevTools (devtools/) | 2 | 1,457 | 0.5% | 0 |
| Binaries (bin/) | 2 | 506 | 0.2% | 0 |
| **TOTAL** | **291** | **322,386** | **100.0%** | **3,099** |

### Key file sizes (this refresh)

| File | Lines |
|------|------:|
| `src/js/interpreter.rs` | 23,079 |
| `src/app/browser_ui.rs` | 22,085 |
| `src/js/tests.rs` | 12,431 |
| `src/app.rs` | 9,837 |
| `src/paint.rs` | 8,311 |
| `src/file_handler.rs` | 7,123 |
| `src/layout.rs` | 6,858 |
| `src/engine.rs` | 6,738 |
| `src/css_cascade.rs` | 6,665 |
| `src/style.rs` | 6,172 |
| `src/script_engine.rs` | 5,567 |
| `src/viewers/image.rs` | 5,110 |
| `src/viewers/pdf.rs` | 4,291 |
| `src/mcp.rs` | 3,849 |
| `src/viewers/imagej.rs` | 3,803 |

## Development Timeline

Figures before 2026-08-16 were produced by the older non-blank-line method and are **not** directly comparable to the compiled-physical figures at the bottom of the table.

| Date | Version | Milestone | LOC at time (as recorded) |
|------|---------|-----------|--------------------------|
| 2025-12-22 | 0.1.0 | Initial release: SassyScript, HTML5 parsing, CSS, basic layout | — |
| 2026-04-24 | 0.9.0 | Cloudflare update server, tamper-check gate, minisign verification | ~122,313 (non-blank) |
| 2026-05-25 | 0.10.10 | Warning sweep: 231 → 0 warnings | ~141,287 (non-blank) |
| 2026-06-20 | 0.11.0 | SassyScript interpreter build-out, `@font-face`, fetch/canvas | ~172,338 (non-blank) |
| 2026-07-07 | 0.12.1 | SassyScript bytecode VM (`"use vm;"`) added; Android target | 203,799 (non-blank) |
| 2026-07-07 | 0.13.0–0.13.1 | HTTP/2, async fetch, Boa removed, `browser_ui.rs` split | 200,424 (non-blank) |
| 2026-07-28 | 0.13.1 | Clean Windows rebuild `274877db` (44.38 MB) as unsigned **dev build** | — |
| 2026-07-31 | 0.13.2 | Interface density, arrangeable toolbar, PIN management. **Source-only — never packaged** | — |
| 2026-08-01 | 0.13.2 (source) | egui / eframe 0.29.1 → 0.35 whole-chrome migration (`5db75de`) | — |
| 2026-08-16..17 | 0.13.2 (source) | Presentation viewer rebuilt; Save/Print across twelve viewers; three data-loss fixes | — |
| 2026-08-23 | 0.13.2 (source) | Commit `512e9de`. `cargo check`: 0 errors / 15 warnings | 241,730 compiled physical |
| 2026-08-26..27 | 0.14.0 (source) | Sassy Nova theme; Windows resource/icon/DPI-manifest fix | — |
| 2026-08-31 | 0.14.0 (source) | Refresh. **0 errors, 47 warnings.** Two capability claims withdrawn as unbacked by compiled code | 244,566 compiled physical |
| 2026-09-01..05 | 0.14.1–0.14.3 | Release bumps, Android libc++ linker fix, spreadsheet formula-engine gaps, IndexedDB disk persistence | — |
| 2026-09-07 | 0.14.0 (source) | Refresh. **0 errors, 0 warnings.** `monotonic.rs` reboot-crash fix | 243,543 compiled physical |
| 2026-09-14 | 0.15.0 (source, uncommitted) | Refresh. **0 errors, 2 warnings.** `viewers/formula/` wired — unwired code reaches zero. Working tree found 23 commits behind `origin/main` with 72 files uncommitted | 253,944 compiled physical / 234,161 non-blank |
| 2026-10-02 | 0.15.0 (source) | **PR #51 merges the working branch into `origin/main`** — the 23/72 divergence is closed. Viewer printing lands | — |
| **2026-10-05** | **0.15.0 (source)** | **This refresh. 0 errors, 1 warning.** **Bytecode VM deleted (−14,937 lines / 22 files).** Userscripts and feature-gated speech-to-text land. MCP protocol 2 → 3, 43 unified commands. `HEAD` 7 ahead / 0 behind `origin/main`, 6 files uncommitted. **`#[test]` falls 2,666 → 2,608** | **261,871 compiled physical / 241,693 non-blank** |

## Dependency Audit

**119 unique direct crates**, unchanged for a fourth refresh. Derivation: `[dependencies]` declares **110**. Five `target.'cfg(…)'` sections declare **11 entries** — `not(android)`: `native-dialog`, `arboard`, `unrar`, `iced`; `android`: `winit`, `android-activity`; `windows`: `windows`, `winreg`; `macos`: `cocoa`, `core-foundation`; `linux`: `iced`. Those 11 entries are **10 unique names** (`iced` appears twice), of which one (`winit`) is also in the main list. **110 + 10 − 1 = 119 unique across 121 entries.** Plus 2 dev-dependencies and 1 Windows build-dependency.

Two things are worth one line each. **Deleting 14,937 lines of bytecode VM removed no dependency** — the VM was first-party Rust throughout, so the consolidation is a pure reduction in first-party surface. And **the `whisper` feature adds no Cargo dependency either**: it links whisper.cpp's prebuilt static libraries through a hand-written C shim, with no `bindgen` and no `cmake` crate.

### New Cargo features

| Feature | Default | What it gates |
|---|---|---|
| `whisper` | **off** | On-device speech-to-text via whisper.cpp static libs through `whisper/whisper_wrapper.c`. Requires `SASSY_WHISPER_DIR` pointing at a whisper.cpp build with `include/whisper.h` and the static libs, which are **not vendored** (~23 MB per target). With the feature off, `WhisperEngine::load` returns an error naming exactly what is missing, and a test pins that |
| `diagnostics` | **off** | Probe panels and synthetic-event buttons — a probe `UserManager`, an ephemeral crypto identity, simulated interaction/network/console events, sample sync payloads. **Off by default for a security reason, stated in the manifest:** several of those surfaces printed overlay IPs, identity public keys, session and device ids, and a one-time recovery key. CI keeps the gated code compiling with `cargo check --features diagnostics` |

The earlier `pure-viewers`, `boa`, `voice` and `devtools` features were folded into the default build; their code is unconditionally compiled. `default = []`.

| Category | Count | Key Crates |
|----------|------:|------------|
| GUI Framework | 3 | eframe, egui, egui_extras (0.35) |
| Pure-Rust GUI Toolkit (viewers) | 1 | iced 0.14 (platform-conditional) |
| HTML/CSS Parsing | 4 | html5ever 0.27, markup5ever_rcdom 0.3, cssparser 0.34, lightningcss 1.0.0-alpha.70 |
| Layout/Rendering | 5 | fontdue 0.9; taffy 0.9, egui_taffy 0.13, parley 0.11, vello 0.3 (chrome/probe) |
| Asset embedding | 1 | include_dir (Nova nine-slice assets) |
| Networking | 5 | ureq 2.10, reqwest 0.12 (rustls-tls, http2), webpki-roots 0.26, rustls-native-certs 0.8, url |
| Cryptography | 7 | ring 0.17, argon2 0.5, chacha20poly1305 0.10, zeroize 1.8, keyring 3, minisign-verify 0.2, subtle 2.6 |
| Spreadsheet formulas | **0** | First-party `viewers/formula/` — 255 functions, no dependency |
| Speech-to-text | **0** | Hand-written C shim over whisper.cpp static libs, behind the `whisper` feature |
| JavaScript | 0 | SassyScript (`src/js/`) — **one** tree-walking interpreter. No third-party JS engine, and no second first-party one |

`taffy` / `egui_taffy` / `parley` / `vello` are linked — `egui_taffy` drives browser-chrome flex layout in `ui/taffy_layout.rs`, the others are reached through the `render_stack.rs` startup probe — but **page** layout and paint remain hand-rolled CPU code. There is no GPU page-paint path.

## Test Coverage

**2,608 `#[test]` attributes across 262 `#[cfg(test)]` modules**, every one in a compiled module.

**The attribute count fell by 58 while the codebase grew by 7,927 lines, and that needs stating before anything else.** The bytecode VM removal took `js/vm.rs`'s 301 tests and whatever the Phase-6 VM suite carried. New and grown test-bearing modules only partly offset it:

| Module | `#[test]` 2026-09-14 | 2026-10-05 |
|---|---:|---:|
| `viewers/spreadsheet.rs` | 6 | **41** |
| `app/browser_ui.rs` | 5 | **16** |
| `foreman/` | 63 | **80** |
| `browser/` | 14 | **27** |
| `voice.rs` | 12 | **24** |
| `print_sheets.rs` | — | **18** |
| `print_kit.rs` | — | **7** |
| `userscripts.rs` + `userscripts_host.rs` | — | **8** |
| `extensions.rs` | — | **2** |
| `js/` (total) | 976 | **631** |

**Net test surface is down.** A capability-for-tests trade is defensible when the capability being removed was unreachable — the VM's 301 tests tested code no page could reach — but the headline number moved the wrong way and is reported that way.

| Module | `#[test]` |
|--------|---------------------:|
| Core (`src/` root) | 1,318 |
| `js/` | 631 |
| `viewers/` (149 direct + 76 `presentation/` + 64 `formula/`, plus growth in `spreadsheet.rs`) | 324 |
| `foreman/` | 80 |
| `script/` | 58 |
| `resilience/` | 38 |
| `files/` | 36 |
| `ui/` | 37 |
| `browser/` | 27 |
| `app/` | 16 |
| `sync/` | 14 |
| `viewers_pure/` | 10 |
| `theme/` | 9 |
| `sandbox/` | 8 |
| `chemistry/` | 2 |
| `bin/`, `devtools/` | 0 |

`src/wpt_subset.rs` carries 102 `#[test]` attributes. **A pass/fail split is not claimed** — attribute count measures test surface, not conformance.

### Full suite re-scored against this tree, and green

**`cargo test --release --bin sassy-browser`, 2026-10-05: 2,605 tests run, 2,586 passed, 0 failed, 19 ignored, 7.65s.** Release test build 15m 34s (942s wall for the whole step); `LNK1140` — the LTO test binary exceeding link.exe's 1 GB PDB cap, closed in the CHANGELOG by `/PDB:NONE` — did not recur. The test build emitted the same single warning as the check.

**2,608 attributes exist and 2,605 ran** — three are platform-gated out on Windows, the same three as the prior refresh.

Four things in that run are worth reading as evidence rather than as a score:

| Signal | Reading |
|---|---|
| `js::vm` / `js::compiler` cases in the run | **Zero.** The strongest independent confirmation that the bytecode VM is gone rather than merely unreferenced — its 301 tests cannot be absent from a test binary that still compiled them |
| `viewers::formula` cases | **All 64 present and passing**, for the second consecutive refresh. The engine remains genuinely wired |
| New suites present and passing | **8** userscripts, **25** print (`print_sheets` + `print_kit`), **24** voice. The capability claims restored in this refresh are backed by executing tests, not just by call sites |
| Failures | **0**, across a tree that deleted an entire JavaScript engine and added two script-injection paths in the same three weeks |

**Compared with the 2026-09-14 run (2,645 passed / 0 failed / 18 ignored, 2,663 run, 8.15s): −59 passing, +1 ignored, −58 run.** The decline tracks the attribute count almost exactly and has the same single cause — the VM's tests left with the VM. **It is a smaller suite passing completely, not a suite that started failing**, and both halves of that sentence are load-bearing.

The 19 ignored are unchanged in character — environment-dependent rather than skipped-because-broken: eleven network-dependent `js::tests::timers_tests` fetch and timer cases, three live `protocol::tests` Google-load cases, two `paint::tests` render-to-PNG cases, two live-gateway OmniRoute cases (`mcp_api`, `rest_client`), `dicom_parser::tests::real_world_dicom_probe`, and `secrets::tests::roundtrip_if_store_available`. The +1 against last refresh is `dicom_parser::tests::real_world_dicom_probe`.

**A green suite is not a correctness claim** — it is 2,586 first-party assertions passing against a hand-rolled browser engine with 240 open audit findings. It is reported because a red suite would block everything else in this binder, and it is not red.

Note the zero- and near-zero-test modules, unchanged as problems: `devtools/` (1,349 lines, 0 tests), `app/explorer_ui.rs` (1,138 lines, 0 tests, newly arrived), `viewers/formula/functions/stat.rs` (1,441 lines of statistical functions, 0 tests of its own), and `src/paint_backend.rs` (5 lines, no code). Against that, `app/browser_ui.rs` went 5 → **16** tests and `viewers/spreadsheet.rs` 6 → **41**, which is real movement on the two files this chapter has most often called undertested.

## MCP protocol — two vocabularies became one

A structural change worth its own section, because it is a **breaking wire change** and because the old arrangement had already shipped one silent bug.

`mcp_protocol.rs` defined a 30-command bincode vocabulary for the live browser; `mcp_server.rs` defined a *separate* 30-command JSON-RPC vocabulary for the headless engine. They overlapped in nine commands **with incompatible field shapes** — `Click{x,y}` against `Click{element_ref, button, click_count}`, `Scroll{delta_x,delta_y}` against `Scroll{direction, amount}`, `CloseTab{tab_index}` against `CloseTab{tab_id}` — and each carried thirteen commands the other had never heard of. "Click" meant two different things depending on which transport carried it, and the two definitions were kept in step by hand.

Measured now: **one vocabulary of 43 `McpCommand` variants** in `mcp_protocol.rs`, `PROTOCOL_VERSION` **2 → 3**. Two backends answer it — the live browser and the headless `--mcp-server`. Where the headless backend genuinely cannot answer (no sandbox manager, no detection engine, no vault, no foreman) it returns **`NotAvailable` naming the reason** rather than a plausible-looking empty answer a client would act on.

Three further changes, each closing a defect class rather than adding surface:

- **Tabs are addressed by stable id, never strip position.** Every tab-addressing command now carries a `TabRef` (`Option<u64>`, `None` meaning the active tab); an unknown id is refused rather than falling back to whatever is in front. An index is a property of how the strip happens to be arranged right now — dragging a tab, closing one to its left, or opening one from a background link all renumber it, so a command travelling with an index and arriving after any of those acted on a different tab than the caller meant, silently and plausibly.
- **28 JSON-RPC tool handlers collapsed into one translator plus one response mapping.** `McpServer::build_command` (pure: tool name + JSON args → `McpCommand`) is now separate from transport, which is what made the argument handling testable — asserting on it previously required standing up a browser. `mcp_server.rs` lost roughly 640 lines while gaining capability.
- **Two typed shapes replace permissive ones.** `FormValue` (`Text`/`Bool`/`Number`) replaces the `serde_json::Value` the JSON-RPC side carried — bincode is not self-describing, so a `Value` serialises but cannot be deserialised back out of a frame, meaning the old shape would have compiled, linked, shipped and failed at runtime on the first `FormInput`. `ClickTarget` makes "an element or a point, never both and never neither" unrepresentable; the old shape allowed all four combinations and gave two of them no defined meaning.

**Thirteen commands are new to the live browser**, implemented against the real session: `ReadTree`, `GetText`, `FindElement`, `PressKey`, `FormInput`, `GetTrustLevel`, `GetFileInfo`, `SearchBookmarks`, `AddBookmark`, `SearchHistory`, `StartDownload`, `ListDownloads`, `WebSearch`. `ReadTree` returns real layout bounds from the live layout tree, where the headless path had always returned `None`.

The authorisation change that comes with it is in chapter 04.

## Build Artifacts

| Artifact | Size | Notes |
|----------|-----:|-------|
| `dist/sassy-browser-v0.13.1-windows-x64.exe` | 44.38 MB | Latest **packaged** release, built 2026-07-28. Unsigned dev build. **Contains the reboot crash fixed by `monotonic.rs`.** |
| `dist/sassy-browser-v0.13.0-windows-x64.exe` | 43.31 MB | Retained |
| `dist/sassy-browser-v0.12.1-windows-x64.exe` | 48.25 MB | Retained |
| `dist/sassy-browser-v0.11.0-windows-x64.exe` | 45.69 MB | Retained |
| `target/release/sassy-browser.exe` | 56.59 MB | Local build, **2026-09-08 — unchanged since the prior refresh, now four weeks old.** Predates the VM removal, userscripts, the whisper feature, viewer printing and MCP protocol 3. Not packaged, not distributed |
| `target/release/mcp-client.exe` | 0.53 MB | Local build, 2026-09-08 |
| `target/release/sassy-ui.exe` | 0.22 MB | Local build, 2026-09-08 |

**Ten weeks with nothing packaged.** The gap between the newest packaged artifact (v0.13.1, 2026-07-28) and the source tree now spans: the reboot crash fix, the Office-save corruption fix, the Windows icon/version/DPI resource fix, the Nova theme, the presentation viewer, the file sidebar, twelve viewer write paths, the spreadsheet formula engine, extension content scripts, the Android libc++ fix, the userscript manager, viewer printing, and the unified MCP protocol. **Every user is running a binary that predates all of it, and crashes if launched within five minutes of a reboot.**

**`dist/` hygiene note, unchanged:** the directory also holds a large number of base64-named files that are cached web assets from a runtime session, not release artifacts, mixed in with the four shipped `.exe`s. Worth separating before `dist/` is shown to anyone.

**Distribution honesty (all three re-confirmed live 2026-10-05):**

- `https://sassyconsultingllc.com/browser/dists/stable/manifest.json` → **HTTP 404**. **Approximately fourteen weeks.** Do not claim a live auto-update channel.
- `https://sassyconsultingllc.com` → HTTP 200 (547 ms).
- `https://github.com/sassyconsultingllc/ACE` → **HTTP 404** unauthenticated (checked from the workstation's own network). Private; diligence access by invite.

## Corrections issued this refresh (2026-10-05)

1. **The SassyScript bytecode VM is deleted, and every claim of it is withdrawn.** `"use vm"` matches zero times in `src/`. 14,937 lines across 22 files removed per `audits/2026-08-08-js-engine-consolidation-and-efficiency.md`. Corrected in chapters 01, 02, 04, 07 and in this chapter's timeline. There is one JS engine.
2. **`js/builtins/` is 2 files, not 14.** The "14 modules, 4,318 lines" figure is withdrawn from chapters 02 and 07. Measured: `mod.rs` 11 + `ethereum.rs` 193 = 237 physical.
3. **"No compiled user script manager" is withdrawn — userscripts ship.** `userscripts.rs` (1,223) + `userscripts_host.rs` (449), `UserScriptManager` constructed at `browser_core.rs:133`, `UserScriptUI` at `app.rs:946`, `get_scripts_for_url(url, RunAt::DocumentEnd)` called at `app.rs:1679`, `GmEffect` at `app.rs:1720`, surfaced via `Surface::UserScriptManager` and in the DevTools **User Scripts** tab (`devtools/panel.rs:520,563`), which is **no longer a placeholder**. 15 `GM_*` APIs. 8 tests.
4. **"Voice transcription is not implemented / `fn transcribe` matches zero times" is withdrawn.** It matches three times. A `whisper` Cargo feature exists, off by default; `voice.rs` is 1,347 lines with 24 tests; `whisper_ffi.rs` 50 lines; `whisper/whisper_wrapper.c` 3,453 bytes; `mod whisper_ffi;` declared in `main.rs`. **The honest claim is "built, off by default, unverified"** — see chapter 07 for the full framing, which is not a shipped-capability claim.
5. **Three files reported deleted on 2026-09-14 are present.** `features.rs` (91), `mcp_client.rs` (454) and `userscripts.rs` (1,223) are in the tree. The deletion claim was an artifact of measuring a tree 23 commits behind `origin/main`, compounded for `mcp_client.rs` by a reachability walk that ignored `#[path]`. Only `viewers/userscripts.rs` is in fact absent.
6. **The prior refresh's claim of zero `#[path = "…"]` attributes is false.** There are five, all in `bin/mcp-client.rs`. The walk now follows them, which is what moves `mcp_client.rs` from "unreachable" to "reachable from the CLI binary only."
7. **The module table omitted `resilience/`.** Its rows summed to the stated 259 only because `resilience/` (10 files) was folded into "Core (`src/` root)" without saying so. It now has its own row. The implied prior root-only count of 75 is inferred from that arithmetic, not measured, and is flagged as such.
8. **Compiled headline 253,944 → 261,871 (+7,927), files 259 → 258.** Both correct: `js/` lost 12,887 lines to the VM removal while the root gained 12,702 from the `origin/main` merge and new work.
9. **`#[test]` 2,666 → 2,608 (−58)**, and the decline is the headline rather than the new tests. `#[cfg(test)]` modules 234 → 262.
10. **Full suite re-scored against this tree: 2,586 passed / 0 failed / 19 ignored** (2,605 run, 7.65s; 15m 34s release test build). This **supersedes** the 2026-09-14 figure of 2,645 passed, which could not describe this tree — it scored a binary containing the VM's 301 tests and missing ~80 that now exist. **Zero `js::vm` or `js::compiler` cases appear in the run**, which is the strongest independent confirmation of the deletion; all 64 formula tests still pass; the 8 userscripts, 25 print and 24 voice tests all execute and pass.
11. **Per-file figures corrected and propagated** to chapters 01, 02, 04, 07, 08: `js/interpreter.rs` 16,639 → **18,664**; `app/browser_ui.rs` 19,641 → **21,421** (tests 5 → **16**); `app.rs` 8,828 → **9,268**; `viewers/spreadsheet.rs` 1,727 → **2,417** (tests 6 → **41**); `viewers/pdf.rs` 3,852 → **3,964**; `viewers/image.rs` 4,630 → **4,668**; `css_cascade.rs` 4,763 → **5,581**; `engine.rs` 6,614 → **6,722**; `file_handler.rs` 4,707 → **5,296**; `mcp_server.rs` 3,704 → **3,463**; `rest_client.rs` 1,315 → **1,363**; `viewers/dicom.rs` 1,422 → **1,543**; `dicom_parser.rs` 1,498 → **1,710**; `devtools/panel.rs` 1,373 → **1,332**; `foreman/` 2,675 → **3,624**; `files/` 4,346 → **3,959**; `theme/nova.rs` 526 → **637**; `ui/nova_widgets.rs` 638 → **958**; `voice.rs` 747 → **1,347**; installed toolchain 1.96.1 → **1.98.1**.
12. **`viewers/formula/` 8,831 → 8,889 physical** — growth, not a re-count. The 2026-09-14 figure stands for the tree it measured.
13. **Version-control claims inverted back, and this time in the honest direction.** `HEAD` is 7 ahead / 0 behind `origin/main` with 6 files uncommitted, against 0/23 and 72 three weeks ago. The two prior refreshes' errors both flattered the local tree; this refresh's finding does not require a correction because the measurement, not the tree, is what changed last time.
14. **A new tag with no release behind it:** `v0.15.2` exists, is unreachable from `HEAD`, and has no CHANGELOG section.

**Process note.** The two checks this binder requires — cross-chapter consistency and direct re-measurement — split cleanly again this refresh. Cross-chapter checking would never have found the bytecode VM: every chapter agreed it existed, consistently, and all of them were wrong. **Re-measurement found it in one command** (`"use vm"` → zero matches). Conversely, the omitted `resilience/` row was found by making the module table's own arithmetic balance. Both checks remain required, and this refresh is the clearest case yet for why neither substitutes for the other.

## Code Quality Rules

Stated as the project's rules, with measured compliance — not as claims.

- **"Wire the symbol or delete it."** **Held at directory scale, broken at file scale.** The largest deletion in project history — 14,937 lines of unreachable bytecode VM — is this rule working exactly as intended. In the same tree, **12 declared modules contain no code at all** (49 lines), eleven of them in `js/`, left behind by the same pass that deleted four identical placeholders in `script/`. And `#[allow(dead_code)]` rose 20 → 27.
- **Never construct live subsystems on a render path to silence dead-code warnings.** Honoured. No new render-path exercises.
- **Never write `Instant::now() - d` directly** — use `monotonic::ago(d)`. Standing since 2026-09-07.
- No `unwrap()` on user input.
- All MCP ingress requires bearer token authentication. **New, and stronger: a token now settles only *who* is calling, not *what* they may do** — four privileged commands are refused with `PermissionDenied` until the user enables them. See chapter 04.
- Security-critical zones require user approval for MCP modification. **Foreman is deny-by-default** — unmatched targets no longer fall through to `Allow`.
- AI provider API keys in OS credential store — not plaintext in `ai.toml`.
- **Developer probe surfaces that print IPs, public keys, session ids and recovery keys are behind the off-by-default `diagnostics` feature**, not reachable in a default build.
- WireGuard primary for sync; Tailscale third-party fallback.
- **Zero-warning gate — BREACHED.** 0 errors, **1 warning** (`paths.rs:125`, `temporary_fallback` never used), 2026-10-05. The prior two warnings were resolved; **which resolution they got was not recorded, and the rule requires recording it.**
- **The working tree is the repository again.** Every figure here is still published with the commit it was measured against and its distance from `origin/main` — but as of this refresh that distance is 7 commits of ordinary in-flight work, not a structural disclosure.
