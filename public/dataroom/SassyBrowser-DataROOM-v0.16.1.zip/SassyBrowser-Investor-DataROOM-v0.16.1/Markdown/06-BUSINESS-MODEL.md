<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-A2CO6OQBKMUP
-->
# Business Model & Financials

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16** (no new financial data this refresh. The Print-to-PDF soft-gate remains removed so free-tier export matches the table below. **Real Pro billing is still not in the tree.** Two claims this chapter recorded as withdrawn are now **restored in source** — a userscript manager, wired with a 15-API `GM_*` surface, and speech-to-text behind an off-by-default feature — and like the formula engine before them, **both land on the *free* side of every tier line by default, because there is still no entitlement mechanism capable of putting them anywhere else.** See the note below the tier table.)

---

## Current Stage

Pre-revenue, pre-seed. Seeking $800K SAFE note for 24-month runway.

## Revenue Pathways (12-18 months post-funding)

### 1. Freemium Desktop Application
- **Free tier:** Core browser, all file viewers, ad blocker, password vault (local only)
- **Pro tier ($4.99/month):** Cloud sync across devices, advanced AI features (multi-provider), team password vault, priority update channel
- **Target:** 100K free users, 5% conversion = 5,000 paying users = $300K ARR

**Print-to-PDF gate resolved (2026-09-07).** The local Unlock-Pro soft-gate was removed so Save-as-PDF matches the free tier above. That closes the code/docs disagreement introduced in `f1d93b3`. **There is still no payment integration in the codebase** — Pro cloud sync / AI / team vault remain modeled revenue, not a pipeline. Future paid features need a real entitlement system, not a plaintext `features.json`. *(Correction, 2026-10-05: this chapter and chapter 07 recorded `src/features.rs` as deleted. **It is present, 91 lines** — the deletion claim was an artifact of measuring a tree 23 commits behind `origin/main`. The gate is gone and PDF export is free; the scaffold file remains, and it was never an entitlement system.)*

**Two restored capabilities land free by default (2026-10-05).** The userscript manager and feature-gated speech-to-text both sit on the free side of every tier line, for the same reason the formula engine does: there is no mechanism to put them elsewhere. Neither is a plausible paid line in its current state in any case — the userscript manager is unreviewed and has never run in a packaged binary, and speech-to-text cannot be built without assembling ~23 MB of unvendored upstream static libraries per target. **Neither should appear in a pricing conversation until it ships.**

**The formula engine and the tier line (2026-09-14).** The 255-function spreadsheet engine is the strongest displacement capability in the product — it is the point at which "opens your spreadsheets" becomes "recalculates your spreadsheets," which is what a Microsoft 365 seat is actually bought for. It currently sits on the **free** side of every tier line, because there is no entitlement mechanism capable of putting it anywhere else.

Two things follow, and they pull in opposite directions:

- **Against gating it:** the free tier is the acquisition engine for the academic and privacy segments in chapter 05, and a formula engine is exactly the kind of capability that gets a browser installed. Gating it would blunt the one displacement story that now has code behind it. The Print-to-PDF gate was removed for essentially this reason a week ago, and removing it was right.
- **For deciding deliberately:** the current placement is not a decision, it is the absence of one. `features.rs` was deleted because it was a plaintext unlock file pretending to be a licence, and nothing replaced it. **Every capability in this product is free by default until an entitlement system exists**, and the list of capabilities that could plausibly carry a price is growing faster than the mechanism to charge for it.

**This does not change any number in this chapter.** Pro revenue was already modeled rather than booked, and remains so. It does sharpen the sequencing: the entitlement decision is now gating a real asset rather than a hypothetical one, and "decide what Pro means" has moved up the roadmap accordingly (chapter 07, Q3 block). **Do not model spreadsheet functionality as paid revenue in any forecast until both the entitlement system and the Excel-compatibility verification exist.**

### 2. Institutional Licensing
- **Academic site license:** $10-50/seat/year for universities and research labs
- **Enterprise license:** $100/seat/year for compliance-focused organizations (includes policy engine, audit logging)
- **Target:** 20 institutions, avg 500 seats = 10,000 seats at $30/seat = $300K ARR

### 3. Cloudflare Workers API
- File conversion and document processing API (the viewer pipeline exposed as a service)
- Pay-per-use pricing: $0.01/conversion for standard formats, $0.05 for scientific/medical
- **Target:** Developer API market, $50K ARR in year 1

### 4. Security Consulting
- Penetration testing and security advisory leveraging the browser's detection engine
- B2B service offered by Sassy Consulting LLC
- **Target:** $100K ARR from 5-10 retainer clients

### Combined Year 1 Revenue Target: $750K ARR

## Use of Funds ($800K SAFE)

| Allocation | Amount | Purpose |
|------------|--------|---------|
| Engineering | $360K | 1 senior Rust engineer (24-month salary + benefits), contractor design support |
| Infrastructure | $55K | Build/signing servers, CDN, Cloudflare Workers scaling, CI/CD |
| Legal & Compliance | $45K | IP protection, open-source licensing strategy, GDPR/CCPA compliance |
| Marketing & Launch | $120K | Product Hunt launch, developer community outreach, conference presence |
| Operating Reserve | $220K | 24-month runway for founder salary + overhead |

## Unit Economics (Pro tier at scale)

| Metric | Value |
|--------|-------|
| Monthly subscription | $4.99 |
| Annual LTV (assuming 18-month avg retention) | $89.82 |
| Infrastructure cost per user/month | ~$0.15 (Cloudflare Workers + R2) |
| Gross margin | ~97% |
| Target CAC | <$20 (organic + community-driven) |
| LTV:CAC ratio | >4.5x |

## Key Assumptions

- Browser is free forever -- revenue comes from Pro features, not the core product
- Scientific viewers are the wedge for institutional sales (ChemDraw/PACS replacement value is immediately quantifiable)
- MCP integration creates a unique developer-market moat (no other browser is natively AI-drivable)
- Rust community provides early organic distribution at near-zero CAC
