<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-HIWRAQAMOR52
-->
# Technical Architecture

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16**

> **Build state:** `cargo check --release` at head of working tree as of 2026-11-16 — **0 errors, 0 warnings, 27.27s**. The zero-warning gate is **fully restored and clean**. **Full suite green: 3,099 test attributes / 0 failed / 19 ignored**.
>
> **Version control:** working-tree `HEAD` is `00eef70` (2026-11-16) on `main`, tagged **`v0.16.1`**, and **fully pushed to `github/main`** (PR #78 release bump, PR #79 array callback reentrancy fix). The tag mismatch disclosure is closed.
>
> **Structural evolution in v0.16.1:** Linked PhotoCraft engine crates (`photocraft-engine/-io/-compose/-doc`), enabling full layered PSD/PSB editing, ImageJ scientific analysis (16 auto-thresholds, watershed, FFT, colocalization), and 45 advanced raster filters. Completed PDF page count and XPS print spooling integration.

---

## Stack Overview

Sassy Browser is a from-scratch, pure-Rust browser. No Chromium. No Blink. No V8. No WebKit. The entire stack -- UI, HTML parsing, CSS cascade, layout, rendering, JavaScript engine, networking, cryptography -- is Rust crates with no C/C++ browser engine dependency.

### Core Pipeline

User input enters at `BrowserApp` (the egui render loop, tab manager, and settings UI). `BrowserApp` dispatches to four orthogonal subsystems: the rendering engine, the universal file handler, the scripting runtime, and the MCP server.

```{=latex}
\begin{center}
\begin{tikzpicture}[
  >=Stealth,
  font=\small\sffamily,
  every node/.style={align=center},
  topbox/.style={rounded corners=3pt, draw=accent, line width=0.7pt,
                 fill=accent, text=white, minimum width=58mm, minimum height=11mm,
                 inner sep=4pt, font=\sffamily\bfseries},
  subbox/.style={rounded corners=2.5pt, draw=accent, line width=0.5pt,
                 fill=mist, text=ink, minimum width=34mm, minimum height=11mm,
                 inner sep=3pt, font=\sffamily\bfseries\small},
  inputlabel/.style={font=\small\sffamily\itshape, text=whisper},
  modlist/.style={font=\footnotesize\sffamily, text=ink, align=center,
                  anchor=north, inner sep=2pt, text width=34mm},
  modroot/.style={font=\scriptsize\ttfamily, text=whisper, align=center,
                  anchor=north, inner sep=1pt},
  arr/.style={->, draw=accent, line width=0.6pt},
  branch/.style={->, draw=accent!75, line width=0.5pt}
]

\node[inputlabel] (input) {User input};
\node[topbox, below=3mm of input] (app) {BrowserApp\\[1pt]{\footnotesize\textnormal{\ttfamily app.rs}}};
\draw[arr] (input) -- (app);

\node[subbox, below=14mm of app, xshift=-57mm] (engine) {Browser\\Engine};
\node[subbox, below=14mm of app, xshift=-19mm] (file)   {File\\Handler};
\node[subbox, below=14mm of app, xshift=19mm]  (script) {Script\\Engine};
\node[subbox, below=14mm of app, xshift=57mm]  (mcp)    {MCP\\Server};

\coordinate (bus) at ($(app.south)+(0,-6mm)$);
\draw[branch] (app.south) -- (bus);
\draw[branch] (bus) -| (engine.north);
\draw[branch] (bus) -| (file.north);
\draw[branch] (bus) -| (script.north);
\draw[branch] (bus) -| (mcp.north);

\node[modroot, below=0.5mm of engine] (engineroot) {engine.rs};
\node[modroot, below=0.5mm of file]   (fileroot)   {file\_handler.rs};
\node[modroot, below=0.5mm of script] (scriptroot) {script\_engine.rs};
\node[modroot, below=0.5mm of mcp]    (mcproot)    {mcp\_server.rs};

\node[modlist, below=1.5mm of engineroot] {HttpClient\\HtmlParser\\CssCascade\\LayoutEngine\\Renderer};
\node[modlist, below=1.5mm of fileroot]   {Viewers\\\textit{(200+ formats)}};
\node[modlist, below=1.5mm of scriptroot] {SassyScript};
\node[modlist, below=1.5mm of mcproot]    {stdio JSON-RPC\\WebSocket bincode\\Auth gate};

\end{tikzpicture}
\end{center}
```

The rendering engine integrates `html5ever` for HTML parsing and `cssparser` for CSS tokenizing. Page flex/grid/block layout and text shaping are **hand-rolled in pure Rust** (`layout.rs`). Painting is a **CPU software rasterizer** (`paint.rs`). **`taffy` / `parley` / `vello`** are linked via `render_stack.rs` (startup probe); **egui_taffy** drives browser chrome flex layout (`ui/taffy_layout.rs`). GPU page paint remains roadmap work. The MCP server runs auth-gated (ring constant-time verification) over stdio JSON-RPC for Claude Desktop and over a native bincode WebSocket protocol.

## Module Breakdown by LOC

Physical lines, blanks included. See Codebase Metrics for the counting convention. **This refresh, compiled and in-tree are the same set** — the reachability walk from the three binary roots, now following the five `#[path]` attributes in `bin/mcp-client.rs`, reaches all 258 files.

*A `resilience/` row has been added. The prior edition's table omitted it while its rows summed to the stated total, which means those 10 files were folded into `root (src/)` without the fold being stated. Chapter 03 records the correction.*

| Module | Files | Physical Lines | Description |
|--------|------:|---------------:|-------------|
| root (src/) | 95 | 117,483 | Core browser: engine, networking, crypto, identity, parsers, layout, paint, MCP, font_registry, extensions. Largest members: `app.rs` 9,268, `paint.rs` 7,287, `engine.rs` 6,722, `layout.rs` 5,750, `css_cascade.rs` 5,581, `file_handler.rs` 5,296, `script_engine.rs` 4,743. **New to the measured tree this refresh:** `extensions.rs` (522), `print_sheets.rs` (1,541), `print_kit.rs` (1,109), `userscripts.rs` (1,223), `userscripts_host.rs` (449), `whisper_ffi.rs` (50), and a restored `voice.rs` (1,347). `features.rs` and `mcp_client.rs`, reported deleted last refresh, are **present** — see Codebase Metrics correction 5 |
| viewers | 43 | 44,368 | File format viewers wired into `viewers/mod.rs` (PDF, DOCX, XLSX, PPTX/ODP, DICOM, chemical, STEP, IGES, 3MF, OpenSCAD, Parasolid, image, archive, etc.). Includes the 7-file `presentation/` directory (6,146) and the 15-file `formula/` spreadsheet engine (8,889). `spreadsheet.rs` grew 1,727 → 2,417 and its tests 6 → **41** |
| js | 31 | 38,946 | SassyScript JS engine + DOM bindings — **now a single engine.** The tree-walking `interpreter.rs` (18,664, up from 16,639 as it absorbed the per-object builtins) is the only execution path. Includes `tests.rs` (11,450) and a `builtins/` subdirectory of **2 files** (`mod.rs` 11, `ethereum.rs` 193). **The bytecode VM and twelve VM-facing builtins were deleted this refresh** (49 → 31 files, −12,887 lines). **11 of the 31 files are declared and empty** — 4 lines each, comments only |
| app | 2 | 22,559 | Main browser UI surface. `browser_ui.rs` 21,421 (**tests 5 → 16**) and `explorer_ui.rs` 1,138, which arrived from `origin/main` completing the egui 0.35 migration (**0 tests**) |
| ui | 12 | 9,572 | UI components, panels, dialogs, theme picker. `nova_widgets.rs` (958) — `clay_button`, `flat_icon_button`, `nova_frame`, `nova_bar`, `nova_progress` |
| files | 5 | 3,959 | File sidebar / Explorer-Finder replacement in the browser chrome: Tree / Details / Timeline views, filter query language, per-root view-edit permissions, optional SQLite whole-drive index. New Folder / Rename / two-click Delete gated on Edit roots. **Shrank 4,346 → 3,959; tests 39 → 36** |
| script | 12 | 3,870 | Script runtime (event loop, storage, history API, async fetch, canvas, defer/async script loading). **Four header-only scaffolds deleted** (`xhr.rs`, `timer.rs`, `bindings.rs`, `host.rs`) in the same pass that spared eleven identical files in `js/` |
| foreman | 5 | 3,624 | Self-awareness engine, policy, health scoring. Policy is deny-by-default. **Grew 2,675 → 3,624; tests 63 → 80** |
| browser | 7 | 3,348 | Browser chrome, tab management, bookmarks, history, downloads, tab groups, page context menu. **Tests 14 → 27** |
| chemistry | 11 | 2,724 | SMILES parser, 3D renderer, Gasteiger charges, NMR/IR. Byte-identical |
| sync | 6 | 2,458 | WireGuard / overlay-VPN device sync, family device registry, QR pairing |
| resilience | 10 | 1,987 | Error boundaries, journaling, locking, numeric and text guards, texture and thread resilience. 38 tests. **Newly broken out as its own row** |
| sandbox | 5 | 1,898 | 4-layer sandbox (network, render, content, download). Byte-identical |
| theme | 4 | 1,675 | Design tokens, palettes, fonts. `nova.rs` (637) — nine-slice chrome renderer; `tokens.rs` carries the three Nova presets and the `ChromeMode` switch |
| viewers_pure | 6 | 1,545 | Pure-Rust Iced-based viewers (audio, ebook, etc.). Byte-identical |
| devtools | 2 | 1,349 | Developer tools (Elements, Console, Network, Sources, Application, Security, User Scripts, REST Client). The Elements panel is populated — `DomNode::from_live` mirrors the live document and Inspect selects the right-clicked element. **The User Scripts tab is no longer a placeholder** — `panel.rs:520` takes a `&mut crate::userscripts::UserScriptUI` and renders it. Still **0 tests** |
| bin | 2 | 506 | Binary entry points (sassy-ui, mcp-client) |
| **TOTAL** | **258** | **261,871** | |
| *Not compiled* | **0** | **0** | *Second consecutive refresh with none. See Codebase Metrics.* |
| *Declared but empty* | **12** | **49** | *Comments only, zero code: 11 in `js/` plus `paint_backend.rs`. Reachable, and therefore invisible to the reachability walk.* |

### Nested subdirectories

| Path | Files | Physical | Wired? |
|------|------:|---------:|--------|
| `js/builtins/` | **2** | 237 | **Yes** — `pub mod builtins;` in `js/mod.rs`. **Reduced from 14 files this refresh.** `ethereum.rs` (193, the EIP-1193 provider) is the only builtin bound to the *interpreter* (`JsInterpreter`) and is registered from `script_engine.rs`; `mod.rs` (11) was trimmed to just it. The other twelve were `install(vm: &mut Vm)` — VM machinery — and went with the VM. *(The "14 modules, 4,318 lines" figure in every prior edition is withdrawn.)* |
| `viewers/presentation/` | 7 | 6,146 | **Yes** — `pub mod presentation;` in `viewers/mod.rs`. The sibling file `presentation.rs` was deleted, so the declaration resolves to this directory. *(The 2026-08-16 binder said this was unwired. That was wrong and is withdrawn.)* |
| `files/` (`filter`, `index`, `model`, `panel`) | 5 | 3,959 | **Yes** — `mod files;` in `main.rs`, consumed by `app.rs` and `browser_ui.rs` |
| `viewers/formula/` (+ `functions/`) | 15 | 8,889 | **Yes — wired 2026-09-14.** `pub mod formula;` at `viewers/mod.rs:28`, and called from `spreadsheet.rs`. *(Every edition before that recorded it as unwired. That is history, not a standing item.)* |
| `resilience/` | 10 | 1,987 | **Yes** — `mod resilience;` in `main.rs`. Previously folded into the root row without being stated |

### The formula engine — wired, and how that is known

A `mod` declaration proves a file compiles. It does not prove anything calls it, and this binder has been burned by exactly that distinction twice (the voice engine and the userscript drafts both compiled and were reached by nothing). So the claim is made on three independent signals, not one:

1. **Declared** — `pub mod formula;` at `viewers/mod.rs:28`.
2. **Called** — `viewers/spreadsheet.rs` lines 13, 14 and 235: `use super::formula::{self, CellResolver}`, `use super::formula::value::{CalcError, Value as FormulaValue}`, and `formula::evaluate(formula_body(formula), &self.resolver_on(spreadsheet, sheet))` on the live cell path.
3. **Corroborated by the compiler** — the prior refresh ran a probe that predicted roughly 200 `dead_code` warnings if `formula` were declared without being bridged. The whole-crate check now returns **two** warnings, neither in `formula/`. A declared-but-unused 8,831-line module cannot produce that result.

Corroborated a fourth way by volume: `spreadsheet.rs` fell **2,541 → 1,727** physical lines. The hand-rolled ~60-function evaluator was deleted, not parked alongside the new engine.

Architecturally the engine is a conventional four-stage pipeline — `lexer.rs` → `parser.rs` → `eval.rs` over a typed `value.rs` model, with the function library split across `functions/{math,stat,text,lookup,datetime,…}.rs` and dispatched through **255 named match arms**. `spreadsheet.rs` supplies a `CellResolver`, which is what lets unsaved cell edits be visible to every formula rather than only to the saved sheet. The engine carries a typed `CalcError`, so text, lookup, and date functions no longer have to degrade to `f64` to share a return type. **It adds no third-party dependency** — 255 spreadsheet functions of first-party Rust.

**What is still not claimed: Excel parity.** 255 named functions is not the ~500 of modern Excel. Array formulas, structured references, and cross-sheet references are unverified. The engine's 64 tests are concentrated in `formula/tests.rs`; `functions/stat.rs` is 1,441 lines with none of its own. No `.xlsx` round-trip against real workbooks has been performed.

**Movement this refresh:** `spreadsheet.rs` grew 1,727 → 2,417 physical lines and its own test count went **6 → 41**, which is the first substantial testing of the surface that calls the engine. `viewers/formula/` itself measured 8,889 physical, up 58 lines — growth, not a re-count.

Compiled volume rose **7,927 lines** against the prior binder, and unlike the last two refreshes most of it is real new code offset by a very large deletion: `js/` **lost 12,887 lines** to the bytecode-VM removal while the root **gained 12,702** from the `origin/main` merge and the new work (userscripts, printing, extensions, the whisper FFI, a restored `voice.rs`), `app/` gained 2,918 (`explorer_ui.rs` arriving plus 11 new `browser_ui.rs` tests), `viewers/` 1,450, `foreman/` 949, and `browser/` 315. `viewers_pure/`, `chemistry/` and `sandbox/` are byte-identical.

Direct deps are **119 unique** across 121 declaration entries: 110 in `[dependencies]`, plus 11 platform-conditional entries spanning 10 unique names (`iced` appears in two sections), of which `winit` also appears in the main list. See Codebase Metrics for the full derivation.

### Theming — Sassy Nova (v0.14.0)

The default chrome is a claymorphic theme built around a 3D icon set. Two properties are worth calling out architecturally rather than cosmetically:

- **The palette is measured from the artwork, not invented.** Canvas `#1B1A2C`, clay face `#8294B9`, lavender bezel `#D4CFEC`, cyan accent `#41CFE7`, violet `#4E59A5` reserved for AI and security affordances. Because the tokens derive from the assets, chrome and icons cannot drift apart as either changes.
- **`ChromeMode` decouples the art from the accessibility mode.** `Skinned` paints nine-slice clay bitmaps; `Flat` drops them for solid fills and hard borders. That switch is what makes `SassyNovaContrast` — a WCAG-AAA high-contrast preset — implementable without fighting the bitmap art, which is the usual failure mode for skinned UIs.

`theme/nova.rs` embeds 20 keyed RGBA assets via `include_dir!` and draws them as nine quads with unstretched corners, so clay buttons and panel frames stay crisp at any size or DPI. `hero.png` is deliberately excluded from texture upload — a 1152×1728 reference sheet the browser never draws, which would otherwise cost roughly 8 MB of VRAM. Clay bitmap art is spent only on primary CTAs and the AI button; toolbar and navigation controls stay flat with a hover fill and a cyan focus ring. `icons.rs` is the single resolution point deciding Nova raster vs. SVG per semantic name; Nova ships no forward-navigation art, so `forward` resolves to the `back` raster mirrored at draw time.

## Key Subsystems

### Networking & Identity
- Custom TLS fingerprint matching Chrome 132 ClientHello (JA3 match)
- Runtime-switchable User-Agent with automatic cookie jar wipe on identity change
- Defeats Cloudflare/Akamai/Imperva JA3 filters
- Native certificate store integration (rustls-native-certs) for enterprise proxy compatibility

### JavaScript Engine — one engine as of 2026-10-05

- SassyScript: custom pure-Rust **tree-walking interpreter** (`interpreter.rs`, **18,664** lines) operating on an `Rc<RefCell<>>` value graph. Broad surface (classes, generators, promises, typed arrays, DOM dispatch) but with known correctness gaps in core semantics tracked by the 2026-06-10 audit (see Security Posture) -- this is the active work area, not a finished engine
- **The bytecode VM has been deleted.** Prior editions of this chapter described `js/vm.rs` / `compiler.rs` / `chunk.rs` / `gc.rs` / `heap.rs` / `vm_value.rs` as a shipped, opt-in second execution path invoked by a leading `"use vm";` directive. **It is gone — 14,937 lines across 22 files, and `"use vm"` matches zero times in `src/`.** The reason, from `audits/2026-08-08-js-engine-consolidation-and-efficiency.md`: the VM was **never DOM-wired**. Its own code noted it was *"additive and not yet DOM-wired"*; it could not touch the page at all; it had partial builtins and zero production callers; and it was reachable only through a directive no real page emits. A bytecode VM is conceptually faster than a tree-walker, but an unfinished and unwired one contributes compile time, binary size and maintenance surface and nothing else. **Consolidating on the single DOM-wired engine is the efficiency gain.**
- Standard library: `js/builtins/` is now **2 files, 237 lines** — `ethereum.rs` (the EIP-1193 provider, the only builtin bound to `JsInterpreter`) plus `mod.rs`. The twelve per-object builtins were `install(vm: &mut Vm)` and went with the VM; their interpreter-side functionality lives in `interpreter.rs`, which is why it grew by ~2,000 lines. **The "14 modules, 4,318 lines" figure is withdrawn.**
- **Eleven declared modules in `js/` are empty** — `ast.rs`, `async_fn.rs`, `class.rs`, `collections.rs`, `error.rs`, `json.rs`, `number_ext.rs`, `object.rs`, `promise.rs`, `strict_mode.rs`, `string_ext.rs`: 4 lines each, a header and one doc line, zero code. `js/mod.rs` declares them under the comment *"ES2015+ feature modules (per web-browser-completion spec)"*. The features are real and live in `interpreter.rs`; the module layout advertises an organisation that does not exist, and the same consolidation deleted four byte-identical placeholders in `script/`. Under the project's wire-or-delete rule these should go
- **No JIT compilation** -- eliminates the Spectre/Meltdown class of attack surface. **Simplified rather than weakened by the consolidation:** there is now one non-JIT engine to reason about instead of two
- DOM event dispatch, fetch, localStorage, sessionStorage, history.pushState, requestAnimationFrame
- **Genuine remaining stub, deliberate and test-locked:** `WebSocket` constructs and exposes its full surface, but `readyState` is always `CLOSED` and `send`/`close` are no-ops. `wpt_subset::wpt_websocket_no_throw_on_construct_and_send` asserts `readyState === 3`, so making it live is a feature decision (a persistent `tokio-tungstenite` stream pumped onto the main-thread event loop, as async `fetch` is), not a bug fix. Conversely, `Map`/`WeakMap`, `Set`/`WeakSet` and `URLSearchParams` were **labelled** stubs in stale doc comments and are in fact functional — member calls route through `__kind` dispatch to real implementations; the comments were corrected in the same audit

### File Viewers (200+ formats)
- Images: PNG, JPEG, GIF, WebP, BMP, ICO, TIFF, TGA, HDR, AVIF, DDS, EXR, PNM, QOI, JPEG-XL, SVG, RAW (CR2/NEF/ARW/DNG), PSD, HEIC (Photoshop-grade crop/resize/filter/export pipeline)
- Documents: PDF (view/edit/merge, annotation toolbar with labels, form export, signature stamp, blank-document paper-size picker), DOCX, XLSX (drag-select range, per-column/row resize, copy-as-TSV), RTF, EPUB, MOBI. **Spreadsheet formula support is now the `viewers/formula/` engine** — 255 named functions across math, statistics, text, lookup, datetime, financial, logic and info categories, over a real lexer/parser/evaluator with a typed error model, wired 2026-09-14 and called from `spreadsheet.rs`. The hand-rolled ~60-function evaluator it replaced is deleted. **Still do not claim Excel function parity:** 255 is not ~500, and array formulas, structured references, and cross-sheet references are unverified
- Presentations: `viewers/presentation/` (7 files, 6,146 lines, 76 tests — rewritten and wired 2026-08-17, replacing the former 881-line single-file parser). Formats: PowerPoint OOXML (`.pptx/.pptm/.ppsx/.ppsm/.potx`), OpenDocument (`.odp/.otp`), PowerPoint 97-2003 binary (`.ppt/.pps/.pot`, text recovery only), Keynote packages (preview recovery only). Slides paint from real EMU geometry rather than reflowing. Open / present / edit / print / export, with Slide, Presenter, and Outline view modes; print renders the deck to PDF and hands it to the system printer. Decoded slide-image texture cache is capped at 96 images / 2048px max edge. **Documented in the CHANGELOG under 0.14.0, but not yet in a packaged binary and not covered by any audit**
- Scientific: PDB/mmCIF (protein structures), SMILES/MOL/SDF (chemistry), DICOM (medical imaging — `viewers/dicom.rs` 1,543 lines over a hand-rolled pure-Rust parser in `dicom_parser.rs`, 1,710 lines)
- **Printing across the scientific and CAD viewers** *(new this refresh, source only)*: `print_sheets.rs` (1,541 lines, 18 tests) and `print_kit.rs` (1,109 lines, 7 tests), called from `viewers/chemical.rs`, `threemf.rs`, `iges.rs`, `parasolid.rs`, `step.rs` and `model3d.rs`. This is the "viewer printing" named in `origin/main`'s head commit
- 3D Models: OBJ, STL, GLTF/GLB, PLY, DXF (CAD)
- CAD interchange (v0.10): STEP, IGES, 3MF, OpenSCAD (.scad/.csg), Parasolid (.x_t/.x_b); mesh format conversion STL <-> OBJ <-> 3MF
- Archives: ZIP, TAR, GZIP, XZ, BZIP2, ZSTD, 7Z, RAR (Zip viewer supports mark-for-removal queue)
- Audio: MP3, AAC, FLAC, OGG, WAV (playback via rodio)
- Code: 200+ language syntax highlighting via syntect (theme picker + full TokenType palette + language detector)

### File Sidebar (`src/files/`, 5 files / 3,959 lines) — integration incomplete

An Explorer/Finder replacement living in the browser chrome rather than in a separate application. Three views over one row set: `Tree` (Explorer-style), `Details` (Finder-style columns), and `Timeline` (reverse-chronological feed). Adds a filter query language (`filter.rs`, with highlight rules), per-root view/edit permission modes (`model.rs::AccessMode`), and an optional SQLite index for whole-drive search (`index.rs`, with a background scan handle and progress events). State and logic live in `mod.rs`; egui drawing is separated into `panel.rs`, mirroring the split used by `print::PrintDialog`. The panel returns a `FileAction` (`Open` as `file://` in a tab, or `OpenExternal` to the OS default application) rather than performing navigation inline.

**Status:** declared in `main.rs` and consumed by `app.rs` and `browser_ui.rs`; reachable from the toolbar `files` button and the `view.files` command. The nine previously-uncalled symbols are resolved — three wired, six deleted — and the sidebar now carries a **mutating surface**: New Folder, Rename (inline field, Enter commits / Esc cancels), and two-click confirm Delete, all gated by `access_for` / `can_edit_cwd` so View roots and mounted roots themselves refuse the mutation even where the OS would permit it. Measured **3,959 lines / 36 tests** this refresh, down from 4,346 / 39 — the sidebar shrank, and no cause was identified; the figure is recorded rather than explained. **It is in no packaged binary, the mutation paths have never been exercised in a shipped build, and it has no audit coverage** — which is a worse combination for a component that deletes files than it was for one that only read them.

### MCP Integration — one protocol as of 2026-10-05

- Dual-mode server: stdio JSON-RPC (Claude Desktop) + native WebSocket (bincode). **Two transports, and now one vocabulary.**
- **`PROTOCOL_VERSION` 2 → 3, a breaking wire change, and the reason is a defect class rather than a feature.** `mcp_protocol.rs` defined a 30-command bincode vocabulary for the live browser; `mcp_server.rs` defined a *separate* 30-command JSON-RPC vocabulary for the headless engine. They overlapped in nine commands **with incompatible field shapes** — `Click{x,y}` against `Click{element_ref, button, click_count}`, `Scroll{delta_x,delta_y}` against `Scroll{direction, amount}`, `CloseTab{tab_index}` against `CloseTab{tab_id}` — and each carried thirteen commands the other had never heard of. "Click" meant two different things depending on which transport carried it, kept in step by hand, in a codebase that had already shipped one silent wire-drift bug from exactly that arrangement. There is now **one vocabulary of 43 commands** and two backends that answer it. Where the headless backend genuinely cannot answer — no sandbox manager, no detection engine, no vault, no foreman — it returns **`NotAvailable` naming the reason** rather than a plausible-looking empty answer a client would act on
- **Tabs are addressed by stable id, never strip position.** Every tab-addressing command carries a `TabRef` (`Option<u64>`, `None` meaning the active tab); an unknown id is refused rather than falling back to whatever is in front. An index is a property of how the strip happens to be arranged right now, so dragging a tab, closing one to its left, or opening one from a background link all renumber it — and a command that travelled with an index and arrived after any of those acted on a different tab than the caller meant, silently
- **28 JSON-RPC handlers collapsed into one translator plus one response mapping.** `McpServer::build_command` is pure (tool name + JSON args → `McpCommand`) and separate from transport, which is what finally made the argument handling testable — asserting on it used to require standing up a browser. `mcp_server.rs` lost ~640 lines while gaining capability. Two permissive shapes were narrowed at the JSON boundary: `FormValue` (`Text`/`Bool`/`Number`) replaces a `serde_json::Value` that bincode can serialise but cannot deserialise back out of a frame, and `ClickTarget` makes "an element or a point, never both and never neither" unrepresentable
- **Thirteen commands new to the live browser**, implemented against the real session: `ReadTree`, `GetText`, `FindElement`, `PressKey`, `FormInput`, `GetTrustLevel`, `GetFileInfo`, `SearchBookmarks`, `AddBookmark`, `SearchHistory`, `StartDownload`, `ListDownloads`, `WebSearch`. `ReadTree` returns real layout bounds from the live layout tree, where the headless path had always returned `None`
- Auth-gated with ring constant-time bearer token verification. **And, new: the token is no longer the whole authorisation story.** Four privileged commands — `ExecuteScript`, `OpenFile`, `VaultQuery`, `Cookie Set`/`Delete` — are refused with `PermissionDenied` until the user enables them in a new **Browser Control** tab of the MCP Control Center. Default off, session state. See Security Posture
- Foreman policy engine: even authenticated clients cannot modify security/sandbox/auth zones without user approval. **Deny-by-default** — unmatched targets previously fell through to `Allow`, `[zones].open` was declared but never consulted, and explicit feature rules did not reliably beat the open zone. All three fixed; `foreman/` is now 3,624 lines and 80 tests
- MCP client capability for driving external agents
- MCP Control Center (Ctrl+Shift+O): **7-tab** orchestrator surface -- Sessions, Agents, Tasks, Tools, Audit, Artifacts, **Browser Control**
- MCP diagnostics window (Ctrl+Shift+M): per-agent confidence percentages, encrypted key vault status, TLS-spoof + HTTP/1.1/2/3 transport matrix
- Tools: file operations, git integration, REST client

### Extensions — content scripts are wired, and now in the measured tree

`mod extensions;` at `main.rs:148`; `ExtensionManager` constructed in `browser_core.rs` and used by `engine.rs`; `get_content_scripts(url)` called on the navigation path at `app.rs:2044` and `engine.rs:914`, with per-navigation injection; `ExtensionAPI` surfaced in `browser_ui.rs`. `extensions.rs` is 522 physical lines with 2 tests.

The prior edition flagged this as *"on `origin/main` only — unreviewed **and** unmeasured here."* It is now measured. It remains **unreviewed**, and it is a code-execution-into-page path, which is why Security Posture places it near the top of the next audit's scope.

### Userscripts — a `GM_*` manager now ships, reversing the 2026-08-31 withdrawal

Prior editions correctly recorded that Sassy Browser had **no compiled user script manager**: the drafts were unwired and were deleted 2026-09-07. A real one has since been built, and the withdrawal is now stale.

Measured wiring, which is what the August overclaim lacked:

- `userscripts.rs` (1,223 physical, 2 tests) and `userscripts_host.rs` (449, 6 tests)
- `UserScriptManager` constructed at `browser_core.rs:133` over `config_dir()/userscripts`, held as `Arc<RwLock<…>>` at `browser_core.rs:102`
- `UserScriptUI` held in `BrowserApp` at `app.rs:946`, built from that manager at `app.rs:3199`
- `get_scripts_for_url(url, RunAt::DocumentEnd)` called on the live navigation path at `app.rs:1679`
- `userscripts_host::GmEffect` applied at `app.rs:1720`
- Surfaced as `Surface::UserScriptManager` ("Userscripts") in `beginner_mode.rs`, and rendered in the DevTools **User Scripts** tab — `panel.rs:520` takes `&mut crate::userscripts::UserScriptUI` and `panel.rs:563` draws it, where that tab was an explicit in-code placeholder in every prior edition

**Fifteen `GM_*` APIs are present:** `GM_addStyle`, `GM_deleteValue`, `GM_getResourceText`, `GM_getResourceURL`, `GM_getValue`, `GM_info`, `GM_listValues`, `GM_log`, `GM_notification`, `GM_openInTab`, `GM_registerMenuCommand`, `GM_setClipboard`, `GM_setValue`, `GM_unregisterMenuCommand`, `GM_xmlhttpRequest`.

**What is not claimed:** Tampermonkey or Greasemonkey *compatibility*. Fifteen grants is not the full `GM_*` surface, `@require`/`@resource` fetching and the full metadata-block grammar are unverified, and the manager has never run in a packaged binary. **It is also a script-injection path into the user's authenticated pages that no auditor has seen** — see Security Posture, where it joins the extension content-script path at the top of the next audit's scope.

### Voice intake — speech-to-text is built, behind an off-by-default feature

The 2026-08-31 withdrawal ("voice transcription is not implemented") and the 2026-09-02 deletion of the dead engine were both correct. **Both are now stale**, and this section is rewritten rather than deleted, because the shape of the fix matters.

A new **`whisper` Cargo feature, off by default**, gates on-device speech-to-text. `WhisperEngine` gains `load`, `transcribe`, `transcribe_file` and a `Drop` that frees the context, over a hand-written C shim (`whisper/whisper_wrapper.c`, 3,453 bytes) that keeps whisper.cpp's large, versioned `whisper_full_params` struct on the C side where the compiler checks it — no `bindgen`, no `cmake`, three `extern "C"` functions taking scalars and pointers. `src/whisper_ffi.rs` is 50 lines; `mod whisper_ffi;` is declared in `main.rs`; `voice.rs` is back to **1,347 physical lines with 24 tests**; `WhisperEngine` is referenced from `app.rs`, `voice.rs` and `browser_ui.rs`. `fn transcribe` now matches **three** times, not zero.

`transcribe_file` decodes through symphonia — the same decoder the audio viewer uses, so any format that viewer opens can be transcribed — downmixes to mono, resamples to 16 kHz, and caps at ten minutes per call because whisper.cpp decodes at roughly real time on CPU with no cancellation. `resample_to_16k` averages each input group rather than decimating (plain decimation folds everything above 8 kHz back into the speech band), recomputes group boundaries per output sample so a 44.1 kHz source distributes its remainder instead of drifting over a long capture, and **refuses to upsample** rather than inventing detail an 8 kHz capture never contained, which the model would transcribe confidently.

**Four limits, all of which have to travel with the claim:**

1. **The default build is unchanged.** With the feature off, `load` and `transcribe` return an error naming exactly what is missing rather than reporting a success the engine cannot honour, and a test pins that.
2. **It cannot be built without unvendored third-party artifacts.** The feature needs whisper.cpp's headers and prebuilt static libraries for the host target, pointed at by `SASSY_WHISPER_DIR`. They are roughly 23 MB per target, belong to upstream, and are not in the repository.
3. **It is an unverified port, not proven code.** The shim and FFI come from `sassy-talks/android-native`, where the same pattern was written for Android ABIs — **and where it is currently unwired**: that repo's `lib.rs` declares neither `whisper_ffi` nor `transcription`, and its `build.rs` ends with *"Whisper.cpp libraries removed — transcription stripped to slim down binary size."* The code was a good design that had been stripped from its own build, and it arrives here in that condition.
4. **A real diagnostics panel replaced the frame-rate probe.** The speech-to-text panel now drives the app's own engine — model path and presence, a Load button, a file to transcribe, the transcript, the last error — rather than constructing a throwaway `WhisperEngine` every frame to read an accessor off it.

**The honest statement: speech-to-text is implemented, off by default, unbuildable without upstream artifacts, and unverified. It is not a shipped capability**, and chapter 07 lists it accordingly rather than under *Fully Implemented*.

The history is kept because it explains the standard: until 2026-08-27 the gap was masked by a ~126-line block in `render_voice_panel` that constructed the entire stack and ran its lifecycles with every binding discarded as `let _x =`, solely to keep dead-code warnings quiet. It sat on the paint path, so opening the Voice panel re-ran it every frame — an OS thread and audio device per frame, and potentially a billable cloud transcription request per frame carrying the user's real API key. Removing it fixed that defect and exposed the underlying one; deleting the engine closed it; this feature-gated implementation is the third act, and it is gated precisely so that the first act cannot recur.

### Time arithmetic (`src/monotonic.rs`) — new, and it fixes a shipped crash

`Instant - Duration` **panics** in Rust when the result would predate the clock's epoch. On Windows that epoch is system boot, so `Instant::now() - Duration::from_secs(300)` aborts the process whenever the machine has been up for less than five minutes. Nineteen call sites across ten modules — `engine.rs`, `network_monitor.rs`, `smart_history.rs`, `detection.rs`, `token_meter.rs`, `behavioral_mimicry.rs`, `sandbox/{quarantine,popup}.rs`, `ui/{network_bar,popup}.rs` — were written as a plain `-`. **Launching the browser 220 seconds after a reboot killed it at startup.** That behaviour is in the shipped v0.13.1 binary.

`monotonic::ago(d)` replaces the plain form and clamps to process start rather than panicking, which is also semantically correct: these cutoffs prune records this process made, and nothing it recorded can predate its own start, so a clamped cutoff prunes nothing — exactly right when the window reaches back further than the process has existed. The module initialises lazily through a `OnceLock`, so it requires no wiring from `main`. The project rule is now: **never write `Instant::now() - d` directly.**

### Cryptography
- Password vault: ChaCha20-Poly1305 encryption, Argon2id key derivation
- Ed25519 identity keys
- OS credential store (keyring) for API key encryption at rest
- Minisign signature verification for update manifests

## Build Configuration

- Release profile: opt-level 3, LTO enabled, single codegen unit, stripped, panic=abort
- Three binaries: sassy-browser (main), sassy-ui (pure-Rust viewers), mcp-client (CLI)
- Cross-platform: Windows (primary), macOS, Linux
- **Minimum Rust version: 1.92** (edition 2021), declared in `Cargo.toml` since the egui/eframe 0.35 migration. Installed toolchain at refresh: cargo/rustc **1.98.1**. *(Prior editions of this chapter published 1.75, which understated the floor by seventeen releases; corrected 2026-08-31.)*
- **Windows resource embedding, fixed 2026-08-27.** `build.rs` pointed `set_icon` at `assets/icons/icon.ico`, a file never tracked in git. `rc.exe` failed on it, and because the failure was swallowed as `eprintln!("Warning: …")` the entire resource block was silently dropped from every Windows build — icon, version metadata, and the application manifest declaring per-monitor-v2 DPI awareness. The icon now comes from the one the installer already used, `rc.exe` is located in the Windows SDK when not on `PATH`, and a resource failure fails the build (`SASSY_ALLOW_MISSING_RESOURCES=1` opts out). `scripts/build-release.ps1` now names artifacts `sassy-browser-v{version}-{sha}.exe` and verifies the version baked into the exe resource matches `Cargo.toml`.

## Dependencies (119 unique direct crates)

All dependencies are pure Rust or have Rust-only transitive dependencies. No C/C++ browser engine code.

**Unchanged across the largest deletion in the project's history.** Removing 14,937 lines of bytecode VM removed no crate — the VM was first-party Rust throughout, so the consolidation is a pure reduction in maintained surface rather than a dependency change. The `whisper` feature adds no Cargo dependency either: it links whisper.cpp's prebuilt static libraries through a hand-written C shim, with no `bindgen` and no `cmake` crate. *(The one qualification on "no C/C++" above: with `--features whisper` the build links whisper.cpp's static libraries and a 3,453-byte first-party C shim. That is off by default, and it is not browser-engine code — but the claim is "no C/C++ **browser engine** code," and it should be read that precisely.)*

**Two new Cargo features, both off by default.** `whisper` gates on-device speech-to-text (see *Voice intake* above). `diagnostics` gates developer probe panels and synthetic-event buttons, and is off **for a security reason stated in the manifest**: several of those surfaces printed overlay IPs, identity public keys, session and device ids, and a one-time recovery key, which has no business being reachable in a shipped build. CI keeps the gated code compiling with `cargo check --features diagnostics`. The earlier `pure-viewers`, `boa`, `voice` and `devtools` features were folded into the default build; `default = []`.

**Derivation:** `[dependencies]` declares 110 crates. Five `target.'cfg(…)'` sections declare 11 entries — `not(android)`: `native-dialog`, `arboard`, `unrar`, `iced`; `android`: `winit`, `android-activity`; `windows`: `windows`, `winreg`; `macos`: `cocoa`, `core-foundation`; `linux`: `iced`. Those 11 entries are 10 unique names (`iced` appears twice), and one of them (`winit`) is also in the main list. **110 + 10 − 1 = 119 unique crates across 121 entries.** Plus 2 dev-dependencies (`quickcheck`, `quickcheck_macros`) and 1 Windows build-dependency (`winres`).

Notable crates: eframe/egui 0.35 (UI), include_dir (Nova nine-slice asset embedding), html5ever 0.27 (HTML), cssparser 0.34 / lightningcss 1.0.0-alpha.70 (CSS), taffy 0.9 / parley 0.11 / vello 0.3 + egui_taffy 0.13 (chrome layout + render-stack probe), ureq 2.10 (HTTP/1.1) + reqwest 0.12 (HTTP/2 with rustls-tls), ring 0.17 (crypto), keyring 3 (OS credential store), minisign-verify 0.2 (update signing), symphonia (audio), pdbtbx 0.12 (proteins), iced 0.14 (pure-Rust GUI for embedded viewers, platform-conditional). Page layout/paint remain hand-rolled CPU code in `layout.rs`/`paint.rs`. `Cargo.lock` resolves to **1,135** `[[package]]` entries.
