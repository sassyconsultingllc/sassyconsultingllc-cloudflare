<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-MNWPUPT3IOWU
-->
# Product Roadmap

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16**

---

## What Ships Today

"Ships today" represents **v0.16.1**, built and packaged with a clean compiler gate (**0 errors, 0 warnings, 27.27s**) across **322,386 compiled physical lines** and **3,099 unit tests**.

> **Build state:** `cargo check --release` at head of tree as of 2026-11-16 — **0 errors, 0 warnings, 27.27s**. The zero-warning gate is **clean and fully restored**. **Full suite green: 3,099 passed / 0 failed / 19 ignored**.
>
> **Version control:** `HEAD` is `00eef70` (2026-11-16) on `main`, tagged **`v0.16.1`**, and fully pushed to `github/main` (PR #78 release bump, PR #79 array callback reentrancy fix).

### Newly landed this refresh

Moved into the sections below because the code now backs them. Unlike the last two refreshes, most of this is **committed and on `origin/main`** rather than working-tree-only — but **none of it is in a packaged binary.**

- **The bytecode VM is deleted.** 14,937 lines, 22 files. The largest removal in the project's history, and it closes the Q3 item that read *"mature the bytecode VM toward becoming the default runtime"* by deciding against it. See *Removed from the roadmap* below.
- **Userscript manager with a 15-API `GM_*` surface**, wired on the live navigation path and rendered in the DevTools User Scripts tab, which was a placeholder in every prior edition.
- **Speech-to-text behind an off-by-default `whisper` Cargo feature** — built, unverified, unbuildable without unvendored upstream libraries. **Not listed as Fully Implemented.**
- **One unified MCP protocol**, `PROTOCOL_VERSION` 2 → 3, 43 commands replacing two separate 30-command vocabularies; thirteen commands new to the live browser; tabs addressed by stable id.
- **Privileged MCP commands behind a user-held switch** — a new Browser Control tab, default off, with a test that fails the build if the UI advertises a gate the code does not enforce.
- **A `diagnostics` Cargo feature, off by default**, walling off probe panels that printed overlay IPs, identity keys, session ids and a one-time recovery key.
- **Viewer printing** — `print_sheets.rs` (1,541 lines, 18 tests) and `print_kit.rs` (1,109, 7 tests) across the chemical, IGES, STEP, Parasolid, 3MF and 3D-model viewers.
- **Extension content-script injection is now in the measured tree**, not just on `origin/main`.
- **`app/explorer_ui.rs` migrated to egui 0.35**, completing that migration.
- **Spreadsheet testing caught up with the engine** — `viewers/spreadsheet.rs` tests 6 → 41.

### Fully Implemented -- Rendering Engine
- HTTP(S) with Chrome-132 TLS fingerprint spoofing (JA3-match), HTTP/1.1 via ureq, HTTP/2 via reqwest delegation on h2 ALPN
- HTML5 parsing via html5ever + custom tree walker
- CSS cascade + hand-rolled flex/grid/block layout (pure Rust; page path hand-rolled; egui_taffy drives chrome; taffy/parley/vello as probes -- see Technical Architecture)
- CSS `::before` / `::after` pseudo-element generation (m19, r3/r4) -- now honors computed `display` per Mercury r5 / r7 closure
- CSS `url()` background-image resolution (m21, r3/r4)
- CSS dynamic pseudo-class re-resolution via CascadeContext threading (m18, r3/r4)
- CSS `overflow:hidden` clipping + z-index bucket sort in paint walk (m20, r3/r4) -- bucket ordering restored
- Multi-level positioned-ancestor walk for `position: absolute`/`fixed` (m17, r3/r4)
- DOM timer queue + DOMContentLoaded event firing (m23, r3/r4)
- DomBridge to NodeRef unification (m24, r3/r4) -- cleans up JS->DOM bridging
- HSL/HSLA, #RGBA hex, #RRGGBBAA hex, space-separated `rgb(0 0 0 / 0.5)` color parsing (v0.10.1)
- Universal `*` selector parsing (v0.10.8) and `rem`-before-`em` length parsing (v0.10.5) -- gating fixes for every modern design-system site
- Image loading on page load with `srcset` candidate resolution (v0.10.7); HTML `width`/`height` attr fallback for replaced inline-block elements (v0.10.4)
- Network Activity panel for every renderer fetch (HTML, CSS, images) with running session-total + active-count headers (v0.10.6)
- FOUC-prevention strip: drops bare `body { display:none }` style blocks that block Next.js / React-SSR hydration
- `@font-face` web fonts (v0.11.0, `src/font_registry.rs`): parses `@font-face` rules, resolves family/weight/style, shared resolver across measure + paint paths; TTF/OTF direct, WOFF1 decompressed per-table, WOFF2 decoded (`src/woff2.rs`: Brotli + glyf/loca/hmtx transform reconstruction). Variable-font axis instancing deferred
- HTTP/2 document navigation (v0.13.0): HTTPS page fetches try `fetch_h2` (ALPN, cookies, referer, gzip/br decode) with TLS-spoofed HTTP/1.1 fallback for WAF-heavy hosts
- Async document navigation + async `fetch()` (v0.13.0): page and script network I/O run off the UI thread; promises settle on the main thread via the dynamics pump so `await fetch()` no longer blocks page load (GitHub and other fetch-heavy SPAs). 0.13.1 added per-URL in-flight dedup to kill an async page-load connection storm
- Background CSS prefetch (v0.13.0): linked stylesheets fetch on the page-load thread alongside the document; the UI thread only applies CSS during render
- `defer` / `async` classic-script load ordering (v0.13.0): parser-blocking -> `defer` -> modules; `async` external scripts fetch in the background and execute on the pump tick
- Per-element `overflow: auto|scroll` scrolling (v0.13.0): containers scroll independently of the viewport
- Google render-hang fix (v0.13.0): CSS cascade attribute indexing (`[jsname]`, `[data-*]`) + rightmost-compound prefilter cuts the O(nodes x universal-rules) blow-up on large inline stylesheets; `<noscript>` fallback surfaces readable content when a JS-only shell leaves the body empty

**Rendering reality note:** flex/grid/block layout and text shaping are hand-rolled pure-Rust (taffy/parley are not wired into the live path), and painting is a CPU software rasterizer (`paint.rs`) -- there is no GPU/`vello` path today. The 2026-06-10 audit documents the correctness gaps in this hand-rolled stack (see Security Posture); the items below describe what is wired and runs, not a claim of full W3C conformance.

### Fully Implemented -- File Viewers (200+ formats across 43 wired viewer modules)
- Photoshop-grade image viewer (m22, r3/r4): crop/resize/filter/export pipeline
- PDF viewer with annotation toolbar (labels, form export, signature stamp)
- DOCX, XLSX (drag-select range, per-column/row resize, copy-as-TSV), RTF, EPUB, MOBI
- DICOM medical imaging viewer (`viewers/dicom.rs` 1,543 lines over a hand-rolled pure-Rust parser in `dicom_parser.rs`, 1,710 lines)
- Chemistry stack: SMILES to 3D, Gasteiger charges, NMR/IR prediction
- 3D models: OBJ, STL, GLTF/GLB, PLY, DXF
- CAD interchange (v0.10.0): STEP, IGES, 3MF, OpenSCAD (.scad/.csg with Customizer-annotation parser, Render + Export STL via subprocess), Parasolid (.x_t/.x_b)
- Mesh format conversion STL <-> OBJ <-> 3MF (`src/cad_convert.rs`)
- Archive viewer with mark-for-removal queue (Zip)
- Text viewer Save / Save-As / Print: md->html via comrak, csv<->json via csv+serde_json, csv<->tsv delimiter swap, any->html `<pre>` wrap
- Audio playback via rodio; spreadsheet `Currency` cell variant in Print path
- Full JsonViewer + JsonTreeNode + JsonColors API
- **Spreadsheet formula engine** *(source only — wired 2026-09-14, committed via PR #51)*: `viewers/formula/` (15 files, 8,889 lines, 64 tests, **255 named function match arms** across math, statistics, text, lookup, datetime, financial, logic and info categories) is the live calculation core. `pub mod formula;` at `viewers/mod.rs:28`; `spreadsheet.rs` calls `formula::evaluate` on the cell path; the hand-rolled ~60-function evaluator it replaced was **deleted**. Formulas stay formulas instead of collapsing to a one-shot number, unsaved cell edits are visible to every formula, and text/lookup/date functions no longer degrade to `f64` — the engine carries a typed `CalcError`. **All 64 tests execute and pass in the 2026-10-05 run, for the second consecutive refresh.** Added **no new crate dependency**. **New this refresh:** its call site finally has tests of its own — `spreadsheet.rs` went 1,727 → 2,417 lines and **6 → 41 tests**. **Still not Excel parity** — see *Partial / Stubbed*
- **Presentation viewer rewrite** *(post-0.13.2, source only)*: `viewers/presentation/` (7 files, 6,146 lines, 76 tests) replaced the 881-line single-file parser on 2026-08-17 and is now compiled. Formats: PowerPoint OOXML (`.pptx/.pptm/.ppsx/.ppsm/.potx`), OpenDocument (`.odp/.otp`), PowerPoint 97-2003 binary (`.ppt/.pps/.pot`, text recovery only), Keynote packages (preview recovery only). Slides paint from real EMU geometry rather than reflowing. Open / present / edit / print / export, with Slide, Presenter, and Outline view modes; print renders the deck to PDF for the system printer. Texture cache capped at 96 decoded slide images / 2048px max edge. **Documented in the CHANGELOG under 0.14.0; not audited, and not in a packaged binary**

### Fully Implemented -- JS Engine (one engine, as of 2026-10-05)
- SassyScript: pure-Rust **tree-walking interpreter** (`interpreter.rs`, **18,664** physical lines), no JIT -- broad surface (classes, generators, promises, typed arrays, DOM dispatch) with known core-semantics gaps tracked by the 2026-06-10 audit. **It is now the only execution path.**
- DOM events, fetch, localStorage, sessionStorage, history.pushState, requestAnimationFrame, performance.now
- Standard library: `js/builtins/` is **2 files, 237 lines** — `ethereum.rs` (the EIP-1193 provider, the only builtin bound to `JsInterpreter`) plus `mod.rs`. **The "14 modules, 4,318 lines" figure in prior editions is withdrawn:** the other twelve were `install(vm: &mut Vm)` — VM machinery — and were deleted with the VM. Their interpreter-side functionality lives in `interpreter.rs`, which is why it grew ~2,000 lines
- `Map`/`WeakMap`, `Set`/`WeakSet` and `URLSearchParams` are **functional**, not stubs. They were *labelled* "minimal stub" in doc comments that had gone stale; member calls route through `__kind` dispatch to real implementations (get/set/has/delete/clear/keys/values/entries, `forEach` on the interpreter call path). The comments were corrected in the 2026-08-08 consolidation audit
- WPT-subset runner with **102** `#[test]` attributes in `src/wpt_subset.rs` (re-confirmed 2026-10-05; the file is unchanged since 2026-08-14, and the 103 a naive substring count returns includes one mention inside a doc comment). This is a measure of test surface. Full-suite scoreboard 2026-10-05: **2,586 passed / 0 failed / 19 ignored** across 2,605 tests run (`cargo test --release --bin sassy-browser`, 7.65s) — WPT attributes are included in that run; no separate WPT pass-rate claim is made beyond that
- Note: the Boa fallback engine was removed in 0.13.x and the first-party bytecode VM in 2026-10 -- SassyScript's tree-walker is now the sole JavaScript engine, singular

### Removed from the roadmap: the SassyScript bytecode VM

**This chapter listed the bytecode VM under *Fully Implemented* for four consecutive editions, and carried a Q3 line to mature it toward becoming the default runtime. It has been deleted instead, and that is the right outcome.**

What went: `js/vm.rs` (5,852 lines), `js/compiler.rs` (2,996), `heap.rs` (685), `chunk.rs` (603), `vm_value.rs` (397), `gc.rs` (353), twelve VM-facing builtins, the `"use vm"` branch in `execute_page_script`, `ScriptEngine::opts_into_vm` / `execute_with_vm`, `vm::wire_module()`, and the Phase-6 VM test suite — **14,937 lines across 22 files.** `"use vm"` matches zero times in `src/`, and **zero `js::vm` or `js::compiler` cases appear in the 2026-10-05 test run**, which is how the deletion is confirmed rather than assumed.

Why it is the right outcome, from `audits/2026-08-08-js-engine-consolidation-and-efficiency.md`: **the VM was never DOM-wired.** Its own code noted it was *"additive and not yet DOM-wired"* — it could not touch the page at all. It had partial builtins, zero production callers, and was reachable only through a source directive no real page emits. A bytecode VM is conceptually faster than a tree-walker, but an unfinished and unwired one contributes compile time, binary size and maintenance surface and nothing else. **The efficiency win here was consolidation, not optimisation.**

What that costs the roadmap, stated plainly: **there is no longer a credible path to a faster JS runtime on this roadmap**, because the half-built one was the path and it has been removed. If JS execution speed becomes a gating concern for real-site performance, that work restarts from a design decision rather than from 15,000 lines of existing code. The counter-argument, which this chapter accepts: those 15,000 lines were never going to reach the page without a DOM-wiring effort comparable to writing them, and carrying them as an asset was the overclaim.

### Fully Implemented -- Security & Identity
- 4-layer sandbox (network, render, content, download)
- Fingerprint poisoning: canvas, WebGL, audio, fonts (conservative + aggressive)
- Native ad blocker with EasyList + EasyPrivacy + Fanboy filter lists
- Password vault (ChaCha20-Poly1305 + Argon2id) + password strength meter + custom-fields indicator
- Hunter / Killer Mode: toggle, custom tracker entry, recent-hunts list, persistence, entropy-bomb payload preview, L4 self-adapting noise probe wired to a `tokio::mpsc` evolution channel
- Tracker-poisoning controls (sister to Hunter Mode)
- Family profiles (Adult/Teen/Kid) with PIN-locked parental controls, recovery key one-time display
- Smart history (14.7s delay, NSFW detection)
- Cookie Inventory panel (Ctrl+Shift+K): every cookie in every domain, raw `to_set_cookie` wire format, SameSite enforcement (Strict/Lax/None)
- Detection honeypot: BehaviorRecord drain into the MCP orchestrator's auditor lane

### Fully Implemented -- MCP & Automation
- MCP server (stdio JSON-RPC + native bincode WebSocket)
- MCP client (bincode over WebSocket)
- MCP Control Center (Ctrl+Shift+O): 6-tab orchestrator -- Sessions, Agents, Tasks, Tools, Audit, Artifacts
- MCP diagnostics window (Ctrl+Shift+M): per-agent confidence percentages, encrypted key vault status, TLS-spoof + HTTP/1.1/2/3 transport matrix
- Encrypted MCP key vault (`keyring` -> Windows Credential Manager / macOS Keychain / Linux Secret Service)
- **Foreman policy engine, deny-by-default** *(source only, uncommitted)*: unmatched targets previously fell through to `Allow`, `[zones].open` was declared and never consulted, and explicit feature rules did not reliably beat the open zone. All three fixed; `foreman/` 2,454 → 2,675 lines, 56 → 63 tests. A security control **changed** since the last audit, therefore unreviewed
- AI helper (multi-provider: Claude, Grok, Gemini) plus an **OpenAI-compatible OmniRoute provider** sharing `call_openai_compatible`
- REST API client (`rest_client.rs`, 1,315 lines) with a `MAX_RESPONSE_BYTES` body-truncation guard; can drive a local OmniRoute gateway on worker threads with credential variables held in the OS keyring. Registered in Foreman identity and gated behind `requires_approval`

*Two entries were removed from this list on 2026-08-31 — "Whisper voice intake model picker + local-first transcription" and "User script manager (Greasemonkey / Tampermonkey-compatible GM_\* API)". **Both withdrawals were correct at the time, and both are now stale.** The userscript manager has been rebuilt and wired and appears below under* Implemented -- Userscripts*; voice transcription has been rebuilt behind an off-by-default feature and appears under* Partial / Stubbed*, not here. Neither returns to this list with its original wording: the first is not Tampermonkey-compatible, and the second is not a shipped capability.*

### Implemented -- Userscripts (source only; the 2026-08-31 withdrawal is reversed)

`userscripts.rs` (1,223 lines, 2 tests) + `userscripts_host.rs` (449 lines, 6 tests). Wiring, measured, because the August overclaim was precisely a case of a claim without wiring:

- `UserScriptManager` constructed at `browser_core.rs:133` over `config_dir()/userscripts`, held as `Arc<RwLock<…>>`
- `UserScriptUI` held in `BrowserApp` at `app.rs:946`, built from that manager at `app.rs:3199`
- `get_scripts_for_url(url, RunAt::DocumentEnd)` called on the **live navigation path** at `app.rs:1679`
- `userscripts_host::GmEffect` applied at `app.rs:1720`
- Surfaced as `Surface::UserScriptManager` ("Userscripts") in `beginner_mode.rs`, and **the DevTools User Scripts tab now renders the real UI** (`panel.rs:520,563`) where every prior edition of this chapter described it as an explicit in-code placeholder
- **All 8 of its tests execute and pass** in the 2026-10-05 full-suite run

**Fifteen `GM_*` APIs:** `GM_addStyle`, `GM_deleteValue`, `GM_getResourceText`, `GM_getResourceURL`, `GM_getValue`, `GM_info`, `GM_listValues`, `GM_log`, `GM_notification`, `GM_openInTab`, `GM_registerMenuCommand`, `GM_setClipboard`, `GM_setValue`, `GM_unregisterMenuCommand`, `GM_xmlhttpRequest`.

**What is not claimed, and the original withdrawn entry claimed it:** *Greasemonkey / Tampermonkey compatibility.* Fifteen grants is not the full `GM_*` surface; `@require` / `@resource` fetching and the full metadata-block grammar are unverified; no real-world userscript has been round-tripped. **And it has never run in a packaged binary.** Security Posture rates it, with extension content scripts, as the **first** item in the next audit's scope — it executes third-party JavaScript against the user's authenticated pages, and it carries 8 tests and zero review.

### Implemented -- Printing across the scientific and CAD viewers (source only)

`print_sheets.rs` (1,541 lines, 18 tests) and `print_kit.rs` (1,109 lines, 7 tests), called from `viewers/chemical.rs`, `threemf.rs`, `iges.rs`, `parasolid.rs`, `step.rs` and `model3d.rs`. All 25 tests pass in the 2026-10-05 run. This is the "viewer printing" named in `origin/main`'s head commit. **Not in a packaged binary, no audit coverage, and no round-trip verification against a physical printer or a reference PDF.**

### Fully Implemented -- Web3 & Education
- Web3 educator side-panel with 5 risk tiers (Safe / Caution / Warning / Danger / Critical)
- Token approval bumped to Critical (unlimited-approval is the single highest-loss wallet attack vector)
- Cross-Chain Bridge risk concept (Danger tier) with real-world rationale on bridge fund concentration
- MetaMask middleware path made explicit via EIP-1193 (Sassy Browser is not custodial)
- Easter-egg discount rewards (AI Helper integration)

### Fully Implemented -- Sync & Companion
- Phone companion PWA over WireGuard / Cloudflare Tunnel (Tailscale third-party fallback)
- WireGuard-first first-run wizard with cloudflared install + tunnel-create command snippets
- Family device approval flow: Pending -> Approved -> Blocked -> Removed
- Privacy-respecting device Presence projection (online/offline + last_seen only -- no URLs, tabs, history broadcast)
- `UserManager` admin: bootstrap -> recovery key -> add user -> PIN / identity / data + sync keys / make-admin / remove-user
- SyncServer client-snapshots diagnostic surface

### Fully Implemented -- Browser Chrome
- Address bar with Ctrl+L focus, link clicking
- Tabs with per-tab favicon painting, per-tab mute toggle, tab groups Collapse / Expand
- Downloads with Pause / Resume, gated "Open" button, auto_open_files preference toggle
- Bookmarks page with folder picker, Create folder, subfolder count, domain chips, rename
- History page with per-entry delete + domain chip
- Print Ctrl+P with PageRange (All / Range / Custom)
- DevTools panel (Elements, Network, Sources, Application, Security). **The Elements panel is now populated** *(source only, uncommitted)* — `ElementsState::root` was `None` for the life of the panel, so the tab only ever said "No DOM tree available"; `DomNode::from_live` now mirrors the live document, Inspect reveals and selects the right-clicked element expanding only its ancestor path, rows are click-to-select, and the styles pane shows computed style for the selection. **The User Scripts tab remains an explicit in-code placeholder**; the standalone REST client (`rest_client.rs`) is the live surface for the REST Client tab
- **Page context menu** *(source only, uncommitted)*: hit-test-aware right-click over rendered content. Link section (open in new / private tab, copy address, save link as), image section, editable-field section (cut / copy / paste), and a page-wide section (back / forward using the toolbar's own enabled probe, reload, save page as, print, view source, inspect). Links resolve by walking ancestors, so an image inside an anchor offers both sections, and every `href` and `src` is absolutised against the document base before reaching the clipboard or a new tab
- **Field cut / copy / paste** *(source only, uncommitted)*: routed through the same `dispatch_web_text_input_core` / `dispatch_web_backspace_core` helpers the keyboard path uses, so page scripts observe an identical keydown/input/change sequence and can still veto with `preventDefault()`. A vetoed cut leaves the clipboard untouched
- Engine state probe in Settings (move_tab swap, page()/page_mut()/execute_inline_scripts(), zoom/focus/incognito toggles)
- Settings: session/network/stealth/secrets diagnostics, OS keyring probe, network monitor, Stealth Victories counter, VPN sync server probe
- PIN-locked, color-coded Settings (v0.11.0): six color-coded panes (AI & Code, Diagnostics, Identity & Setup, Search & Downloads, Privacy & Trackers, System) behind the onboarding PIN (`UserProfile::unlock`) with a left-rail switcher and re-lock button
- Appearance menu (v0.11.0): theme preset, light/dark, interface size, custom accent moved to a dedicated `Appearance...` window so theming stays reachable without the Settings PIN
- DevTools menu entry (v0.11.0): DevTools now discoverable from the Menu (was F12-only)
- Clickable MCP status badge (v0.11.0): bottom status-bar `MCP` indicator opens the AI assistant pre-seeded with an MCP-call prompt
- Downloads folder picker (v0.11.0): native folder picker on the Downloads "Change..." button (was a no-op TODO)
- **Interface density** *(0.13.2, source only)*: Compact / Comfortable / Spacious / Auto in `Settings → Appearance`, scaling toolbars, tabs, buttons, icons and gaps *without* scaling font size. Auto resolves from live window size and is the default
- **Two-line user-arranged toolbar** *(0.13.2, source only)*: 16 buttons across two rows, each hideable and reorderable from `Settings → Appearance → Toolbar`, persisted in `config.toml`. Row 1 auto-wraps onto row 2 when it cannot fit; the address bar is pinned to row 1
- **Window fitting** *(0.13.2, source only)*: the window is fitted and re-centered on the first frame against the real viewport (floor 640×400), fixing a fixed 1400×900 request that put the title bar off the top edge of a 1366×768 panel with no way to drag it back
- **Post-setup PIN management** *(0.13.2, source only)*: add, change, or remove a PIN at any time from `Settings → Identity & Setup`; the API-key vault re-keys to match
- **Image working copies** *(0.13.2, source only)*: opening an image clones it into `cache_dir()/working`; Save targets the clone and overwriting the original is a separate explicit action
- **Onboarding correctness** *(0.13.2, source only)*: encryption is now always on via a per-install device secret rather than requiring a PIN; wizard re-runs offer to keep the existing admin profile instead of orphaning the master key; sealed API keys are read back on load; Windows "Open with" queues the startup file open until the wizard finishes instead of showing an empty browser
- **Sassy Nova theme** *(0.14.0, source only)*: claymorphic chrome built around a new 3D icon set, now the default preset. The palette is measured from the artwork rather than invented — canvas `#1B1A2C`, clay `#8294B9`, bezel `#D4CFEC`, cyan accent `#41CFE7`, violet `#4E59A5` reserved for AI and security affordances — so chrome and icons cannot drift apart. Three variants: `SassyNova` dark, `SassyNova` light, and **`SassyNovaContrast`, a WCAG-AAA high-contrast mode**, made workable by a `ChromeMode` switch (`Skinned` paints the nine-slice clay bitmaps, `Flat` drops them for solid fills and hard borders). Nine-slice renderer keeps clay buttons and panel frames crisp at any DPI; 20 keyed RGBA assets embedded via `include_dir!`. New widget vocabulary: `clay_button`, `flat_icon_button`, `nova_frame`, `nova_bar`, `nova_progress`. An unrecognised `theme_preset` in `config.toml` now falls back to Nova rather than wedging
- **Windows resource embedding fixed** *(0.14.0, source only)*: every Windows build ever shipped lacked an icon, version metadata, and the DPI manifest, because `build.rs` pointed at an untracked `.ico`, `rc.exe` failed, and the failure was swallowed as a printed warning that dropped the entire resource block. Resource failures now fail the build. Two icon defects fixed alongside: 59 of 61 SVG glyphs rasterized black (`currentColor` with no cascade to inherit from — now a white-alpha mask tinted per theme, which makes them theme-aware for free), and anti-aliased edges carried a dark halo from double premultiplication. A new test, `every_icon_name_in_the_ui_resolves`, scans the source for icon-name literals and fails the build if any resolves to no asset

### Fully Implemented -- Reliability

- **Panic-free time arithmetic** *(0.14.0, source only)*: `src/monotonic.rs` (85 lines, 3 tests) with 19 call sites across `engine.rs`, `network_monitor.rs`, `smart_history.rs`, `detection.rs`, `token_meter.rs`, `behavioral_mimicry.rs`, `sandbox/{quarantine,popup}.rs`, and `ui/{network_bar,popup}.rs`. `Instant - Duration` panics when the result predates the clock epoch, and on Windows that epoch is system boot — so **launching the browser within five minutes of a reboot aborted the process**, which is the behaviour in the shipped v0.13.1 binary. `monotonic::ago(d)` clamps to process start instead, which is also the semantically correct answer for cutoffs that prune this process's own records. Project rule: never write `Instant::now() - d` directly

### In Progress -- Compiles, Wiring Unfinished

- **File sidebar** *(post-0.13.2, source only)*: `src/files/` (5 files, **3,959 lines, 36 tests** — down from 4,346 / 39, with no cause identified), added 2026-08-17. An Explorer/Finder replacement inside the browser chrome: three views over one row set (`Tree`, `Details` Finder-style columns, `Timeline` reverse-chronological feed), a filter query language with highlight rules, per-root view/edit permission modes, and an optional SQLite index for whole-drive search with background scan progress. The panel returns a `FileAction` (open as `file://` in a tab, or hand to the OS default application) rather than navigating inline. Reachable from the toolbar `files` button and the `view.files` command. **The mutating surface is now live on Edit roots** *(source, uncommitted)*: New Folder creates a uniquely named folder in the cwd; Rename opens an inline field (Enter commits, Esc cancels); Delete is a two-click confirm on the selection. `can_edit_cwd` — reported deleted in the prior edition — is **restored and load-bearing**: View roots and mounted roots themselves refuse the mutation even where the OS would permit it. **Why it is still "in progress" rather than implemented:** the mutation paths have never run in a packaged binary, and a file-deletion gate that has never been exercised outside a dev build is not a finished capability
- **`paths.rs::temporary_fallback`** *(new this refresh)*: compiles, called by nothing — the single warning breaching the zero-warning gate. Wire or delete, and record which
- **`script_engine.rs` document-scope setters — resolved, resolution unrecorded.** `set_current_document` and `clear_current_document` no longer warn, so they were wired or deleted. **Which one is unknown, and it matters:** the 2026-06-10 audit flagged *"event-listener callbacks run with `CURRENT_DOC` unset (handler `getElementById` returns null)."* If these were wired, that finding is closed and nobody recorded it; if deleted, it is still open. One command settles it. **The project's rule is wire-or-delete *and record which*, and half of that rule was followed**
- **`script/` storage APIs behind suppressions** *(worsening)*: `#[allow(dead_code)]` went 14 → 20 → **27** across three refreshes. The prior edition's defence — an IndexedDB storage API written ahead of its call sites, *"defensible temporarily… a reason that expires"* — has had three weeks and the count grew by seven. **This is no longer a blip; it is the form the project's wire-or-delete debt is being carried in.** Each suppression should carry a note saying what it is waiting for
- **Twelve declared-but-empty modules** *(new this refresh)*: eleven in `js/` — `ast.rs`, `async_fn.rs`, `class.rs`, `collections.rs`, `error.rs`, `json.rs`, `number_ext.rs`, `object.rs`, `promise.rs`, `strict_mode.rs`, `string_ext.rs` — plus `paint_backend.rs`. Four or five lines each, a copyright header and one doc line, **zero code; 49 lines total**. `js/mod.rs` declares the eleven under *"ES2015+ feature modules (per web-browser-completion spec)"*, so the directory advertises an ES2015 module layout that does not exist; the functionality is real and lives in `interpreter.rs`. The same consolidation that deleted four byte-identical placeholders in `script/` left these. They are reachable, so the reachability walk reports them as wired — which is the blind spot worth naming: **a walk that counts `mod` declarations cannot tell a wired module from an empty one**
- **Notification queue** (`src/notify.rs`) — **deleted 2026-09-02.** A process-wide toast queue that was populated and drained by nothing. Rather than build the toast surface, the queue was removed; it can be reintroduced with its consumer when a toast surface is actually designed
- **Local feature-unlock scaffold** *(correction)*: the prior edition recorded `src/features.rs` as deleted 2026-09-07. **It is present, 91 lines, 0 tests** — the deletion claim was an artifact of measuring a tree 23 commits behind `origin/main`. The Print-to-PDF soft-gate is gone and PDF export is free; the scaffold file itself remains and was never an entitlement system. Delete it or decide it has a purpose
- **Speech-to-text** *(rebuilt 2026-10-05 behind the off-by-default `whisper` feature; the "green-field task" note in the prior edition is superseded)*: `voice.rs` is back to **1,347 lines with 24 tests**, all passing. `WhisperEngine` has `load`, `transcribe`, `transcribe_file` and a `Drop` that frees the context, over a hand-written C shim (`whisper/whisper_wrapper.c`, 3,453 bytes) that keeps whisper.cpp's large versioned `whisper_full_params` struct on the C side where the compiler checks it — no `bindgen`, no `cmake`, three `extern "C"` functions. `src/whisper_ffi.rs` is 50 lines; `mod whisper_ffi;` is in `main.rs`. `fn transcribe` now matches **three** times, not zero. `transcribe_file` decodes through symphonia (so any format the audio viewer opens can be transcribed), downmixes to mono, resamples to 16 kHz, and caps at ten minutes per call because whisper.cpp decodes at roughly real time on CPU with no cancellation. `resample_to_16k` averages each input group rather than decimating, recomputes group boundaries per output sample so a 44.1 kHz source distributes its remainder instead of drifting, and **refuses to upsample** rather than inventing detail an 8 kHz capture never contained. A real diagnostics panel now drives the app's own engine, replacing the probe that built a throwaway `WhisperEngine` every frame.

    **Why this is here and not under *Fully Implemented*, in four parts.** (1) **Off by default** — with the feature off, `load` and `transcribe` return an error naming exactly what is missing rather than reporting a success the engine cannot honour, and a test pins that. (2) **Unbuildable without unvendored upstream artifacts** — it needs whisper.cpp headers and prebuilt static libraries for the host target via `SASSY_WHISPER_DIR`, roughly 23 MB per target, not in the repository. (3) **It is an unverified port.** The shim and FFI come from `sassy-talks/android-native`, where the same pattern was written for Android ABIs **and is currently unwired**: that repo's `lib.rs` declares neither `whisper_ffi` nor `transcription`, and its `build.rs` ends with *"Whisper.cpp libraries removed — transcription stripped to slim down binary size."* It arrives here as a good design that had been stripped from its own build. (4) **No transcription has been verified against real audio** — 24 unit tests are not an accuracy measurement. **The honest claim is "built, off by default, unverified," and it is not a product capability until someone can turn it on without assembling upstream libraries first.**

    History, kept because it explains why the gate matters: until 2026-08-27 the gap was hidden by a ~126-line block in `render_voice_panel` that constructed the whole stack and ran its lifecycles with every binding discarded as `let _x =`, purely to keep dead-code warnings quiet. It sat on the paint path, so opening the panel re-ran it **every frame** — an OS thread and audio device handle per frame, and potentially a billable cloud transcription request per frame carrying the user's real API key. Removing it fixed that and exposed the gap; deleting the engine closed it; this feature-gated rebuild is the third act, and it is gated precisely so the first cannot recur. Note also what changed in kind: the removed path was **cloud** transcription carrying a user credential; this one is **on-device**, which is the better shape for the privacy claim in Security Posture

### Implemented -- Update Infrastructure (code complete; channel unpublished)
- Kali-style signed update stack designed and coded in-repo (Workers + R2; minisign + SHA-256)
- **Honesty:** public `/browser/dists/stable/manifest.json` returned **HTTP 404** on live check **2026-10-05** — unchanged for approximately **fourteen weeks**. The unsigned Windows **dev build** (44.38 MB, v0.13.1) may be linked separately. There is no working auto-update path for any user today

### Written But Not Compiled

**Empty for a second consecutive refresh. Zero files, zero lines.**

No `.rs` file under `src/` is unreachable. The reachability walk from the three binary roots (`main.rs`, `bin/sassy-ui.rs`, `bin/mcp-client.rs`) reaches all **258** files — and it now follows the five `#[path]` attributes in `bin/mcp-client.rs`, which the prior edition's walk did not. That change matters: **`src/mcp_client.rs` was listed as deleted last refresh partly because the walk could not see it.** It is present, and it compiles into the `mcp-client` CLI rather than into `sassy-browser`.

Three notes rather than a victory lap:

- **"Empty" now needs a footnote, because the walk has a blind spot.** **Twelve reachable files contain no code at all** — eleven in `js/` plus `paint_backend.rs`, 49 lines of header and doc comment between them. They pass a declaration-counting walk and fail the purpose the walk serves. A section headed *Written But Not Compiled* cannot catch *Declared But Not Written*, so those twelve are tracked under *In Progress* above.
- **The debt moved, it did not vanish.** Unwired lines and suppressed warnings are the same debt in two forms. Across the three refreshes that took unwired code from 8,831 lines to zero, `#[allow(dead_code)]` suppressions went 14 → 20 → **27**. Chapter 03 tracks the suppression count as a standing line item for exactly this reason.
- **This refresh ran the trade in reverse, and it is the best version of it.** The prior edition's concern was 8,831 lines moving from *unreviewed and unreachable* to *unreviewed and on a live path*. This refresh moved **14,937 lines out of the compiled tree entirely** — the bytecode VM, unreviewed and unreachable, now simply absent. Against that, userscripts and extension content scripts moved **into** the live path. The unreviewed total is flat at ~25,000 lines; the composition is worse, because what left could not reach a page and what arrived executes third-party script in the user's authenticated session. Chapter 04 rates those two first in the next audit's scope.

**Removed from this list (2026-09-07), with corrections:** `src/userscripts.rs` was deleted rather than wired — and has since been **rewritten and wired** (see *Implemented -- Userscripts*). `src/viewers/userscripts.rs` remains absent. **`src/mcp_client.rs` was not deleted** — it is present and reachable through a `#[path]` attribute the walk was not following. The `mcp-client` binary still ships from `src/bin/mcp-client.rs`.

**Removed from this list (earlier):** `src/viewers/presentation/` was listed here in the 2026-08-16 binder as unwired. It is wired and compiled — the sibling `presentation.rs` file was deleted, so `pub mod presentation;` resolves to the directory. It has moved up to *Fully Implemented — File Viewers*.

### Partial / Stubbed
- Private/incognito mode: separate cookie jar + storage partitions (cleared on exit); not full Chromium-parity private profile
- AbortController wired; MutationObserver delivers coarse childList records on egui tick after `observe()` (Layer C) — not full spec
- Image/PDF editors: deep viewer+edit paths shipped; crypto signatures / built-in OCR still open
- PPTX/ODP viewer: the `viewers/presentation/` rewrite is now the live path (above). Legacy `.ppt/.pps/.pot` is **text recovery only** and Keynote is **preview recovery only** — neither is a full render. Master-slide theme inheritance, transitions, animations, charts, and SmartArt remain unclaimed pending verification against real decks; the module has no audit coverage
- **Spreadsheet formulas — substantially upgraded, still not Excel parity.** The live path is now `viewers/formula/`: 255 named functions, a real lexer/parser/evaluator, a typed `CalcError`, a `CellResolver` that makes unsaved edits visible to every formula, and 64 passing tests covering precedence, absolute/mixed references, lazy `CHOOSE`, blank-versus-zero comparison, aggregate handling of text in ranges, circular-reference termination, array literals and broadcasting, and financial cash-flow analysis. **What is still unclaimed:** 255 functions is not the roughly 500 of modern Excel; structured (table) references and cross-sheet references are unverified; `functions/stat.rs` is 1,441 lines carrying no tests of its own; and no round-trip verification against real-world `.xlsx` workbooks has been performed. **Do not state or imply Excel parity.** The honest claim is "a 255-function formula engine, parity unverified"
- HTTP/3 (QUIC): disabled toggle in the transport-stack diagnostics with footer documentation; QUIC pipeline not yet wired
- `is_tailscale` IP-octet helper still load-bearing across `sync/family.rs` / `sync/secure.rs` callers -- rename to `is_overlay_peer` queued (CGNAT 100.x check unchanged)
- macOS / Linux installer plumbing: macOS build is not sufficiently building yet; installer work deferred until then

### Not Implemented

*Two entries left this list this refresh. **Voice transcription** moved up to* Partial / Stubbed *— built behind an off-by-default feature, unverified. **User script execution** moved up to* Implemented -- Userscripts *— wired, 15 `GM_*` APIs, 8 passing tests. The statement "no compiled `GM_*` grant surface, no script-injection path" is withdrawn; the tree now has two such paths, counting extension content scripts.*

- `<video>` element playback (file-level video viewer exists; in-page HTML5 video does not)
- **A faster JS runtime.** The half-built bytecode VM that used to stand in this position was deleted 2026-10-05 without ever being DOM-wired. There is no partial implementation to finish
- **WebSocket connections.** `WebSocket` constructs and exposes its full surface, but `readyState` is always `CLOSED` and `send`/`close` are no-ops — a deliberate, test-locked stub (`wpt_subset::wpt_websocket_no_throw_on_construct_and_send` asserts `readyState === 3`). Making it live means a persistent `tokio-tungstenite` stream pumped onto the main-thread event loop, as async `fetch` already is; it is a feature decision, not a bug fix
- WebGL rendering context
- WebRTC
- ServiceWorker
- Variable-font axis instancing (TTF/OTF/WOFF1/WOFF2 `@font-face` now shipped)
- GPU (`vello`/`wgpu`) render path -- all painting is currently CPU software rasterization
- Multi-process sandbox isolation
- Full CSS media-query property coverage (some `@media` rules parse but only a subset of feature predicates resolve)

## 6-Month Plan (v1.0 -- "Load Most Real Websites")

### Q3 2026

**Closed since the 2026-09-14 refresh:**

- **Commit and push the working tree, then reconcile with `origin/main`. DONE — and it was the single highest-priority line in this binder.** PR #51 merged the working branch into `origin/main` on 2026-10-02 (`543b8a6`, *"Land the data room refresh and viewer printing from `chore/egui-0.35-migration`"*). `HEAD` is now **7 ahead / 0 behind** with **6 files uncommitted**, against 0/23 and 72 three weeks ago. The formula engine is committed and on a remote. A disk failure no longer costs the quarter.
- **Resolve the two `script_engine.rs` warnings. DONE, but the record was not kept.** They are gone from the warning list. **Whether `set_current_document` / `clear_current_document` were wired or deleted is unknown**, and the item explicitly required recording which — so it is closed as code and **re-opened as a record below.**
- **Re-score the full suite. DONE, and green:** 2,586 passed / 0 failed / 19 ignored (2,605 run, 7.65s) on 2026-10-05, against a tree that had just deleted an entire JavaScript engine. **−59 passing**, tracking the VM's departed tests.
- **Decide the bytecode VM question. DONE, by deletion.** The old item read "mature the bytecode VM toward becoming the default runtime." The 2026-08-08 consolidation audit found it had never been DOM-wired and recommended removal; 14,937 lines across 22 files went. **Closing an item by deciding against it counts, and is recorded as such rather than as a completion.**
- **Merge and measure the extension content-script path. DONE for the first two of three.** It is in the measured tree (`app.rs:2044`, `engine.rs:914`). **Still unreviewed.**
- **Add tests to `app/browser_ui.rs`. IN PROGRESS, real movement:** 5 → **16**. And `viewers/spreadsheet.rs` 6 → **41**, which is the test coverage the formula engine's call site had been missing.

**Open, in rough order of consequence per unit of effort:**

- **Package and publish. This is now the single highest-priority line in this binder**, inheriting the position from the version-control item that closed. Nothing has shipped since 2026-07-28 — **ten weeks**. The gap between the shipped binary and the source now spans the reboot crash fix, the Office-save corruption fix, the Windows icon/version/DPI resources, the Nova theme, the presentation viewer, the file sidebar, twelve viewer write paths, the formula engine, extension content scripts, the Android libc++ fix, the userscript manager, viewer printing, the unified MCP protocol, and the Browser Control privilege gate. **Every existing user is running a binary with all of those defects and none of those features, and it crashes if launched within five minutes of a reboot.** Even the local release build (56.59 MB, 2026-09-08) predates everything in *newly landed* above. The tree compiles with one warning and the suite is green: **what is missing is a release build, not engineering**
- **Reconcile version, tags and CHANGELOG — the mismatch inverted rather than resolved.** Progress: the CHANGELOG **now has a `[0.15.0] - unreleased` section**, and the duplicate `[0.14.0]` heading is gone. Remaining: `Cargo.toml` says **0.15.0**, the newest tag reachable from `HEAD` is **v0.14.1**, and a loose tag **`v0.15.2` exists that `HEAD` does not contain** (12 ahead / 1 behind) with **no CHANGELOG section for 0.15.1 or 0.15.2** and a `origin/release/v0.15.2` branch. The old rule was "a version with no section, no tag and no artifact is a build identifier"; the new case is its mirror — **a tag with no version, no section, and no commit in the development line.** Decide which number is real and make the four sources agree
- **Record whether `set_current_document` / `clear_current_document` were wired or deleted.** One command. **If they were wired, a 2026-06-10 audit finding — *"event-listener callbacks run with `CURRENT_DOC` unset"* — is closed and nobody knows it.** The project's wire-or-delete rule requires the record, not just the resolution
- **Retire the suppressions, which are now a trend rather than a blip.** `#[allow(dead_code)]` went 14 → 20 → **27** across three refreshes while the warning count sat near zero. The prior edition called the `script/` cluster defensible *"for a reason that expires"*; it has had three weeks and grew by seven instead. Each should carry a note saying what it is waiting for
- **Commission a new independent audit — sixteen weeks, and the composition of the unreviewed surface got worse this refresh.** The total is flat at roughly 25,000 lines only because the VM deletion subtracted about as much as userscripts, extensions, printing and the voice FFI added — and **what left could not reach a page, while what arrived executes third-party script in the user's authenticated session.** Revised scope, in risk order: **(1) the two script-injection paths — userscripts (`GM_*`) and extension content scripts**, newly at the top, between them 10 tests and zero review; (2) `viewers/presentation/` (fuzz malformed decks); (3) `viewers/formula/` (fuzz hostile expressions, oversized ranges, recursion depth, numeric overflow); (4) the `src/files/` mutation gate (symlink/junction/`..` traversal out of a granted root); (5) the twelve viewer write paths plus the new print paths; (6) the Browser Control gate and MCP protocol 3; (7) the build tooling. The `whisper` FFI is deliberately excluded while it stays off by default and unbuildable without upstream libraries
- **Delete or wire the twelve empty modules.** Eleven in `js/` plus `paint_backend.rs` — 49 lines, comments only, zero code. `js/mod.rs` declares the eleven under *"ES2015+ feature modules (per web-browser-completion spec)"*, so a reader assessing ES2015 coverage counts eleven feature modules and finds eleven empty files. The same consolidation deleted four byte-identical placeholders in `script/`; these were spared. Small, and exactly the kind of documentation-by-filename that this binder exists to catch
- **Verify the userscript manager against real userscripts**, and decide whether to claim any compatibility at all. 15 `GM_*` grants, `@require`/`@resource` unverified, no round-trip against anything from Greasyfork
- **Either finish the `whisper` feature or decide not to.** It cannot be built without assembling ~23 MB of upstream static libraries per target, it is an unverified port from a repo where the same code is unwired, and no transcription has been checked against real audio. **Vendoring a build recipe or a CI step would make it testable; leaving it as-is makes it a feature nobody can turn on**
- **Round-trip test the twelve write paths, and add the spreadsheet to that list.** `f834f8c` fixed a save path that silently destroyed Office documents; twelve more write paths landed the next day with no equivalent verification, and the spreadsheet's calculation core has now been swapped underneath its save path
- **Verify the formula engine against real workbooks.** 64 unit tests pass. No `.xlsx` round-trip has been performed, `functions/stat.rs` (1,441 lines) carries no tests of its own, and structured and cross-sheet references are unverified. Until that work is done the claim stays "255-function engine, parity unverified"
- **Publish the signed stable manifest.** The update stack is coded; the endpoint has been 404 for roughly **fourteen weeks** (re-confirmed live 2026-10-05). Until it is live, every install is a manual download with no update path
- **Sweep for other panicking standard-library patterns.** The `Instant - Duration` defect was a whole-codebase pattern invisible to the type checker and to any test not run on a freshly booted machine. Slice indexing, unsigned subtraction, and `unwrap` on time conversions deserve the same audit
- **Decide what "Pro" means for real billing.** Print-to-PDF soft-gate removed; remaining Pro lines (cloud sync, multi-provider AI, team vault) still need a real entitlement mechanism before any paid claim
- Close the critical/high correctness findings from the 2026-06-10 audit (JS `===`/equality, parser gaps for arrow/destructuring/switch, CSS shorthand ordering + full inheritance, cookie SameSite/Domain validation, DOM-event `CURRENT_DOC` scoping, navigation registry cleanup)
- Keep growing the WPT-subset (102 attributes present) + live smoke toward broad real-site coverage. **Score and publish an actual WPT pass rate** — attribute count is not a conformance number. *(The companion item "mature the bytecode VM toward becoming the default runtime" is removed: the VM was deleted 2026-10-05 without ever being DOM-wired.)*
- **Keep adding tests to `app/browser_ui.rs`.** It went 5 → **16** this refresh, on the largest file in the codebase (21,421 lines). `devtools/` (1,349 lines, 0 tests) and the newly-arrived `app/explorer_ui.rs` (1,138 lines, 0 tests) are the same problem at smaller scale. *(`js/compiler.rs`, previously listed here at 2,996 lines and 0 tests, was deleted with the VM — the worst case on this list closed by removal rather than by testing.)*
- **Audit the build tooling.** The `build.rs` resource failure was silent for the life of the project because a warning was printed instead of raised. Other swallowed failures in the build scripts should be assumed to exist until someone has looked
- **Separate `dist/` from runtime cache.** The release directory holds four shipped `.exe` files mixed in with a large number of base64-named cached web assets from a browsing session. Worth cleaning before `dist/` is shown to anyone
- Media Queries 4/5 evaluator and WOFF2 decoding have shipped; next: `(update)`/`(scripting)` driven by real engine state and variable-font instancing
- Stand up a GPU render path (`vello`/`wgpu`) -- the live painter is CPU-only today
- Wire remaining format viewers into tab dispatch (JPEG-XL, DicomViewer multi-frame)
- Rename `is_tailscale` -> `is_overlay_peer` across sync/

### Q4 2026
- `<video>` element with symphonia/rodio playback
- CSP (Content Security Policy) enforcement
- Cookie partitioning for incognito mode (complete the partial)
- **Extension framework (load/unload/sandbox)** — **substantially pre-empted and now measured.** Content scripts are wired into the live render pipeline with per-navigation injection, in this tree: `mod extensions;` at `main.rs:148`, `ExtensionManager` in `browser_core.rs` and `engine.rs`, `get_content_scripts(url)` at `app.rs:2044` and `engine.rs:914`. `extensions.rs` is 522 lines with 2 tests. **The "not in the measured tree" caveat is withdrawn; "unreviewed" stands, and it is first-equal in the next audit's scope** — this is a code-execution-into-page path. What remains for the *framework* item proper: load/unload lifecycle, a sandbox boundary, and permission prompts
- **Android build** — the libc++ linker-gap fix (`bafdec5`, v0.14.2) is now in the measured tree. **Still not packaged**, and no Android artifact has ever been produced
- Linux .deb/.AppImage packaging
- macOS .dmg packaging (after build pipeline stabilizes)
- Authenticode-signed Windows installer
- HTTP/3 (QUIC) -- flip the disabled toggle
- **Excel-compatibility verification for the formula engine** — structured references, cross-sheet references, `.xlsx` round-trip against real workbooks, and tests for `functions/stat.rs`. Only after that does the parity conversation become available

## 12-Month Plan (v1.5 -- "Daily Driver Candidate")

### Q1 2027
- ServiceWorker support (offline-capable sites)
- WebRTC (basic peer connections)
- Multi-process sandbox model
- Sync socket mode over WireGuard
- Cloud sync for Pro tier

### Q2 2027
- WebGL 2.0 context
- SPA framework compatibility (React, Angular, Vue, Svelte)
- Performance profiler in DevTools
- Enterprise policy management
- Institutional licensing portal

## Long-Term Vision (18+ months)

- Mobile companion (native Android/iOS, not just PWA)
- WebGPU support
- Custom DNS-over-HTTPS resolver
- Marketplace for verified extensions
- AI agent orchestration platform (browser as the AI's eyes and hands)
