<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-DPTVF4HHRZQ7
-->
# Team & Organization

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16**

---

## Founder

### Shane Smith -- Founder & CEO

- **Military:** 11 years U.S. Army / National Guard -- Chemical Warfare Officer
- **Education:** B.S. Chemistry, University of Wisconsin-Eau Claire
- **Technical:** Sole developer of the entire 322,386-line compiled Rust codebase (291 files; compiled and in-tree are the same set as of 2026-10-05)
- **Security:** Background in chemical/biological threat analysis directly informs the security-first architecture
- **Location:** Prairie du Sac, Wisconsin

Shane built Sassy Browser from first commit (December 22, 2025) to its current state in roughly 9 months as a solo developer. The codebase spans a custom HTML/CSS renderer, a JavaScript engine, 200+ file format viewers (including 5 CAD interchange formats added in v0.10, a full presentation stack rewritten in August 2026, a 255-function spreadsheet formula engine wired in September 2026, and printing across the scientific and CAD viewers in October), cryptographic subsystems, a file-manager sidebar with its own search index and mutation gate, a userscript manager with a `GM_*` API, a full MCP orchestration platform with Control Center, signed update infrastructure, a WireGuard-first device sync stack, and a bespoke claymorphic design system with a WCAG-AAA contrast mode -- all in pure Rust with zero external browser engine dependencies. The 2026-05-25 warning-sweep audit took the workspace from 231 compiler warnings to 0 while wiring every previously-suppressed dead-code item into either a real chrome surface or an honest delete.

**The founder-concentration risk, stated plainly.** One person holds all architectural context for 322,386 lines across a browser engine, a JavaScript runtime, a cryptographic stack, a file manager, a spreadsheet formula engine, two script-injection paths, and an MCP server. There is no second reviewer, and the symptoms are visible in the codebase today:

- **This binder described a shipped capability for four consecutive editions that the code did not have.** The SassyScript bytecode VM appeared under *Fully Implemented* in chapter 07, in chapter 02's module table and JS Engine section, and as the basis of chapter 04's no-JIT claim. It has been deleted — 14,937 lines across 22 files — and `"use vm"` matches zero times in `src/`. **Cross-chapter consistency checking could never have caught this: every chapter agreed, consistently, and all of them were wrong.** It was found by re-measuring the repository, which is exactly the check a second engineer performs for free by asking "when was that last actually used?"
- **Two features were listed in this binder as shipped with no compiled code behind them** — a user script manager and a voice transcription pipeline. Both survived at least three refreshes before being withdrawn in August 2026. Both were found by re-deriving module reachability programmatically rather than by reading the documents.
- **And the reciprocal happened this refresh: both of those withdrawn claims are now true again, and the documents did not know it.** A real userscript manager with 15 `GM_*` APIs has been wired on the live navigation path, and speech-to-text has been rebuilt behind an off-by-default feature. **Three weeks of correct capability went unclaimed while the binder carried an obsolete withdrawal.** The absence of a second reader costs accuracy in both directions, which is the part that is easy to miss: a solo founder's documentation drifts behind his own work as readily as ahead of it.
- **The reachability walk this binder relies on had a bug for at least one refresh.** It did not follow `#[path]` attributes, of which there are five in `bin/mcp-client.rs`. That is why the 2026-09-14 edition reported `src/mcp_client.rs` as deleted: it is present, and compiles into the CLI binary. A measurement tool with a blind spot, used by the only person who could notice the blind spot, is the single-pair-of-hands risk applied to the instruments rather than the code.
- **Twelve declared modules in the tree contain no code at all.** Eleven in `js/`, declared under a comment reading *"ES2015+ feature modules (per web-browser-completion spec),"* plus `paint_backend.rs` — 49 lines of header and doc comment, zero implementation. The same consolidation pass that deleted four byte-identical placeholders in `script/` left these eleven. It is a small thing that a reviewer catches in a diff and an author does not catch in his own.
- **A dead-code suppression was doing real damage on the render path for months.** To keep the voice module's warnings quiet, a block in `render_voice_panel` constructed the whole voice stack and ran its lifecycles every frame the panel was open — spawning an OS thread, opening the audio device, and potentially issuing a billable cloud API call with the user's key, per frame. That is the specific failure mode of working alone: a shortcut taken to satisfy a self-imposed quality gate, with no one to say "that runs in the paint loop."
- **Suppression debt has nearly doubled in three weeks and nobody flagged it but the weekly refresh.** `#[allow(dead_code)]` went 14 → 20 → **27** while the compiler warning count sat at 2, then 1. A codebase with one warning and 27 suppressions is not quiet; it is one whose noise has been moved where the gate does not look. The prior two editions each called the newest batch "defensible temporarily, for a reason that expires." The reason has not been cashed.
- **A resolved warning went unrecorded, and the record was the point.** `set_current_document` / `clear_current_document` no longer warn, so they were wired or deleted. **Which one is unknown.** The 2026-06-10 audit flagged event-listener callbacks running with `CURRENT_DOC` unset; if those functions were wired, that finding is closed and nobody wrote it down. The project's own rule is wire-or-delete *and record which*, and half of it was followed.
- **No independent audit in sixteen weeks**, while two script-injection paths — the userscript `GM_*` surface and extension content scripts — went live in the measured tree carrying 10 tests and zero review between them. A new audit artifact does exist (`audits/2026-08-08-js-engine-consolidation-and-efficiency.md`, landed 2026-10-02) and it drove the VM deletion, but **it is a self-audit written in the same week as the change it approves.** Counting it as coverage would be the exact category error this binder exists to prevent.
- **Nothing has been packaged since 2026-07-28 — ten weeks.** v0.13.2 through 0.15.0 exist in source only, and the local release build (2026-09-08) already predates the VM deletion, userscripts, viewer printing, and the MCP protocol-3 work. The tree compiles with one warning and the suite is green, so **what is missing is a release build, not engineering.**
- **A tag exists with no release behind it.** `v0.15.2` is tagged at a commit `HEAD` does not contain, with no CHANGELOG section for 0.15.1 or 0.15.2 and `Cargo.toml` saying 0.15.0. The prior mismatch — a version number with no tag — has partly resolved into its mirror image.
- **Every Windows build ever shipped lacked an icon, version metadata, and DPI awareness**, because a build-script warning was printed instead of raised. Found 2026-08-27, after roughly eight months of releases.
- **The shipped browser crashes on launch within five minutes of a reboot.** Nineteen sites wrote `Instant::now() - d`, which panics when the result predates the clock epoch — and on Windows that epoch is boot. Found and fixed 2026-08-31; present in every packaged binary. A second reviewer is not guaranteed to catch this either, but a test run on a fresh VM is, and that is a process the hire brings.
- The signed update endpoint the update code targets has been 404 for approximately **fourteen weeks**.
- A save path that silently corrupted DOCX/XLSX/PPTX files shipped and survived until 2026-08-16. Found by the founder, not by a test or a reviewer.

**The counter-evidence, which belongs in the same list — and this refresh supplies the strongest instance of it yet.** When a problem is named in this binder it does get closed.

**The item that dominated the last two editions is closed.** "Commit and push the working tree, then reconcile with `origin/main`" was described on 2026-09-14 as *"the single highest-priority line in this binder"* — 23 commits behind the remote, 72 files uncommitted, the quarter's best work on one laptop. PR #51 merged the branch into `origin/main` on 2026-10-02. The tree is now 7 ahead, 0 behind, 6 files uncommitted. **A disk failure no longer costs the quarter.**

**And the largest deletion in the project's history came out of the founder's own audit habit.** The bytecode VM had been carried as an asset in four editions of this binder. A self-audit found it had never been DOM-wired, could not touch the page, had zero production callers, and cost compile time and binary size for nothing — and recommended removing it. 14,937 lines went. **Deciding against your own 15,000 lines of work is a harder call than writing them**, and it is evidence that the self-review, whatever it cannot substitute for, is not self-congratulatory.

Alongside: the full suite came back **2,586 passed / 0 failed / 19 ignored** against a tree that had just deleted an entire JavaScript engine and added two script-injection paths. `app/browser_ui.rs`, the file this list called untested for months, went from 5 tests to **16**. `viewers/spreadsheet.rs` went from 6 to **41**, finally testing the call site of the formula engine wired three weeks earlier. Privileged MCP commands moved behind a user-held switch with **a test that fails the build if the UI advertises a gate the code does not enforce** — which is the right shape for a security control and is not an obvious thing for a solo engineer to build for himself. And a `diagnostics` feature now walls off probe panels that were printing identity keys and recovery keys in default builds.

None of the items in the risk list are hard problems. Every one is the queue that forms behind a single pair of hands — and the pattern across the last three weeks is that this founder *can* clear the largest item on it decisively, including by deleting his own work, but not hold every item cleared at once. Note also what the list does not contain: the engine architecture is sound, the memory-safety property holds, the suite is green, and every finding here was surfaced by the founder's own process and published rather than buried. The senior Rust hire below is the direct mitigation, and this list is a fair test of whether the hire pays for itself.

## Current Infrastructure

| System | Role |
|--------|------|
| Lenovo LOQ Windows 11 workstation ("Admin") | Primary development workstation |
| Kali Linux home server ("yomama", Tailscale 100.99.213.97) | Development / testing / Aegis AI orchestration |
| Samsung Galaxy S24 Ultra ("Brick 2.0") | Mobile testing device, SDR rig |
| Cloudflare Workers + R2 | Update server, sassyconsultingllc.com, MCP OAuth |
| GitHub (sassyconsultingllc/ACE) | Source repository — **private**; returns 404 unauthenticated (re-confirmed 2026-10-05 from the workstation's own network). Diligence access by invite. Working-tree `HEAD` is `0f60c30` (2026-10-04) on `chore/egui-0.35-migration`, **fully pushed**; `origin/main` is `543b8a6` (2026-10-02) and `HEAD` is **7 commits ahead of it, 0 behind**, with **6 tracked files uncommitted** |
| WireGuard mesh + Cloudflare Tunnel | Primary device-sync transport |

## Hiring Plan (Post-Seed)

### Immediate (Months 1-3)

**Senior Rust Engineer**

- Focus: Browser engine rendering pipeline -- closing 2026-06-10 audit correctness findings and standing up a GPU (vello/wgpu) render path over the current hand-rolled CPU painter
- Secondary, and immediately valuable: **own release and review.** The integration half of this role got materially smaller on 2026-10-02 when the branch merged into `main` — which is worth saying, because it means the hire starts on product rather than on cleanup. What remains: **cut a release** (ten weeks and counting, with a green suite and a one-warning tree, so this is process not engineering); make version, tag, CHANGELOG and artifact agree, including resolving the orphan `v0.15.2` tag; publish the signed update manifest; **be the second reader on the two script-injection paths before they ship** — the userscript `GM_*` surface and extension content scripts have 10 tests and no review between them; round-trip test the twelve viewer write paths and the new print paths; verify the formula engine against real `.xlsx` workbooks; retire the 27 `#[allow(dead_code)]` suppressions or document what each waits for; delete the twelve empty modules; record whether the `script_engine.rs` document-scope setters were wired or deleted; audit the build scripts for other swallowed failures; keep adding tests under `browser_ui.rs` and start on `devtools/` and `explorer_ui.rs`, which have none. **Most of this is not hard engineering — it is the work that only exists because one person cannot be both the author and the reviewer**, which is precisely why it is the fastest-paying half of this hire
- Requirements: Production Rust experience, familiarity with graphics programming or browser internals
- Compensation: $150-180K + equity

### Near-Term (Months 3-6)

**Frontend/UX Designer**

- Focus: egui UI polish, marketing site, product identity
- Requirements: Desktop application design experience, Figma proficiency
- Compensation: Contract, $80-120/hour

### Growth (Months 6-24)

**Business Development / Enterprise Sales**

- Focus: Institutional licensing (universities, research labs, enterprises)
- Requirements: SaaS/enterprise sales experience, ideally in academic or scientific markets
- Compensation: $80-100K base + commission + equity

## Advisory Network

- Security audit infrastructure: Mercury-2 (Inception's code-review model) -- 8 completed passes (Mercury-2 P1-P3, r3, r4, r5 render diagnosis, r7 render-collapse v1, r7 render-collapse v2)
- xAI audit completed April 2026
- Final warning-sweep + real-feature wire-up audit completed 2026-05-25 (231 warnings -> 0)
- Multi-agent full-codebase audit completed 2026-06-10 (19 subsystem auditors, 240 confirmed findings) -- now driving the correctness work plan
- **A new audit artifact landed 2026-10-02** — `audits/2026-08-08-js-engine-consolidation-and-efficiency.md`, the first file in `audits/` since 2026-06-15. It drove the bytecode-VM deletion and corrected a set of stale "stub" labels on `Map`/`Set`/`URLSearchParams`. **It is a self-audit, not a commissioned independent review**, and it is counted here as evidence of process rather than as audit coverage
- **No independent audit has been commissioned since 2026-06-15 — sixteen weeks.** Re-audit is queued in the Q3 2026 roadmap block, and its scope was re-prioritised this refresh: the **two script-injection paths now rank first** — the userscript `GM_*` surface and extension content-script injection, both in the measured tree, both executing third-party code against the user's authenticated pages, with 10 tests and zero review between them. Then the unreviewed `viewers/presentation/` parser, the `viewers/formula/` engine, the `src/files/` mutation gate, the twelve viewer write paths plus the new print paths, the Browser Control privilege gate and MCP protocol 3, and the build tooling
- DevToolAngels investor engagement (in progress)
- David Mytton follow-up (in progress)

There is no formal advisory board, no board of directors, and no outside counsel of record. "Advisory network" above describes audit tooling and investor conversations, not seated advisors with equity or fiduciary duty.

## Corporate Entity

**Sassy Consulting LLC**
- Jurisdiction: Wisconsin
- Structure: Single-member LLC (founder-owned)
- Website: sassyconsultingllc.com

---

**Contact:** Shane Smith | shane@sassyconsultingllc.com
