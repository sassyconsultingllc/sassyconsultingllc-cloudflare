<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-KM3FLLNBEEKS
-->
# Project Portfolio Status Report

**Snapshot:** 2026-11-16 · Madison / Prairie du Sac, Wisconsin · **Standalone** (not a DataROOM binder chapter)

> This report is the living portfolio inventory for external readers. Sassy Browser figures below are recounted as of 2026-10-05 and match DataROOM chapter 03, which is the authoritative source. Development-velocity figures are as of the 2026-08-15 git walk. Non-browser project **file counts** that still cite March 2026 were last fully walked on **2026-03-18** and should be re-verified before formal diligence distribution.

> **Scope of measurement — the warning that headed this report for two snapshots is gone.** `HEAD` (`0f60c30`, 2026-10-04) is **7 commits ahead of `origin/main` and 0 behind**, with **6 tracked files uncommitted** — against 0-ahead / 23-behind and 72 uncommitted on 2026-09-14. PR #51 merged the working branch into `main` on 2026-10-02. **A clone of `origin/main` now reproduces these figures to within a week of ordinary work.**

> **Build state:** `cargo check --release` as of 2026-11-16 — **0 errors, 0 warnings, 27.27s**. The zero-warning gate is **fully restored and clean**.

---

## Executive summary

Sassy Consulting LLC is a veteran-owned cybersecurity and software firm. The portfolio spans a pure-Rust desktop browser, Android / desktop communications, security monitoring, forensics, client web properties, and an AI tooling layer (SassyMCP) that multiplies a single-founder build cadence.

**Lead product — Sassy Browser v0.15.0 (source) / v0.13.1 (packaged)**

| Metric | Value |
|--------|------:|
| Compiled Rust lines (`src/`) | 322,386 |
| Total lines in tree | 322,386 |
| Compiled source files | 258 |
| Files in tree but not compiled | **0** (second snapshot running) |
| Declared modules containing no code | **12** (49 lines, comments only) |
| `#[test]` attributes (all compiled) | 2,608 (**−58**, the VM's tests left with it) |
| Full suite (2026-11-16) | **3,099 test attributes / 0 failed / 19 ignored** |
| WPT subset attributes | 102 (no pass rate claimed) |
| Windows x64 packaged binary | 44.38 MB (v0.13.1, 2026-07-28) |
| `cargo check --release` (2026-11-16) | **0 errors, 0 warnings (clean gate)** |
| Working-tree `HEAD` | `0f60c30` (2026-10-04) — **fully pushed** |
| `origin/main` | `543b8a6` (2026-10-02) — **`HEAD` is 7 ahead, 0 behind** |
| Uncommitted locally | **6 tracked files** |
| Ask | $800K SAFE / 24-month runway |

*Superseded LOC figures: 225,307, 224,732, 228,000, 241,730, 244,566, 243,543, and 253,944. The first two came from a blank-line-skipping counter that also included files the compiler never builds. The 228,000 figure used the right convention but mis-classified `src/viewers/presentation/` as uncompiled. Each later figure was correct for its tree. DataROOM chapter 03 documents each correction.*

Public **signed** update channel remains gated (`/browser/dists/stable/manifest.json` → 404, re-confirmed live 2026-10-05, approximately **fourteen weeks**). An unsigned Windows **dev build** (`274877db`) is published for evaluation. **Nothing has been packaged since 2026-07-28 — ten weeks**: v0.13.2 through 0.15.0 all exist in source only, and a local 56.59 MB release build has sat unpublished since 2026-09-08 — predating the VM deletion, the userscript manager, viewer printing and the unified MCP protocol. The rewritten presentation viewer, the file-manager sidebar, the Sassy Nova theme, the formula engine, the userscript manager and viewer printing appear in **no packaged binary**. The tree compiles with one warning and the suite is green, so **what is missing is a release build, not engineering.** Live site smoke: **2 pass · 5 partial · 3 fail** (see product truth layer).

**A capability claim was withdrawn on 2026-10-05: the SassyScript bytecode VM.** It appeared in this report and in four DataROOM chapters as a shipped, opt-in execution path. It is deleted. **Cross-chapter consistency checking could never have caught it — every document agreed, consistently, and all were wrong.** It was found by re-measuring the repository.

**Two capability claims withdrawn on 2026-08-31 were restored on 2026-10-05.** A user script manager and voice transcription, neither backed by compiled reachable code at the time, each having survived at least three refreshes before withdrawal. **Both are now backed by code** — the userscript manager fully, speech-to-text behind an off-by-default feature with four stated limits. **Restoring a claim is as much a correction as withdrawing one**, and the measurement discipline cuts in both directions.

**A version-control claim withdrawn on 2026-09-14 is now wholly historical.** Prior snapshots reported the local branch as ahead of origin and unpushed; it was fully pushed and `origin/main` was 23 commits ahead. **The two lines were merged on 2026-10-02**, so neither the original claim nor its inversion describes the tree any more.

---

## Development posture

All original software is primarily Rust, TypeScript, Kotlin, and Python, with web surfaces on Cloudflare Workers. Development is founder-led with AI-assisted workflows (Claude / Cursor / Copilot) coordinated through **SassyMCP**.

**SassyMCP v1.14.4** — production MCP server (~4,000 Python modules/files in tree) used daily for desktop automation, Android control, GitHub ops, memory/handoffs, and security audit tooling. Open source: `github.com/sassyconsultingllc/SassyMCP`.

## Development velocity

**As of 2026-08-15.** Measured from git history (commits + insertions/deletions), not file mtimes. Chart: `dev_velocity_4k.png` (regenerated via `dev_graph.py`).

| Repo | Last commit | Commits (≈72h) | Commits (30d) | Lines ± (30d) |
|------|-------------|----------------:|--------------:|---------------|
| SassyTalkie | 2026-08-15 | 1 | 17 | +22,425 / −4,900 |
| SassyMCP | 2026-08-14 | 4 | 22 | +14,309 / −2,289 |
| Scout | 2026-08-12 | 1 | 6 | +2,980 / −49 |
| ACE Browser | 2026-08-11 | 0 | 34 | +32,471 / −20,101 |
| Marketing site | 2026-08-02 | 0 | 13 | +2,416 / −1,180 |
| Riverview | 2026-07-06 | 0 | 0 | — |

**Read:** Across the six tracked repos above, the last 30 days show **~92 commits** and **~74.6k lines added / ~28.5k deleted**. Activity in the last ~72 hours concentrated on **SassyMCP** and **SassyTalkie**, with ACE Browser still the largest 30-day churn (egui migration / engine work). Riverview is quiet in this window; Guard / RACRUST were not on reachable git roots for this refresh.

![SaS development velocity — 3D daily adds + cumulative net lines](../docs/status/standalone-pdf/dev_velocity_4k.png)

Single-founder cadence with AI tooling (SassyMCP as force multiplier) remains the operating model.
---

## Portfolio overview

| Project | Status | Stack | Revenue path |
|---------|--------|-------|--------------|
| Sassy Browser | Active · v0.16.1 (322,386 LOC) | Rust | Freemium / family tier · pre-seed |
| SassyTalkie | Near-complete | Kotlin + Rust JNI | App stores |
| Guard Security System | Active | JS / C / Python / Rust | SaaS |
| WinForensics-Pro | Commercial Suite / Dual Engine | Rust | Tiered licensing |
| Foodie Finder | Complete | TypeScript / RN | App stores |
| Riverview Adventure Co. | Live | Rust / Workers | Client |
| SassyMCP | Production · v1.14.4 | Python | OSS / services |
| Consulting website | Live | HTML / Workers | Lead gen |
| SDR Radio Toolkit | Operational | Rust / config | Internal / consulting |
| CF Admin Mobile | Active | TypeScript / Expo | App stores |
| NetGuard Dashboard | Paused | TypeScript / React | SaaS (deferred) |
| WordPress plugins | Live | PHP / JS | Client |
| Security audit scripts | Complete | PowerShell | Consulting |
| RACRUST CMS | In progress | Rust / Workers | Client (consolidating) |
| Wyze NVR Integration | Active | Python / Docker | Internal / Guard |

---

## 1. Sassy Browser (lead)

**Status:** Active development · **v0.16.1 release** · repo `github.com/sassyconsultingllc/ACE` (**private** — 404 unauthenticated, re-confirmed 2026-10-05; working-tree `HEAD` `0f60c30` fully pushed, **7 commits ahead of `origin/main` (`543b8a6`) and 0 behind**, 6 files uncommitted locally)  
**Codebase:** 291 compiled `.rs` files · **322,386** compiled physical lines under `src/` (recount 2026-10-05) · **zero files present but unwired**, though 12 declared modules contain no code · `cargo check --release` **0 errors, 1 warning** · full suite **2,586 passed / 0 failed / 19 ignored**  
**Engine:** SassyScript tree-walking interpreter (23,079 lines in interpreter.rs), no JIT — **one engine.** The opt-in `"use vm;"` bytecode VM prior snapshots listed here was **deleted 2026-10-05** (14,937 lines / 22 files; never DOM-wired, zero production callers). **Boa removed** in 0.13.x. `js/builtins/` is **2 files, 237 lines** — the "14 modules" figure is withdrawn; twelve of them were VM machinery  
**Layout / paint:** Hand-rolled CPU page pipeline · chrome flex via `egui_taffy`

Privacy-first desktop browser with **zero Chromium**. Differentiating surfaces include native ad blocking, ChaCha20-Poly1305 password vault, fingerprint poisoning, family profiles, MCP Control Center, Web3 risk education, and 200+ in-app file viewers (PDF annotate, image edit tiers, DICOM, chemistry, CAD interchange, archives, ebooks — **not** claimed as Photoshop / Excel / Acrobat / ChemDraw replacements).

**Distribution honesty**

| Channel | State |
|---------|--------|
| Signed stable manifest | **404** (re-checked 2026-10-05, **~14 weeks**) — do not advertise public installers |
| Windows x64 **dev** build | Published · clean SHA `274877db` · 44.38 MB · unsigned · **v0.13.1** |
| v0.13.2 | Complete in source since 2026-07-31 · **not packaged, not distributed** |
| v0.14.0 | Complete in source since 2026-08-27, tagged, on `origin/main` · **not packaged, not distributed** |
| v0.14.1 / v0.14.2 / v0.14.3 | CHANGELOG sections dated 2026-09-01 / 09-05 / 09-05, **now present in the measured tree** · only v0.14.1 is tagged · **none packaged** |
| 0.15.0 | The version in `Cargo.toml`. **A CHANGELOG `[0.15.0] - unreleased` section now exists** — it did not last snapshot. **No reachable tag, no artifact.** Still a build identifier, not a release |
| **v0.15.2** | **A tag exists (`9645f4c`) that `HEAD` does not contain** (12 ahead / 1 behind), with a `origin/release/v0.15.2` branch and **no CHANGELOG section for 0.15.1 or 0.15.2**. The old mismatch — a version with no tag — has partly resolved into its mirror: **a tag with no version and no changelog.** Decide which number is real |
| Formula engine | Wired 2026-09-14 · **committed and on `origin/main` via PR #51** (2026-10-02) · still **not packaged**. Its call site gained tests this snapshot: `spreadsheet.rs` 6 → **41** |
| Post-0.13.1 source work | egui 0.35 migration (completed by `explorer_ui`), presentation rewrite, file sidebar + mutations, Save/Print across twelve viewers, Sassy Nova theme, three data-loss fixes, Windows resource/icon/DPI fix, reboot-crash fix, Foreman deny-by-default, formula engine, **extension content scripts, Android libc++ fix, PSD decode, CSS `@layer`, IndexedDB persistence** (all five now in the measured tree), **the userscript manager, viewer printing, the unified 43-command MCP protocol, the Browser Control privilege gate, the `diagnostics` feature gate, and feature-gated speech-to-text** · **none of it packaged** |
| Linux packages | Build from source · no distro packages |
| macOS | Planned |

**Recent engine / product work (2026-07-28…08-01)**

- DevTools Network dual-write; FOUC / Next.js `partially-hydrated` unlocks
- MutationObserver delivery on the egui path (records, subtree, `attributeFilter`, `removedNodes`)
- Deeper image editor (lasso, selection-aware paint, layer masks from selection, expanded blends)
- PDF annotate-persist, blank draft, print-to-PDF
- v0.13.2 (2026-07-31): interface density independent of font scale, two-line arrangeable toolbar, post-setup PIN management, image working copies; onboarding now always encrypts at rest via a per-install device secret, wizard re-runs no longer orphan master keys, sealed API keys are read back, Windows "Open with" no longer opens empty
- `js/builtins/` extraction out of `interpreter.rs` — **and mostly reversed 2026-10-05.** The prior "14 modules, 4,318 lines" figure is withdrawn: twelve of those modules were `install(vm: &mut Vm)` VM machinery and went with the VM, leaving **2 files / 237 lines** (`ethereum.rs`, the EIP-1193 provider bound to the interpreter, plus `mod.rs`)
- **2026-10-05 — the bytecode VM deleted** (14,937 lines across 22 files): `js/vm.rs` (5,852), `js/compiler.rs` (2,996), `heap.rs`, `chunk.rs`, `vm_value.rs`, `gc.rs`, twelve VM-facing builtins, the `"use vm"` dispatch branch, and the Phase-6 test suite. Driven by `audits/2026-08-08-js-engine-consolidation-and-efficiency.md`, which found the VM had **never been DOM-wired** — it could not touch a page, had partial builtins and zero production callers, and was reachable only via a directive no real page emits. `js/` 49 → 31 files, `script/` 16 → 12. **Zero `js::vm` cases appear in the test run**, which is how the deletion is confirmed. The largest removal in the project's history, and **it reduced the headline LOC figure by choice**
- **2026-10-05 — userscript manager wired** (`userscripts.rs` 1,223 + `userscripts_host.rs` 449, 8 passing tests, **15 `GM_*` APIs**): `UserScriptManager` built in `browser_core.rs:133`, `UserScriptUI` in `app.rs:946`, `get_scripts_for_url` on the live navigation path at `app.rs:1679`, `GmEffect` at `app.rs:1720`, and the DevTools **User Scripts** tab now rendering the real UI where every prior snapshot called it a placeholder. **Reverses the 2026-08-31 withdrawal.** Not Tampermonkey-compatible, never run in a packaged binary, and **unreviewed — it is first-equal in the next audit's scope, because it executes third-party script against the user's authenticated pages**
- **2026-10-05 — speech-to-text behind an off-by-default `whisper` feature** (`voice.rs` 1,347 / 24 tests, `whisper_ffi.rs` 50, a 3,453-byte hand-written C shim): `transcribe`/`transcribe_file`/`load` over whisper.cpp static libs, symphonia decode, mono downmix, 16 kHz resample that averages rather than decimates and refuses to upsample, ten-minute cap. **Reverses the 2026-08-31 withdrawal, with four limits**: off by default, unbuildable without ~23 MB of unvendored upstream static libraries per target, an unverified port from a repo where the same code is currently unwired, and no transcription checked against real audio. **Not a shipped capability**
- **2026-10-05 — one MCP protocol** (`PROTOCOL_VERSION` 2 → 3, **43 commands**): two separate 30-command vocabularies that overlapped in nine commands with incompatible field shapes became one; tabs addressed by stable id rather than strip position; 28 JSON-RPC handlers collapsed into one testable translator (`mcp_server.rs` −~640 lines while gaining capability); thirteen commands new to the live browser. **Plus a privilege gate**: `ExecuteScript`, `OpenFile`, `VaultQuery` and `Cookie Set`/`Delete` refused until the user enables them in a new Browser Control tab, default off, with a test that fails the build if the tab advertises a gate the code does not enforce
- **2026-10-05 — viewer printing** (`print_sheets.rs` 1,541 / 18 tests, `print_kit.rs` 1,109 / 7 tests) across the chemical, IGES, STEP, Parasolid, 3MF and 3D-model viewers; and a new off-by-default **`diagnostics`** feature walling off probe panels that printed overlay IPs, identity public keys, session/device ids and a one-time recovery key
- **2026-09-14 — spreadsheet formula engine wired** (`viewers/formula/`, 15 files, 8,889 lines, 64 tests, **255 named functions**): declared at `viewers/mod.rs:28` and called from `spreadsheet.rs` on the live cell path; the hand-rolled ~60-function evaluator it replaced was deleted. Formulas stay formulas, unsaved edits are visible to every formula, and text/lookup/date functions no longer degrade to `f64`. All 64 tests execute and pass, for a second snapshot. **Zero new crate dependencies.** **New this snapshot:** its call site finally has tests — `spreadsheet.rs` 6 → **41**. **Not Excel parity** — 255 is not ~500, and structured and cross-sheet references are unverified
- **2026-09 — file sidebar mutations + Foreman deny-by-default**: New Folder, Rename and two-click Delete gated on Edit roots; Foreman policy no longer falls through to `Allow` on unmatched targets, `[zones].open` is actually consulted, and explicit feature rules beat the open zone in both directions (`foreman/` now **3,624 lines / 80 tests**). `src/files/` measured **3,959 lines / 36 tests** this snapshot, down from 4,346 / 39, with no cause identified
- **2026-09 — DevTools Elements panel populated**: `ElementsState::root` was `None` for the life of the panel, so the tab only ever said "No DOM tree available". Inspect now selects the right-clicked node and the styles pane shows computed style
- **2026-08-17 — presentation viewer rewritten** (`viewers/presentation/`, 7 files, 6,146 lines, 76 tests): PPTX/PPTM/PPSX/POTX, ODP/OTP, PowerPoint 97-2003 binary text recovery, Keynote preview recovery; EMU-accurate slide painting; present / edit / print-to-PDF / export with Slide, Presenter and Outline modes. Replaces the former 881-line single-file parser
- **2026-08-17 — file sidebar added** (`src/files/`): Explorer/Finder replacement in the browser chrome with Tree / Details / Timeline views, filter query language, per-root view-edit permissions, and an optional SQLite whole-drive search index
- **2026-08-31..09-02 — dead-code sweep and P0 crash fix**: warnings 47 → 0 with the compiled tree 1,023 lines *smaller*; `notify.rs` deleted; `voice.rs` cut 2,649 → 747 by deleting the unreachable transcription engine; six unused file-sidebar and viewer symbols deleted and three wired. **`src/monotonic.rs` added (85 lines, 3 tests, 19 call sites) to fix a shipped crash**: `Instant - Duration` panics when the result predates the clock epoch, and on Windows that epoch is boot, so launching the browser within five minutes of a restart aborted the process
- **2026-08-26..27 — Sassy Nova theme** (v0.14.0): claymorphic chrome over a new 3D icon set, now the default preset, with a palette measured from the artwork and three variants including a **WCAG-AAA high-contrast mode**. Nine-slice renderer (`theme/nova.rs`), new widget vocabulary (`ui/nova_widgets.rs`), single-point icon resolution (`icons.rs`). +2,836 lines — the only source change this cycle; `js/` and `viewers/` are byte-identical to the prior snapshot
- **2026-08-27 — Windows resource embedding fixed**: `build.rs` pointed at an untracked `.ico`, `rc.exe` failed, and the failure was swallowed as a printed warning that silently dropped the *entire* resource block from every build — icon, version metadata, and the manifest declaring per-monitor-v2 DPI awareness. Every Windows binary ever shipped was affected. Resource failures now fail the build. Two icon-rendering defects fixed alongside (59 of 61 SVG glyphs rasterizing black; double-premultiplied AA edges), plus a test that fails the build if any UI icon name resolves to no asset

**Carried debt visible in this snapshot**

- **Nothing has been packaged in ten weeks, and that is now the single highest-priority item in the portfolio** — inheriting the position from the version-control item that closed on 2026-10-02. The tree compiles with one warning and the suite is green, so this is release process, not engineering. Every user is running v0.13.1 (2026-07-28), which predates twelve or more capability changes and crashes if launched within five minutes of a reboot
- **The shipped binary crashes on launch after a reboot.** Nineteen sites computed `Instant::now() - d`, which panics when the result predates the clock epoch — and on Windows that epoch is system boot. Launching v0.13.1 within five minutes of a restart aborts the process. Fixed in source 2026-08-31 by `src/monotonic.rs`; **present in every packaged binary**
- **A capability claim this report carried for four snapshots was withdrawn 2026-10-05: the bytecode VM.** It is deleted. Every document agreed it existed, consistently, and all of them were wrong — **cross-chapter consistency checking cannot catch that class of error; only re-measuring the repository can.** See DataROOM chapter 03
- **Two script-injection paths are now live in the measured tree and neither has been reviewed** — the userscript `GM_*` surface and extension content-script injection, between them 10 tests and zero audit. Three snapshots ago the tree had neither. They are **first in the next audit's scope**
- **Version, tags, CHANGELOG and artifacts still do not agree — but the mismatch inverted.** Progress: a `[0.15.0] - unreleased` CHANGELOG section now exists, and the duplicate `[0.14.0]` heading is gone. Remaining: `Cargo.toml` says 0.15.0, the newest tag reachable from `HEAD` is v0.14.1, and **a `v0.15.2` tag exists that `HEAD` does not contain**, with no CHANGELOG section for 0.15.1 or 0.15.2. The old rule was "a version with no tag is a build identifier"; the new case is its mirror — a tag with no version
- **The zero-warning gate is still breached**, 2 → 1 (`temporary_fallback` in `paths.rs`, never used). The prior two warnings were resolved and **the resolution was not recorded, which the project's rule requires**: if `set_current_document` / `clear_current_document` were wired rather than deleted, a 2026-06-10 audit finding is closed and nobody wrote it down
- **Suppression debt is now a trend:** `#[allow(dead_code)]` 14 → 20 → **27** across three snapshots while the warning count sat near zero. One warning and 27 suppressions is not a quiet codebase; it is one whose noise moved where the gate does not look
- **`#[test]` fell 2,666 → 2,608 and the suite fell with it, 2,645 → 2,586 passing**, while the codebase grew 7,927 lines. The VM took its 301 tests. A smaller suite passing completely is not a suite that started failing — but it is not growth either
- `app/browser_ui.rs`, the largest file at 21,421 lines, now carries **16** unit tests, up from 5 — real movement, still thin for its size. `devtools/` (1,349 lines) and the newly-arrived `app/explorer_ui.rs` (1,138 lines) remain at zero. *(`js/compiler.rs`, previously listed here at 2,996 lines and zero tests, was deleted with the VM — the worst case on this list closed by removal rather than by testing)*
- **Twelve declared modules contain no code at all** — eleven in `js/`, declared under a comment reading *"ES2015+ feature modules (per web-browser-completion spec)"*, plus `paint_backend.rs`. 49 lines, zero implementation. They pass a reachability walk and fail its purpose
- **No independent audit since 2026-06-15 — sixteen weeks.** A new artifact exists (`audits/2026-08-08-js-engine-consolidation-and-efficiency.md`, landed 2026-10-02) and it drove the VM deletion, but **it is a self-audit written in the same week as the change it approves** and is not counted as coverage. The unreviewed compiled surface is flat at ~25,000 lines **only because the VM deletion offset the new arrivals — and the composition got worse**: what left could not reach a page; what arrived (userscripts, extension content scripts) executes third-party script in the user's authenticated session. Also unreviewed: the presentation parser, the formula engine, the sidebar's mutation gate, the changed Foreman control, the new print paths, and the Browser Control gate
- Full suite green on 2026-10-05 (**2,586 passed / 0 failed / 19 ignored**, 2,605 run, 7.65s), re-scored against this tree. Keep it on cadence after large merges
- Print-to-PDF soft-gate removed; free-tier PDF export matches chapter 06. Real Pro billing still absent. *(Correction: `src/features.rs` was reported deleted on 2026-09-14 and is **present**, 91 lines — an artifact of measuring a tree 23 commits behind `origin/main`)*
- `dist/` holds four release `.exe` files mixed in with a large number of base64-named cached web assets from a browsing session. Clean before showing it to anyone

*Correction to the prior snapshot: `src/viewers/formula/` was once listed as written but unwired at 9,345 lines. It is **wired and compiled, measured at 8,889 lines** this snapshot. The "root-level orphan `mcp_client.rs`" it was grouped with was reported deleted — **it is present**, reachable from `bin/mcp-client.rs` through a `#[path]` attribute the reachability walk was not following. The unwired category is empty; the walk that establishes that has been fixed.*

*Correction carried: `src/viewers/presentation/` was once listed as unwired. It is wired and compiled — the sibling `presentation.rs` file it was said to be shadowed by has been deleted.*

**Public smoke (v0.13.1 · live `274877db`)** — 2 pass / 5 partial / 3 fail across ten sites. Static pages (example.com, Craigslist) work; SPA giants (DuckDuckGo, GitHub) still fail primary UX. HTTPS working sets often **450–840 MB**; one idle newtab hang spun ~100% CPU (tracked).

**Raise:** $800K SAFE for engineering hire(s), infrastructure, legal/IP, and 24-month runway.

Canonical machine-readable truth: `docs/status/product-status.json` in the ACE repo (mirrored to the marketing site `/status/`).

---

## 2. SassyTalkie

**Status:** Near-complete (Android primary; desktop secondary)  
**Stack:** Kotlin/Compose app hosting Rust `libsassytalkie` via JNI · shared `core` crate (PQC, sealed sender, channels, audio)

Cross-platform push-to-talk. 2026 feature epic landed privacy policy, relay store-and-forward, live translation scaffolding, noise suppression, radio/emergency channels, hardware/BT PTT, ML-KEM PQC, sealed sender wiring, and self-host docs. Remaining: settings/nav wiring for several panels, sealed-context at QR import, and multi-peer field validation. Wear OS / Android Auto deferred.

---

## 3. Guard Security Monitoring System

**Status:** Active development *(file inventory last walked 2026-03-18)*  
**Scope:** BLE (nRF52840), Wi-Fi monitoring, P25 radio paths, cellular tracking, Wyze camera feeds, unified command center.

---

## 4. WinForensics-Pro

**Status:** Commercial Forensic Workstation Suite (v1.0-rc / Production Packaging)
**Stack:** Rust Edition 2021 · Native Windows 95/NT `egui` Workstation GUI · Bundled SectorScope Engine
**Revenue model:** Tiered per-seat licensing, live on Cloudflare D1 + Stripe ($499 single practitioner → $1,800–$3,500/seat/year enterprise workstation tier)

### Delivered Scope
- **Dead-Disk Artifact Forensic Engine:** Rotating scanner, Prefetch and ShimCache parsers, BAM/Amcache analysis, registry triage, Authenticode signature verification, memory and disk acquisition paths, and automated report generation.
- **Integrated SectorScope Engine (`disk-core`):** Real-time disk I/O capture engine embedded natively into the WinForensics-Pro GUI. Includes period-accurate Windows 95 Defrag 2D cluster map, live NTFS USN journal and minifilter I/O event streaming, 3-layer content decode (L1 raw hex/ASCII dump, L2 structural headers for PE/SQLite/JSON/PNG, L3 forensic summary), file-extent cluster inspection, and throughput telemetry HUD.
- **Native Period-Accurate GUI:** Authentic Windows 95/NT workstation aesthetic implemented in `egui` with a 1-pixel beveled lighting model, XP silver palette, property sheet navigation tabs, discrete block progress gauges, and timeline event ribbons.
- **Licensing & Cloud Integration:** Cloudflare D1 entitlement verification with Stripe billing and 30-day cryptographically-signed offline lease capability for air-gapped forensic field deployments.

---

## 5. Foodie Finder

**Status:** Complete (feature-complete for store submission)  
Restaurant discovery with multi-source scraping, sentiment, cuisine filters — TypeScript / React Native.

---

## 6. Riverview Adventure Co. (client)

**Status:** Live  
Full-stack tourism site + admin on Cloudflare Workers (Rust). Related **RACRUST CMS** work is consolidating into the riverview-rust line.

---

## 7. SassyMCP

**Status:** Production · **v1.14.4**  
Unified Model Context Protocol server for Windows / macOS / Linux + Android automation, screen/OCR, GitHub, memory, network forensics, and security audit hooks. Force multiplier across the entire portfolio.

---

## 8. Consulting website

**Status:** Live · `sassyconsultingllc.com`  
Product portal, NDA flows, contact, Stripe/GitHub webhooks, coming-soon / browser status truth layer.

---

## 9–15. Supporting systems

| # | Project | Notes |
|---|---------|--------|
| 9 | SDR Radio Toolkit | RTL-SDR / P25 / HackRF tooling — operational |
| 10 | CF Admin Mobile | Expo mobile Cloudflare admin — active |
| 11 | NetGuard Dashboard | Paused; Guard command center prioritized |
| 12 | WordPress plugins | Live client themes / river safety |
| 13 | Security audit scripts | Complete PowerShell assessment suite |
| 14 | RACRUST CMS | In progress; consolidating into Riverview |
| 15 | Wyze NVR Integration | Docker bridge for Guard video |

---

## Hardware assets

| Device | Model | Purpose | Status |
|--------|-------|---------|--------|
| BLE sniffer | nRF52840 Dongle | Guard BLE | Operational |
| SDR receiver | RTL-SDR v3 | P25 / spectrum | Operational |
| Cellular router | Cradlepoint IBR600B | Guard cellular | Acquired |
| Wi-Fi AP | Meraki MR45 | Network monitoring | Licensed |
| Security appliance | Meraki MX64W | Network security | Licensed |
| Cameras | Wyze v2/v3 | Guard video | Operational |

---

## Infrastructure

Web-facing apps deploy on **Cloudflare Workers** (D1, R2, KV). Development spans Windows desktop, Ubuntu server, and Samsung Galaxy S24 Ultra. Project sources live on an encrypted development volume.

---

## Legal entity

| Field | Value |
|-------|-------|
| Entity | Sassy Consulting, LLC |
| WI Entity ID | S162390 |
| Formed | August 1, 2025 |
| EIN | 39-3544154 |
| IRS Name Control | SASS |
| CP 575 G | August 1, 2025 |
| Registered agent | Shane Alan Smith |
| Principal market | Madison / Prairie du Sac, Wisconsin |

---

## Outlook

Near-term focus is **Sassy Browser** correctness (SPA hydration / JS host fidelity, memory, DevTools truth), publishing a **signed** update channel when ready, and converting SassyTalkie / Foodie Finder store traction into revenue. AI-augmented tooling (SassyMCP) remains the operating system for a single-founder portfolio.

**Do not** advertise browser version **v2.0.0**, stale LOC figures (94k / 139k / 156k / 200k / 224,732 / 225,307 / 228,000 / 241,730 / 244,566 / 243,543 / 253,944 — all superseded by the **261,871** compiled recount of 2026-10-05), office-suite parity claims, **Excel function parity**, a WPT pass rate, a public auto-update channel, **a bytecode VM or a `"use vm";` fast path** (deleted 2026-10-05 — do not describe a second JS engine), **Tampermonkey or Greasemonkey compatibility** (the userscript manager ships with 15 `GM_*` grants and no compatibility claim), or **working speech-to-text** (built, off by default, unbuildable without unvendored upstream libraries, unverified). The tree compiles with **0 errors and 1 warning** as of 2026-10-05 — the zero-warning gate is breached, not restored — and the full suite is green (**2,586 passed / 0 failed / 19 ignored**). Nothing has been packaged since 2026-07-28, so do not describe any post-v0.13.1 capability as available to users; the shipped v0.13.1 binary crashes on launch within five minutes of a reboot.

**Two capabilities may now be described as implemented in source**, which prior snapshots forbade: a **userscript manager** (wired, 15 `GM_*` APIs, 8 passing tests) and **extension content-script injection** (wired on the navigation path). Both carry the same caveat: **in no packaged binary, and reviewed by nobody.**

**Three cautions this snapshot.**

**On the formula engine:** it is correct to say Sassy Browser has *a 255-function spreadsheet formula engine*, and correct to say that engine is *wired, called, and passing 64 tests*. It is **not** correct to say Excel parity, Excel compatibility, or "opens and edits Excel files like Excel." 255 is not the roughly 500 of modern Excel; structured and cross-sheet references are unverified; no round-trip against real workbooks has been run; and the engine is in **no packaged binary**. *(It is now committed and on `origin/main` — the "no commit" half of the prior caution is withdrawn.)* The safe sentence is: *"a 255-function formula engine, in source, parity unverified."*

**On LOC movement — and this snapshot runs the opposite way to the last one.** The browser figure rose about 7,900 lines, and the composition is unusual: **`js/` lost 12,887 lines to the bytecode-VM deletion while the root gained 12,702.** So the net increase **understates** the period's engineering, because real new capability is partly masked by a large deliberate removal. Do not present the delta as a velocity figure in either direction — and if the deletion comes up, the honest framing is that **removing 15,000 lines of never-reachable interpreter makes every LOC-derived figure in this binder more accurate, not less.**

**On the two restored capabilities:** the userscript manager and speech-to-text were *withdrawn* from this report in August for lack of compiled code, and are *restored* now because the code exists. Each restoration carries its own ceiling. Userscripts: **no Tampermonkey or Greasemonkey compatibility claim**, 15 `GM_*` grants, never run in a packaged binary, unreviewed. Speech-to-text: **not a shipped capability** — off by default, unbuildable without ~23 MB of unvendored upstream static libraries per target, an unverified port, and no transcription checked against real audio. The safe sentences are *"a userscript manager with a 15-API `GM_*` surface, in source, unreviewed"* and *"on-device speech-to-text, built behind an off-by-default feature, unverified."*

---

**Sassy Consulting LLC**  
sassyconsultingllc@gmail.com · sassyconsultingllc.com · Wisconsin  
Veteran-owned · Security-first · AI-augmented  
Entity ID S162390 · EIN 39-3544154 · Formed August 1, 2025
