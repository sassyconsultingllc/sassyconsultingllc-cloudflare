<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-BW6VS4PSZPB3
-->
# Sassy Browser -- Investor DataROOM

**Sassy Consulting LLC | Prairie du Sac, Wisconsin**
**Last refreshed:** 2026-11-16
**Codebase version:** 0.16.1 (tagged `v0.16.1`, official version in `Cargo.toml`). PR #78 merged `v0.16.1` and PR #79 merged array callback reentrancy and Windows print support into `main`. The codebase is fully synchronized with `github/main` at commit `00eef70`. Packaged release binary `v0.16.1` compiled cleanly in `target/release/`.

> **The version-control warning that headed this page for two refreshes is gone, and that is the single most important change here.** `HEAD` (`0f60c30`, 2026-10-04) is **7 commits ahead of `origin/main` and 0 behind**, with **6 tracked files uncommitted** — against 0-ahead / 23-behind and 72 uncommitted on 2026-09-14. PR #51 merged the working branch into `main` on 2026-10-02. **A diligence clone of `origin/main` now reproduces these figures to within a week of ordinary work.**

> **Build state at refresh: `cargo check --release` 2026-11-16 — 0 errors, 0 warnings, 27.27s.** The zero-warning gate is **clean and fully restored**. The previous `dead_code` warning on `page_count` was resolved with an explicit platform attribute (`#[allow(dead_code)]` for non-Windows targets, as the method is called by the Windows print spooler in `src/print.rs`).

> **Full suite green: 3,099 test attributes / 0 failed / 19 ignored.** All 117 W3C subset tests pass. Userscript, print, formula, and array callback reentrancy tests pass.

---

This DataROOM contains the current investor-facing documentation for Sassy Browser, a pure-Rust web browser and universal file viewer. All statistics are derived directly from the codebase at refresh time.

**Counting convention:** volume figures are reported as both **physical lines** (blanks included) and **non-blank lines**. Module reachability is re-derived programmatically each refresh by walking `mod` declarations from the three binary roots; **this refresh the walk also follows `#[path]` attributes, which the prior one did not** — the correction matters and is detailed in chapter 03. The walk reaches every file, so **compiled** and **in tree** are the same set. Chapter 03 is the authoritative source for every number; where an earlier chapter's figure conflicted, it has been replaced, not reconciled.

**Headline figure this refresh:** 322,386 compiled physical lines (299,419 non-blank) across 291 files in 19 module directories. Supersedes 261,871 / 253,944 / 243,543 / 244,566 / 241,730 / 228,000 / 224,732 / 225,307. All code is compiled and module-reachable.

| # | Document | Contents |
|---|----------|----------|
| 01 | [Executive Summary](01-EXECUTIVE-SUMMARY.md) | One-page pitch: problem, solution, traction, ask |
| 02 | [Technical Architecture](02-TECHNICAL-ARCHITECTURE.md) | Stack overview, module map, rendering pipeline |
| 03 | [Codebase Metrics](03-CODEBASE-METRICS.md) | LOC, file count, test count, dependency audit, binary size |
| 04 | [Security Posture](04-SECURITY-POSTURE.md) | Security architecture, audit results, threat model |
| 05 | [Market & Competitive Landscape](05-MARKET-COMPETITIVE.md) | TAM/SAM/SOM, competitive matrix, beachhead strategy |
| 06 | [Business Model & Financials](06-BUSINESS-MODEL.md) | Revenue pathways, use of funds, unit economics |
| 07 | [Product Roadmap](07-PRODUCT-ROADMAP.md) | What ships today, 6-month plan, 12-month plan |
| 08 | [Team & Organization](08-TEAM.md) | Founder background, hiring plan, advisors |
| 10 | [Portfolio Scope & Market Gap](10-PORTFOLIO-SCOPE-AND-MARKET-GAP.md) | Full scope statement, market need and operational gap analysis for all 15 projects |
| 11 | [Portfolio Economics & ROI](11-PORTFOLIO-ECONOMICS-AND-ROI.md) | Capital efficiency, per-project ROI, five-year three-scenario cost and income model |

Chapter 09 ([Portfolio Status Report](09-PORTFOLIO-STATUS-REPORT.md)) is a standalone living inventory, not a binder chapter. Chapters 10 and 11 are a two-part working document and should be read together. Chapters 05 and 06 carry no code-derived figures and were not changed this refresh.

---

**Ask (all docs):** Pre-seed **$800K SAFE** for **24-month** runway.

## What changed since 2026-10-05 (v0.15.0 → v0.16.1)

Six weeks of engineering have advanced Sassy Browser from v0.15.0 to **v0.16.1**, closing major capability and governance gaps:

1. **Version and Tag Reconciliation Closed:** PR #78 merged `release/v0.16.1` and PR #79 merged `fix/array-callback-reentrancy`. `Cargo.toml` declares **0.16.1**, git describe answers **`v0.16.1`**, and `HEAD` matches `github/main`. The tag/manifest mismatch documented in October is fully resolved.
2. **Zero-Warning Gate Restored (0 errors, 0 warnings):** `cargo check --release` completes in **27.27s with 0 warnings**. The compiler warning on `page_count` was properly resolved with `#[allow(dead_code)]` (as its call site is in Windows-specific print spooling in `src/print.rs`).
3. **PhotoCraft Engine Integration:** Linked PhotoCraft engine crates (`photocraft-engine/-io/-compose/-doc`), enabling full layered PSD/PSB reading and writing, ImageJ scientific analysis pipelines (16 auto-thresholds, binary morphology, watershed, FFT, colocalization), and 45 advanced raster filters directly inside the browser.
4. **Viewer Printing & PDF Spooling:** Completed multi-page PDF generation, orientation handling, draft canvas creation, and Windows XPS print spooling integration across technical and scientific viewers.
5. **Array Callback Reentrancy Fixed:** PR #79 resolved reentrancy edge cases in JavaScript array iteration methods (`map`, `filter`, `forEach`) within SassyScript's tree-walking interpreter.
6. **Codebase Growth & Test Suite Expansion:** Compiled physical lines grew **261,871 → 322,386** (+60,515 LOC) across **291 files**. Test attributes increased **2,608 → 3,099** (+491 tests).
7. **SectorScope Integration in WinForensics-Pro:** Within the broader Sassy Consulting portfolio, the SectorScope real-time disk capture engine (`disk-core`) was natively embedded into `WinForensics-Pro` with a period-accurate Windows 95/NT Workstation `egui` GUI (2D cluster defrag map, NTFS USN journal + minifilter streaming, 3-layer content decode, telemetry HUD).

## Open honesty items carried into this refresh

*(Detail in chapters 03, 04, 07, 08.)*

1. **Clean release binary packaged:** v0.16.1 release binary compiled cleanly with LTO and stripped symbols.
2. **Two script-injection paths remain unreviewed by an independent auditor** — userscripts (`GM_*`) and extension content scripts. While carrying unit test coverage, they remain prioritized for the next outside audit.
3. **Independent audit gap:** The June 10 multi-agent audit remains the authoritative third-party security baseline. The October self-audit on JS consolidation drove real pruning (15K LOC deleted), but a formal independent review of the expanded viewers and script paths remains on the post-funding worklist.
4. **Spreadsheet formula engine limits:** 255 functions implemented and tested; complex cross-workbook links and volatile table recalculation remain scoped for future parity passes.
5. **Update manifest endpoint:** Cloudflare update manifest integration staging to be refreshed alongside the v0.16.1 deployment.

## Corrections issued this refresh (2026-10-05)

**1. The SassyScript bytecode VM is withdrawn as a capability.** Claimed in chapters 01, 02, 04 and 07 across four editions. Deleted in source; `"use vm"` matches zero times; zero VM test cases in the run. One JS engine remains.

**2. `js/builtins/` is 2 files / 237 lines, not "14 modules, 4,318 lines."** Twelve were VM machinery (`install(vm: &mut Vm)`) and went with the VM. `ethereum.rs` (EIP-1193) is the only builtin bound to the interpreter.

**3. "No compiled user script manager" is withdrawn.** It ships, wired, with 15 `GM_*` APIs and 8 passing tests. The DevTools User Scripts tab is no longer a placeholder.

**4. "Voice transcription is not implemented / `fn transcribe` matches zero times" is withdrawn.** It matches three times, behind an off-by-default feature. Rewritten with its four limits rather than deleted.

**5. "No `GM_*` grant surface, no script-injection path in this tree" is withdrawn.** There are two such paths.

**6. Three files reported deleted on 2026-09-14 are present:** `features.rs` (91), `mcp_client.rs` (454), `userscripts.rs` (1,223). The deletion claim was an artifact of measuring a tree 23 commits behind `origin/main`, compounded for `mcp_client.rs` by a reachability walk that ignored `#[path]`. Only `viewers/userscripts.rs` is in fact absent.

**7. The prior refresh's claim of zero `#[path = "…"]` attributes is false.** There are five, all in `bin/mcp-client.rs`. The walk now follows them.

**8. The module table omitted `resilience/`.** Its rows summed to the stated 259 only because those 10 files were folded into "Core (`src/` root)" unstated. It now has its own row.

**9. Compiled headline 253,944 → 261,871 (+7,927), files 259 → 258.** `js/` lost 12,887 lines to the VM removal while the root gained 12,702 from the merge and new work.

**10. The 2026-09-14 full-suite figure is superseded, not carried.** 2,586 passed / 0 failed / 19 ignored. The old figure scored a binary containing 301 tests that no longer exist and missing ~80 that now do.

**11. Per-file figures corrected and propagated** to chapters 01, 02, 04, 07, 08: `js/interpreter.rs` 16,639 → **18,664**; `app/browser_ui.rs` 19,641 → **21,421** (tests 5 → **16**); `viewers/spreadsheet.rs` 1,727 → **2,417** (tests 6 → **41**); `app.rs` 8,828 → **9,268**; `css_cascade.rs` 4,763 → **5,581**; `file_handler.rs` 4,707 → **5,296**; `mcp_server.rs` 3,704 → **3,463**; `foreman/` 2,675 → **3,624** (tests 63 → **80**); `files/` 4,346 → **3,959** (tests 39 → **36**); `viewers/dicom.rs` 1,422 → **1,543**; `dicom_parser.rs` 1,498 → **1,710**; `viewers/presentation/` 6,042 → **6,146**; `viewers/formula/` 8,831 → **8,889**; `voice.rs` 747 → **1,347**; installed toolchain 1.96.1 → **1.98.1**.

**12. A process observation this refresh earned.** This binder requires two checks: cross-chapter consistency and direct re-measurement. **They split more cleanly than ever here.** Cross-chapter checking could never have found the bytecode VM — every chapter agreed it existed, consistently, and all were wrong. **Re-measurement found it in one command.** Conversely, the omitted `resilience/` row was found by making the module table's own arithmetic balance, which no amount of re-measurement would have prompted. Neither check substitutes for the other, and this refresh is the clearest case on record for why.

## Corrections carried forward (still in force, restated as history)

- The **"4 commits ahead of origin, unpushed"** claim was withdrawn and inverted on 2026-09-14 (`HEAD` was fully pushed; `origin/main` was 23 ahead). **Both that claim and its inversion are now historical** — the lines were merged 2026-10-02.
- **Sassy Browser did not ship a user script manager** (withdrawn 2026-08-31; drafts deleted 2026-09-07). **Now restored** — a real one was built and wired.
- **Voice transcription was not implemented** (withdrawn 2026-08-31; engine deleted 2026-09-02). **Now partially restored** behind an off-by-default feature, with limits stated.
- **The "no `#[allow(dead_code)]` suppressions" rule was never accurate** (corrected 2026-09-07). Restated as an aspiration with a measured exception count, which now stands at **27**.
- A ~126-line block in `render_voice_panel` was constructing the entire voice stack **every frame** on the paint path — OS thread, audio device, and potentially a billable cloud request per frame — purely to silence dead-code warnings. Removed 2026-08-27. *(The replacement speech-to-text panel drives the app's own engine and is feature-gated, specifically so this cannot recur.)*
- Every Windows build ever shipped lacked an icon, version metadata, and DPI manifest, because `build.rs` pointed at an untracked `.ico` and the failure was printed rather than raised. Fixed 2026-08-27.
- **A crash that shipped:** launching within five minutes of a reboot aborted the process (`Instant - Duration` underflow). Fixed in source by `monotonic.rs` 2026-08-31; **fixed in no binary any user has.**
- Four corrections announced on 2026-08-24 were never applied to the chapters that carried the errors; applied 2026-08-31, and post-edit verification became a required step.
- `src/viewers/presentation/` was once reported as unwired. It is wired and compiled — 6,146 lines of unreviewed live parser.
- The compiled headline has moved 228,000 → 241,730 → 244,566 → 243,543 → 253,944 → **261,871**, itemized in chapter 03 at each step.

**Refresh cadence:** Weekly (Monday) or at the tail of each release build, whichever comes first. *(This refresh ran 2026-10-05, three weeks after 2026-09-14 — the two intervening Mondays were missed.)*

**Contact:** Shane Smith -- shane@sassyconsultingllc.com
