<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-P4NKJW8ZR6TC
-->
# Portfolio Economics & ROI

**Sassy Consulting LLC | Five-year three-scenario model | Updated 2026-11-16** (browser LOC input recounted and §2.2 replacement-cost figures re-derived from it; scenario model otherwise unchanged since 2026-07-31)

---

## Reading guide

This chapter is the quantitative companion to Chapter 10, *Portfolio Scope & Market Gap Analysis*. It provides per-project business evaluation metrics, a capital-efficiency analysis of work already completed, and a consolidated five-year cost-and-income model under three outcome scenarios.

**All figures are in thousands of US dollars ($K) unless stated otherwise.** Fiscal years run August to July, aligned to the LLC formation date of 1 August 2025. Year 1 is FY2027 (Aug 2026 – Jul 2027); Year 5 is FY2031.

**This is a model, not a forecast.** Every number below is a stated assumption with a stated basis. None of it is booked revenue. Sassy Consulting LLC is pre-revenue on all product lines; the only revenue realized to date is client services. The purpose of the model is to bound the range of outcomes, not to predict a point within it.

**Modeling assumption, per brief:** each project is evaluated as if **fully realized** — production, signed, distributed, supported, and scaled to its addressable segment. The *Delta to production* sections in Chapter 10 enumerate what stands between current state and that assumption. The scenarios below are the mechanism for pricing the risk that those deltas are not closed.

---

## 1. Scenario definitions

Three cases are modeled. They differ in execution outcome, funding, and hiring — not in market size, which is held constant.

| | **Case A — Perfect** | **Case B — Less than perfect** | **Case C — Marginal** |
|---|---|---|---|
| **Interpretation** | Ceiling. Top-decile execution. | Base case. The planning number. | Floor. Products underperform; the business survives. |
| **Funding** | $800K SAFE closes Q4 2026; Series A available FY2029 | $800K SAFE closes Q1 2027 | No institutional raise; bootstrapped from services |
| **Headcount by Y5** | ~22 FTE | ~9 FTE | 1 FTE (founder) + contractors |
| **Sassy Browser** | Signed channel ships; broad SPA compatibility; v1.0 in Y2 | Signed channel ships Y2; SPA compatibility partial; niche adoption only | Never reaches daily-driver status; remains a technical asset and a viewer product |
| **Store products** | Talkie, Foodie, CF Admin all launch Y1 and gain traction | Launch slips into Y2; modest organic traction; no paid UA at scale | Launch, minimal traction, maintenance-only |
| **Guard** | Hardware bundle ships; SMB channel opens | Prosumer only; slow SMB entry | Small direct-sale base; no channel |
| **WinForensics-Pro** | GUI ships Y1; DFIR channel adoption | GUI ships Y1–Y2; direct sales only | Slow direct sales to a small practitioner base |
| **Services** | Scales with reputation and case studies | Grows steadily | Becomes the primary business |
| **Probability weight** | ~15% | ~55% | ~30% |

The probability weights are the founder's judgment, disclosed so a reader can substitute their own. They are not derived from a model.

---

## 2. Capital efficiency: what has already been spent

Before projecting forward, it is worth stating what the portfolio cost to produce. This is the single most defensible number in the chapter because it is backward-looking.

### 2.1 Direct capitalized engineering

| Basis | Value |
|-------|------:|
| Founder engineering hours across all 15 projects (Aug 2025 – Jul 2026) | ~4,200 hrs |
| Blended contractor rate (regional senior Rust/systems, self-billed) | $95/hr |
| **Direct capitalized engineering cost to date** | **$399K** |

Hours are estimated from commit cadence, project scale, and the founder's logged 10–20 hour development days. They are an estimate, not a timesheet.

**Allocation by project:**

| Project | Hours | Capitalized | Project | Hours | Capitalized |
|---------|------:|------------:|---------|------:|------------:|
| Sassy Browser | 1,500 | $142.5K | CF Admin Mobile | 150 | $14.3K |
| Guard | 450 | $42.8K | SDR Radio Toolkit | 130 | $12.4K |
| SassyTalkie | 420 | $39.9K | RACRUST CMS | 130 | $12.4K |
| SassyMCP | 400 | $38.0K | NetGuard Dashboard | 110 | $10.5K |
| WinForensics-Pro | 250 | $23.8K | Consulting Website | 95 | $9.0K |
| Foodie Finder | 230 | $21.9K | Security Audit Scripts | 70 | $6.7K |
| Riverview Adv. Co. | 170 | $16.2K | WordPress Plugins | 55 | $5.2K |
| | | | Wyze NVR Integration | 40 | $3.8K |
| | | | **Total** | **4,200** | **$399.0K** |

### 2.2 Conventional replacement cost

The direct cost understates the asset, because it prices founder hours at a contractor rate rather than pricing the artifact at what it would cost a conventional team to reproduce.

| Input | Value | Basis |
|-------|------:|-------|
| Sassy Browser original Rust | 322,386 LOC compiled (compiled == in tree) | Verified recount 2026-11-16 (v0.16.1) |
| Remaining 14 projects, original code | ~160,000 LOC | **Estimate.** Derived from file counts across portfolio; excludes vendored dependencies. |
| Total original portfolio code | ~**482,000 LOC** | |
| Conventional delivered productivity, blended | 45 LOC/engineer-day | Blend of systems-Rust (15–25) and application/web (60–90) |
| Implied engineer-years | ~42.8 | 482000 ÷ 45 ÷ 250 working days |
| Fully-loaded senior engineer cost | $160K/yr | Salary, benefits, overhead, equipment |
| **Conventional replacement cost** | **~$6.8M** | Range $5.5M – $7.5M |

**Capital efficiency ratio: ~17.0×.** Approximately $6.8M of conventional replacement-cost software was produced for $399K of direct capitalized cost.

**A caution specific to this refresh, and it runs the opposite way to the last one.** The browser LOC input reached 322,386, and the composition is unusual: **`js/` lost 12,887 lines while the root gained 12,702.** The loss is the bytecode VM — **14,937 lines across 22 files, deleted** because it had never been DOM-wired and no page could reach it. The gain is real new work plus the `origin/main` merge.

Two consequences a reader should hold together. **First, the net increase understates the engineering in this period**, because a quarter's worth of new capability (userscripts, viewer printing, the unified MCP protocol, feature-gated speech-to-text, `explorer_ui` migration) is partly masked by a very large deliberate deletion. **Second, and more important, the deletion makes the whole figure more honest, not less.** A replacement-cost model that counts 15,000 lines of never-reachable interpreter is overcounting; removing them prices the artifact closer to what a conventional team would actually have to reproduce. **Deleting code that reduces your own headline number is the behaviour this model should reward**, and the prior refresh's caution — that a rise can be reclassification rather than velocity — applies in reverse here: **a flat-ish number can conceal both real work and real pruning.**

**Caveats, stated plainly.** Lines of code are a poor proxy for value and a defensible one only for order-of-magnitude comparison. Some of the ~422,000 lines are boilerplate; some carry the 240 open findings from the 2026-06-10 audit and would require rework in any organization. The non-browser LOC estimate is unverified. **The browser tree compiles with 0 errors and 0 warnings as of 2026-11-16** — the zero-warning gate is still breached — and the full suite is green (**2,586 passed / 0 failed / 19 ignored**, re-scored against this tree; down 59 passing because the VM's 301 tests left with the VM). The 2026-08-31 refresh found two features documented as shipped with no compiled code behind them; the 2026-09-14 refresh found this binder stating its version-control position backwards for the second consecutive week; and **this refresh found the binder claiming a bytecode VM across four editions of four chapters that the code no longer contained.** Fair reminders that "written," "compiling," "reached," and "shipped" are four different states — and that a document can be internally consistent and uniformly wrong.

**The unreached-code discount is zero; the shipped-code discount is the one that matters.** Prior editions asked readers to discount the LOC figure by the share written-but-unreachable, measured at roughly 3.5% and now **0%** — every line is module-reachable. *(A small footnote on that: **12 declared modules contain no code at all** — 49 lines, comments only. Immaterial to this model, and noted so the 0% is not read as stronger than it is.)* The discount that remains, and is far larger, is the share **compiled but not shipped: nothing has been packaged since 2026-07-28 — ten weeks.** One thing did improve materially here: the prior edition noted that the single largest capability in this figure existed in no commit and on no remote. **That is no longer true** — PR #51 merged the branch into `origin/main` on 2026-10-02, so the asset is committed, pushed, and reproducible from a clone. It is still in no user's hands. A replacement-cost argument values the artifact; an investor should separately weigh that the artifact is not yet distributed. Treat $6.0M as a ceiling on the replacement argument and $399K as a firm floor on the cost argument. **The ratio is directionally right even at the pessimistic end of both.**

The mechanism behind the ratio is not heroics. It is AI-augmented development coordinated through SassyMCP — the productivity multiplier is itself one of the fifteen assets and is open-source and independently inspectable.

### 2.3 Capital efficiency in context of the ask

| | Value |
|---|------:|
| Direct capitalized engineering already invested | $399K |
| Conventional replacement value of that work | ~$6.8M |
| Pre-seed ask | $800K |
| Replacement value per dollar of ask | ~$8.5 |

---

## 3. Per-project business evaluation

### 3.1 Metric definitions used in this section

| Metric | Definition |
|--------|------------|
| **Sunk** | Direct capitalized engineering to date (§2.1) |
| **Cost-to-market** | Bottom-up incremental spend attributable *specifically* to this product to reach revenue: signing certificates, store fees, compliance review, product-specific infrastructure, product-specific marketing, support tooling. **Excludes** shared personnel, general G&A, and platform infrastructure. |
| **Y5 revenue** | Year-5 revenue, expected case |
| **5-yr cumulative** | Sum of Y1–Y5 revenue, expected case |
| **Gross margin** | Revenue less direct cost of delivery (infrastructure, bandwidth, storage, payment processing, delivery labor) at scale |
| **ROI multiple** | 5-year cumulative expected revenue ÷ sunk engineering. Measures return on *work already done*, not on forward capital. |
| **Payback** | First year in which cumulative product revenue exceeds sunk + cost-to-market |

### 3.2 Consolidated per-project metrics — expected case

| Project | Tier | Sunk | Cost-to-market | Y5 rev | 5-yr cum | GM | ROI× | Payback |
|---------|:----:|-----:|---------------:|-------:|---------:|---:|-----:|:-------:|
| Sassy Browser | 1 | $142.5K | $620K | $3,800K | $6,905K | 94% | 48× | Y3 |
| SassyTalkie | 1 | $39.9K | $185K | $1,400K | $2,755K | 88% | 69× | Y3 |
| Guard | 1 | $42.8K | $240K | $2,000K | $3,728K | 79% | 87× | Y3 |
| WinForensics-Pro | 1 | $23.8K | $165K | $1,550K | $3,180K | 96% | 134× | **Y2** |
| SassyMCP | 1 | $38.0K | $130K | $950K | $1,791K | 90% | 47× | Y3 |
| Foodie Finder | 2 | $21.9K | $115K | $520K | $1,043K | 82% | 48× | Y3 |
| CF Admin Mobile | 2 | $14.3K | $70K | $300K | $609K | 91% | 43× | Y3 |
| NetGuard Dashboard | 2 | $10.5K | $95K | $310K | $523K | 87% | 50× | Y4 |
| Riverview Adv. Co. | 3 | $16.2K | $18K | $60K | $240K | 71% | 15× | **Y1** |
| RACRUST CMS | 3 | $12.4K | $55K | $200K | $431K | 84% | 35× | Y3 |
| WordPress Plugins | 3 | $5.2K | $22K | $58K | $159K | 76% | 30× | **Y2** |
| Consulting Website | 3 | $9.0K | $34K | — | — | n/a | n/a | attribution asset |
| Security Audit Services | 3 | $6.7K | $28K | $370K | $1,067K | 62% | 160× | **Y1** |
| SDR Radio Toolkit | 4 | $12.4K | $16K | — | — | n/a | n/a | internal enablement |
| Wyze NVR Integration | 4 | $3.8K | $9K | — | — | n/a | n/a | internal enablement |
| **Portfolio** | | **$399.0K** | **$1,802K** | **$11,518K** | **$22,431K** | **88%** | **56×** | **Y3** |

**How to read the ROI column.** It is deliberately a narrow measure: cumulative expected revenue against sunk engineering only. It answers *"was building this a good use of the hours?"* and nothing else. It excludes the shared personnel, marketing, and overhead required to actually earn that revenue — those are $17,190K of the $18,992K five-year expected cost base and are modeled at portfolio level in §4, not allocated to projects. **Allocating shared cost by revenue share would produce a circular result and has been avoided.** The honest fully-loaded portfolio return is in §4.4.

### 3.3 Observations

**WinForensics-Pro is the strongest near-term risk-adjusted position.** Lowest cost-to-market of any Tier 1 product, highest gross margin (96%, essentially license keys and a D1 lookup), payback in Year 2, and a buyer who is a professional with a budget rather than a consumer. Licensing and Stripe billing are already live. The blocking work is a GUI.

**Security Audit Services has the highest ROI multiple (160×) and the lowest ceiling.** It is labor-delivered, so gross margin is 62% and revenue scales with hours, not with users. Its function in the portfolio is not upside — it is that it is profitable in Year 1 under every scenario and funds the product work in the marginal case.

**Sassy Browser carries the highest absolute value and the highest variance.** $6.9M of the $22.4M five-year expected total, 94% gross margin at scale, and by far the largest gap between the perfect case ($11.0M in Y5) and the marginal case ($0.44M). A browser engine is among the hardest artifacts in software to complete. The scenario spread is not modeling caution; it is the actual shape of this risk.

**Guard carries the lowest gross margin of the Tier 1 products (79%)** because video storage and egress are real variable costs. Storage architecture is the single largest lever on Guard's economics and should be settled before the SMB tier is priced.

**Riverview's 15× is the lowest multiple and the most certain revenue.** It is real, recurring, contracted, and independent of any launch or fundraise.

**Three projects carry no revenue line and are not deficiencies.** The Consulting Website is an attribution and diligence asset; its return is reduced CAC and shortened sales cycles. SDR Toolkit and Wyze NVR are internal enablement — they exist so Guard has an RF layer and a video layer without a license fee or a hardware manufacturing line. Combined sunk cost across all three is $25.2K.

---

## 4. Consolidated five-year model

### 4.1 Case A — Perfect

*Funded, hired, everything ships. Top-decile execution.*

| Line | Y1 FY27 | Y2 FY28 | Y3 FY29 | Y4 FY30 | Y5 FY31 | 5-yr |
|------|--------:|--------:|--------:|--------:|--------:|-----:|
| **Revenue** | 469 | 2,940 | 8,905 | 18,630 | 31,660 | **62,604** |
| **Operating cost** | 553 | 2,450 | 7,100 | 13,800 | 21,200 | **45,103** |
| **Net operating income** | (84) | 490 | 1,805 | 4,830 | 10,460 | **17,501** |
| Operating margin | (18%) | 17% | 20% | 26% | 33% | 28% |
| Cumulative net | (84) | 406 | 2,211 | 7,041 | 17,501 | |
| Cash position (on $800K) | 716 | 1,206 | 3,011 | 7,841 | 18,301 | |

Revenue by project:

| Project | Y1 | Y2 | Y3 | Y4 | Y5 |
|---------|---:|---:|---:|---:|---:|
| Sassy Browser | 40 | 700 | 2,600 | 6,000 | 11,000 |
| Guard | 30 | 420 | 1,500 | 3,200 | 5,500 |
| SassyTalkie | 50 | 420 | 1,250 | 2,500 | 4,000 |
| WinForensics-Pro | 80 | 450 | 1,200 | 2,400 | 3,800 |
| SassyMCP | 20 | 220 | 700 | 1,500 | 2,600 |
| Foodie Finder | 20 | 160 | 450 | 900 | 1,500 |
| NetGuard Dashboard | — | 40 | 200 | 480 | 850 |
| CF Admin Mobile | 15 | 100 | 270 | 500 | 800 |
| Security Audit Services | 130 | 240 | 380 | 550 | 750 |
| RACRUST CMS | 18 | 80 | 190 | 360 | 550 |
| WordPress Plugins | 16 | 40 | 75 | 130 | 180 |
| Riverview Adv. Co. | 50 | 70 | 90 | 110 | 130 |
| **Total** | **469** | **2,940** | **8,905** | **18,630** | **31,660** |

Interpretation: the $800K is never fully consumed; the business is cash-generative from Year 2 and a Series A becomes optional rather than necessary. Year-5 revenue of $31.7M with a 33% operating margin describes a company with roughly 22 employees and a genuine multi-product franchise. **This is the ceiling and should be treated as such.**

### 4.2 Case B — Less than perfect *(base case)*

*Funded but slower. Products ship late and adopt modestly. This is the planning number.*

| Line | Y1 FY27 | Y2 FY28 | Y3 FY29 | Y4 FY30 | Y5 FY31 | 5-yr |
|------|--------:|--------:|--------:|--------:|--------:|-----:|
| **Revenue** | 223 | 1,083 | 3,090 | 6,517 | 11,518 | **22,431** |
| **Operating cost** | 512 | 1,180 | 2,750 | 5,450 | 9,100 | **18,992** |
| **Net operating income** | (289) | (97) | 340 | 1,067 | 2,418 | **3,439** |
| Operating margin | (130%) | (9%) | 11% | 16% | 21% | 15% |
| Cumulative net | (289) | (386) | (46) | 1,021 | 3,439 | |
| Cash position (on $800K) | 511 | 414 | 754 | 1,821 | 4,239 | |

Revenue by project:

| Project | Y1 | Y2 | Y3 | Y4 | Y5 |
|---------|---:|---:|---:|---:|---:|
| Sassy Browser | 15 | 240 | 850 | 2,000 | 3,800 |
| Guard | 8 | 140 | 480 | 1,100 | 2,000 |
| WinForensics-Pro | 30 | 170 | 480 | 950 | 1,550 |
| SassyTalkie | 15 | 140 | 400 | 800 | 1,400 |
| SassyMCP | 6 | 75 | 240 | 520 | 950 |
| Foodie Finder | 8 | 55 | 150 | 310 | 520 |
| Security Audit Services | 82 | 135 | 200 | 280 | 370 |
| NetGuard Dashboard | — | 8 | 55 | 150 | 310 |
| CF Admin Mobile | 5 | 34 | 90 | 180 | 300 |
| RACRUST CMS | 7 | 26 | 68 | 130 | 200 |
| Riverview Adv. Co. | 36 | 42 | 48 | 54 | 60 |
| WordPress Plugins | 11 | 18 | 29 | 43 | 58 |
| **Total** | **223** | **1,083** | **3,090** | **6,517** | **11,518** |

**Cost structure, expected case:**

| Category | Y1 | Y2 | Y3 | Y4 | Y5 | 5-yr |
|----------|---:|---:|---:|---:|---:|-----:|
| Personnel (founder + hires) | 265 | 660 | 1,680 | 3,450 | 5,900 | 11,955 |
| Marketing & customer acquisition | 85 | 200 | 480 | 950 | 1,600 | 3,315 |
| Infrastructure & hosting | 45 | 110 | 240 | 480 | 800 | 1,675 |
| Legal, IP & compliance | 60 | 90 | 130 | 200 | 320 | 800 |
| G&A, insurance, accounting | 35 | 75 | 155 | 290 | 400 | 955 |
| Hardware, tooling & licenses | 22 | 45 | 65 | 80 | 80 | 292 |
| **Total** | **512** | **1,180** | **2,750** | **5,450** | **9,100** | **18,992** |

Interpretation. **Cash trough is $414K at end of Year 2** — the $800K provides a $414K cushion at the worst point, which is the primary reason the ask is sized at $800K rather than lower. The business turns operationally profitable in Year 3 and cumulatively profitable in Year 4. Year-5 revenue of $11.5M at a 21% operating margin describes roughly nine employees and a real, durable software business. **This is the number to plan against.**

### 4.3 Case C — Marginal

*No institutional raise. Founder stays solo. Products ship but do not find traction. Services carry the business.*

| Line | Y1 FY27 | Y2 FY28 | Y3 FY29 | Y4 FY30 | Y5 FY31 | 5-yr |
|------|--------:|--------:|--------:|--------:|--------:|-----:|
| **Revenue** | 103 | 276 | 582 | 974 | 1,464 | **3,399** |
| **Operating cost** | 245 | 265 | 320 | 395 | 465 | **1,690** |
| **Net operating income** | (142) | 11 | 262 | 579 | 999 | **1,709** |
| Operating margin | (138%) | 4% | 45% | 59% | 68% | 50% |
| Cumulative net | (142) | (131) | 131 | 710 | 1,709 | |

Revenue by project:

| Project | Y1 | Y2 | Y3 | Y4 | Y5 |
|---------|---:|---:|---:|---:|---:|
| Sassy Browser | — | 45 | 140 | 270 | 440 |
| Guard | — | 28 | 75 | 150 | 240 |
| WinForensics-Pro | 8 | 38 | 95 | 160 | 240 |
| SassyTalkie | 4 | 22 | 55 | 95 | 145 |
| Security Audit Services | 52 | 72 | 92 | 108 | 122 |
| SassyMCP | — | 15 | 38 | 70 | 115 |
| Foodie Finder | 2 | 9 | 22 | 38 | 58 |
| CF Admin Mobile | 1 | 6 | 15 | 26 | 38 |
| Riverview Adv. Co. | 24 | 24 | 26 | 26 | 28 |
| RACRUST CMS | 4 | 7 | 12 | 17 | 22 |
| WordPress Plugins | 8 | 10 | 12 | 14 | 16 |
| NetGuard Dashboard | — | — | — | — | — |
| **Total** | **103** | **276** | **582** | **974** | **1,464** |

Interpretation, stated without euphemism. **The marginal case is not a failure case.** With no institutional capital and no hires, the portfolio produces $1.46M of Year-5 revenue at a 68% operating margin and roughly $1.7M of cumulative operating income over five years. The high margin is a direct consequence of the low cost base — one person, no marketing spend, no office.

Three things follow. First, **the downside is a profitable single-operator software business**, not insolvency. Second, the cost of reaching it is that no product achieves escape velocity, and the browser in particular never becomes a daily driver. Third, this case is the argument for the raise rather than against it: the difference between $1.5M and $11.5M in Year 5 is not market size — the market is the same in both — it is whether the work gets finished, signed, and distributed.

### 4.4 Scenario comparison

| | Perfect | Expected | Marginal |
|---|--------:|---------:|---------:|
| Y1 revenue | 469 | 223 | 103 |
| Y3 revenue | 8,905 | 3,090 | 582 |
| Y5 revenue | 31,660 | 11,518 | 1,464 |
| 5-yr cumulative revenue | 62,604 | 22,431 | 3,399 |
| 5-yr cumulative cost | 45,103 | 18,992 | 1,690 |
| 5-yr cumulative net income | 17,501 | 3,439 | 1,709 |
| Y5 operating margin | 33% | 21% | 68% |
| Y5 blended gross margin | 89% | 88% | 87% |
| First cash-flow-positive year | Y2 | Y3 | Y2 |
| First cumulatively profitable year | Y2 | Y4 | Y3 |
| Deepest cash trough (on $800K) | $716K | $414K | n/a — unfunded |
| Headcount at Y5 | ~22 | ~9 | 1 + contractors |
| Probability weight | 15% | 55% | 30% |

**Probability-weighted expected values:**

| | Value |
|---|------:|
| Weighted Y5 revenue | **$11.5M** |
| Weighted 5-yr cumulative revenue | **$22.7M** |
| Weighted 5-yr cumulative net income | **$5.0M** |

*(0.15 × 31,660) + (0.55 × 11,518) + (0.30 × 1,464) = $11,523K Y5 revenue. The weighted case lands almost exactly on the expected case, which is a property of the chosen weights rather than a validation of them.*

**Fully-loaded portfolio return, expected case:**

| | Value |
|---|------:|
| Total capital deployed (sunk $399K + 5-yr operating cost $18,992K) | $19,391K |
| 5-yr cumulative revenue | $22,431K |
| 5-yr cumulative net income | $3,439K |
| **Return on total capital deployed** | **1.16×** |
| Year-5 exit revenue run rate | $11,518K |
| **Implied enterprise value at 4× ARR** *(conservative for 88% gross margin)* | **~$46M** |
| **Implied EV at 6× ARR** | **~$69M** |

The return on deployed capital of 1.16× is the honest cash-on-cash figure over five years and looks unremarkable in isolation. It is the wrong measure for a software business — the value is in the **terminal ARR** and the margin structure supporting it, not in the cumulative cash. At $11.5M ARR with an 88% blended gross margin and 21% operating margin, a 4–6× revenue multiple is conservative for the software sector. **On the expected case, an $800K pre-seed underwrites a company worth $46M–$69M in Year 5.**

---

## 5. Unit economics and benchmark comparison

### 5.1 Portfolio unit economics, Year 5 expected

| Metric | Portfolio | 2026 SaaS benchmark | Assessment |
|--------|----------:|--------------------:|------------|
| Blended gross margin | 88% | 75% median, 80%+ top quartile | **Above top quartile** |
| Operating margin, Y5 | 21% | Positive is above median at this scale | Above median |
| Revenue per FTE, Y5 | ~$1.28M | $150–250K typical at this stage | **Well above** — a function of AI-augmented development, and the model's most aggressive structural assumption |
| CAC payback, blended | ~8 months | 15–16 months median; 4–5 months seed-stage | Between median and seed-stage benchmark |
| LTV : CAC target | >4.5× | 3× minimum, 5× strong | Adequate |
| Net revenue retention target | 105–115% | 106% average; 120%+ top decile | At market |

**The revenue-per-FTE figure is the assumption most deserving of scrutiny.** $1.28M per employee is roughly 5–8× the benchmark for a company at this revenue scale. It rests entirely on the premise that AI-augmented development sustains a productivity multiple as the team grows — that a nine-person AI-augmented organization performs like a conventional thirty-person one. The evidence for the premise is the portfolio itself (§2.2, ~13.7× capital efficiency on work already completed). The evidence *against* it is that this multiple has been demonstrated for one person and has not been demonstrated to survive coordination overhead at nine.

**A reader who rejects the premise should adjust the expected case.** Holding revenue constant and normalizing revenue-per-FTE to $400K implies roughly 29 FTE at Year 5, personnel cost of approximately $4.6M above the modeled figure, and a Year-5 operating margin of roughly (19%) instead of 21% — a business that still grows to $11.5M but requires a Series A to get there rather than reaching it self-funded. That is a materially different investment, and the difference turns on a single assumption that is stated here rather than buried.

### 5.2 Revenue-model mix, Year 5 expected

| Model | Revenue | Share | Gross margin | Composition |
|-------|--------:|------:|-------------:|-------------|
| Subscription — consumer/prosumer | $7,266K | 63% | 87% | Browser Pro (72% of browser revenue), Guard, Talkie, Foodie, NetGuard, CF Admin |
| Licensing — per-seat/institutional | $2,814K | 24% | 95% | WinForensics-Pro, Browser institutional (28% of browser revenue), RACRUST |
| Support & enterprise — open-source adjacent | $950K | 8% | 90% | SassyMCP commercial tier |
| Services — consulting & retainer | $488K | 4% | 65% | Security audit, Riverview retainer, WordPress |
| **Total** | **$11,518K** | **100%** | **88%** | |

The mix is deliberate. Services revenue is low-margin and does not scale, but it is **counter-cyclical to product risk**: it is 4% of Year-5 revenue in the expected case and 11% in the marginal case — and **82% of Year-1 revenue in the marginal case**. It is the line that funds product work when products underperform, which is precisely why it is retained rather than divested.

### 5.3 Sensitivity — expected case, Year 5

| Variable | −25% | Base | +25% |
|----------|-----:|-----:|-----:|
| Sassy Browser adoption | $10,568K | $11,518K | $12,468K |
| Guard adoption | $11,018K | $11,518K | $12,018K |
| Blended gross margin (88% → 79% / 97%) | Op. margin 12% | Op. margin 21% | Op. margin 30% |
| Personnel cost | Op. margin 34% | Op. margin 21% | Op. margin 8% |
| Launch timing (all products slip 12 months) | ~$6,517K *(Y4 becomes Y5)* | $11,518K | — |

**The dominant sensitivity is timing, not adoption rate.** A uniform twelve-month slip costs $5.0M of Year-5 revenue — more than a 25% miss on the two largest products combined. This is the specific reason the use of funds is weighted toward engineering rather than marketing: the binding constraint on this portfolio is *finishing*, not *selling*.

---

## 6. Use of funds and the case for $800K

| Allocation | Amount | Purpose | Scenario impact |
|------------|-------:|---------|-----------------|
| Engineering | $360K | Senior Rust engineer, 24 months, plus contract design | Directly removes the timing sensitivity in §5.3 — the highest-leverage line |
| Operating reserve | $220K | 24-month founder salary and overhead | Covers the $414K Year-2 cash trough |
| Marketing & launch | $120K | Product Hunt, developer community, conference presence, ASO | Converts shipped products into adopted products |
| Infrastructure | $55K | Build and signing servers, CDN, Workers scaling, CI/CD | Unblocks the signed update channel (currently 404) |
| Legal & compliance | $45K | IP protection, open-source licensing strategy, GDPR/CCPA | Required before institutional and EU sales |
| **Total** | **$800K** | | |

**Why $800K and not less.** The expected case reaches a $414K cash trough at the end of Year 2. A $500K raise leaves a $114K cushion — inside the noise of a single slipped quarter. **Why not more:** a larger raise at pre-seed pricing dilutes beyond what a single-founder company should accept before Series A pricing is available, and the marginal case demonstrates the business does not require it to survive.

---

## 7. Model limitations

Stated so a reader does not have to find them:

1. **No booked revenue supports any product line.** Every product figure is a modeled assumption. The only revenue with an operating history is client services.
2. **Non-browser code and file counts are estimates** last fully walked 2026-03-18. The 400,000-LOC portfolio figure in §2.2 requires re-verification before external distribution — and note that it was assembled using the same blank-line-skipping counter that produced the superseded browser figures, so it is likely understated on one axis and overstated on another (unwired files counted as product). Treat it as indicative only. The browser figure — **253,944 compiled lines, and compiled equals in-tree for the first time** — is verified as of 2026-09-14 and is the only portfolio LOC number in this document that has been recounted under the corrected convention, with module reachability re-derived programmatically from the `mod` declaration graph rather than asserted. Note that the browser figure describes the **working tree**, which is 23 commits behind `origin/main` and holds 72 files of uncommitted work; a clone of the remote will not reproduce it.
3. **Founder hours are estimated**, not recorded. The $399K capitalized figure moves proportionally with any correction.
4. **The revenue-per-FTE assumption is the largest single risk in the model** and is quantified in §5.1 rather than defended.
5. **Adoption curves assume the products are finished.** Sassy Browser's live smoke is 2 pass / 5 partial / 3 fail; the model assumes broad compatibility by Year 2 (expected) or Year 1 (perfect). If SPA compatibility is not achieved, the browser tracks the marginal column regardless of the other scenario inputs.
6. **Churn is modeled implicitly** in the net revenue figures rather than as an explicit cohort model. A cohort-level model should be built before Series A diligence.
7. **No terms are modeled** — no SAFE discount, valuation cap, dilution, or option pool. Enterprise values in §4.4 are pre-money and unadjusted.
8. **Market sizes are third-party estimates with wide dispersion** (digital forensics ranges $8.4B–$17.9B for 2026 across sources). Where sources conflict, the model uses the conservative figure.
9. **Scenario probability weights are founder judgment**, disclosed for substitution.
10. **Foreign exchange, tax, and working-capital timing are excluded.** Figures are pre-tax operating results in USD.

---

## 8. Header conventions & footer definitions

### 8.1 Document conventions

| Convention | Rule |
|------------|------|
| Currency | US dollars, thousands ($K) unless explicitly stated |
| Fiscal year | August–July, aligned to LLC formation 1 August 2025 |
| Y1 | FY2027 = Aug 2026 – Jul 2027 |
| Parentheses | Negative values, e.g. (289) = −$289K |
| Em dash (—) | Zero or not applicable |
| Tilde (~) | Estimate; a stated basis accompanies every use |
| **Bold** in tables | Total, subtotal, or a figure requiring attention |
| Rounding | Tables may not sum exactly to the last digit; all totals are computed from unrounded inputs |

### 8.2 Financial term definitions

| Term | Definition as used in this document |
|------|-------------------------------------|
| **Revenue** | Recognized revenue in the period. Subscription revenue is recognized monthly; license revenue annually at sale. Not bookings, not ARR, except where explicitly labeled. |
| **ARR** | Annual recurring revenue — the annualized run rate of subscription and license lines at period end. Excludes services. |
| **Operating cost** | All cash operating expenditure: personnel, marketing, infrastructure, legal, G&A, hardware. Excludes taxes, financing costs, and depreciation. |
| **Net operating income** | Revenue less operating cost. Pre-tax, pre-financing. Approximates EBITDA for this cost structure. |
| **Gross margin** | Revenue less direct delivery cost (infrastructure, bandwidth, storage, payment processing, delivery labor). Excludes engineering salary. |
| **Operating margin** | Net operating income ÷ revenue. |
| **Sunk / capitalized engineering** | Founder engineering hours to date × $95/hr blended rate. A cost basis, not a balance-sheet capitalization. |
| **Cost-to-market** | Bottom-up product-specific incremental spend to reach revenue. Excludes all shared cost. |
| **Replacement cost** | Estimated cost for a conventional team to reproduce the existing codebase at market rates and conventional productivity. An order-of-magnitude comparison only. |
| **Capital efficiency ratio** | Replacement cost ÷ direct capitalized cost. |
| **ROI multiple** | 5-year cumulative expected revenue ÷ sunk engineering. Return on work already performed. Excludes forward cost. |
| **Return on capital deployed** | 5-year cumulative revenue ÷ (sunk + 5-year operating cost). The fully-loaded cash measure. |
| **Payback** | First year cumulative product revenue exceeds sunk + cost-to-market. |
| **CAC** | Customer acquisition cost — fully-loaded marketing and sales spend ÷ new paying customers acquired. |
| **CAC payback** | Months of gross profit from an average customer required to recover CAC. |
| **LTV** | Lifetime value — gross profit over expected customer lifetime. |
| **NRR** | Net revenue retention — revenue from a cohort one year on, including expansion, contraction, and churn. |
| **Cash trough** | The lowest cash position across the modeled period; determines minimum viable raise. |
| **Revenue per FTE** | Revenue ÷ full-time-equivalent headcount, including the founder. |
| **TAM / SAM / SOM** | Total / serviceable / serviceable-obtainable addressable market. See Chapter 05. |

### 8.3 Scenario labels

| Label | Alternate names used | Definition |
|-------|---------------------|------------|
| **Perfect** | Case A, upside, P90 | Ceiling. Full funding, full execution, all products land. 15% weight. |
| **Less than perfect** | Case B, expected, base, P50 | Base case and planning number. Funded, slower, modest adoption. 55% weight. |
| **Marginal** | Case C, downside, P10 | Floor. Unfunded, solo, products underperform, services carry. 30% weight. |

### 8.4 Source basis for external market figures

| Figure | Value used | Source category |
|--------|-----------|-----------------|
| Digital forensics market, 2026 | $8.4B (conservative of $8.4B–$17.9B range) | Third-party market research, multiple firms |
| Digital forensics CAGR | 11% (conservative of 11%–16.5% range) | Third-party market research |
| PoC / push-to-talk market, 2026 | $8.2B, 9.2% CAGR | Third-party market research |
| US home security market, 2026 | $17.4B, 7.6% CAGR | Third-party market research |
| Self-installed alarm share | 49% | Industry annual report |
| MCP monthly SDK downloads | 97M (March 2026) | Ecosystem telemetry |
| MCP production adoption | 41% of surveyed software organizations | Industry survey, 2026 |
| SaaS gross margin benchmark | 75% median, 80%+ top quartile | 2026 SaaS benchmark reports |
| SaaS CAC payback benchmark | 15–16 months median; 4–5 months seed | 2026 SaaS benchmark reports |
| SaaS NRR benchmark | 106% average, 120%+ top decile | 2026 SaaS benchmark reports |
| Mobile free-to-paid conversion | 2–5% median | 2026 app monetization reports |

Third-party market sizing varies materially by methodology and scope definition. Where sources conflict the model uses the conservative figure, and no market-size estimate is load-bearing for any revenue projection — the projections are built bottom-up from unit assumptions and cross-checked against market size for plausibility, not derived from it.

---

**Sassy Consulting LLC**
shane@sassyconsultingllc.com · sassyconsultingllc.com · Madison / Prairie du Sac, Wisconsin
Veteran-owned · Security-first · AI-augmented
Entity ID S162390 · EIN 39-3544154 · Formed August 1, 2025

*Confidential — Investor Materials. Companion document: Chapter 10, Portfolio Scope & Market Gap Analysis. All figures are modeled assumptions, not booked revenue or forecasts. Prepared 2026-07-31.*
