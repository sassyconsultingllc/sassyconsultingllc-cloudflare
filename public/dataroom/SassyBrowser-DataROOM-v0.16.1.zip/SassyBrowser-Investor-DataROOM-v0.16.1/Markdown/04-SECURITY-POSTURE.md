<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-IGPA4CNUKLXQ
-->
# Security Posture

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16**

> **Three security-relevant changes landed this refresh, and one claim in this chapter is withdrawn.**
>
> **Landed:** privileged MCP commands are now behind a user-held switch rather than behind the bearer token alone; a new off-by-default `diagnostics` Cargo feature walls off probe panels that printed credentials; and the bytecode VM — 14,937 lines of never-DOM-wired second JavaScript engine — was deleted, removing its attack surface entirely.
>
> **Withdrawn:** this chapter's statement that there is *"no `GM_*` grant surface, no script-injection path in this tree."* **Both now exist in the measured tree** — a wired userscript manager with 15 `GM_*` APIs, and extension content-script injection. Neither has been reviewed by anyone.
>
> **Measured against:** `HEAD commit `00eef70` (2026-11-16) on `main`, tagged `v0.16.1`, 322,386 compiled physical lines across 291 files, **7 commits ahead of `origin/main` and 0 behind** with 6 files uncommitted. The working-tree divergence the prior two editions disclosed is closed.

---

## Security Architecture

### Memory Safety
Sassy Browser is written entirely in Rust. This eliminates the memory safety vulnerabilities -- buffer overflows, use-after-free, null pointer dereferences, data races -- that account for 70%+ of browser CVEs according to CISA data. There is zero C/C++ browser engine code in the binary.

### No JIT Compilation — and, as of 2026-10-05, one engine rather than two
The JavaScript engine (SassyScript) runs with no JIT compiler: the tree-walking interpreter executes without native code generation. This eliminates the Spectre/Meltdown class of side-channel attacks that exploit JIT-compiled code in V8, SpiderMonkey, and JavaScriptCore.

**Correction.** Prior editions of this chapter grounded the claim in *"both the default tree-walking interpreter and the opt-in bytecode VM (`"use vm";`)."* **The bytecode VM has been deleted** — 14,937 lines across 22 files; `"use vm"` matches zero times in `src/`. The no-JIT property is unaffected, and from a security standpoint the change is favourable in two ways: there is one execution path to reason about instead of two, and the path that was removed was **never DOM-wired and reached by nothing**, which is to say it was 15,000 lines of compiled, unreviewed, unreachable interpreter sitting in every shipped binary. Removing unaudited code that no page could reach is a strict reduction in attack surface.

(The Boa fallback engine was removed in 0.13.x. SassyScript's tree-walker is now the sole JS engine, singular.)

### 4-Layer Sandbox Architecture

| Layer | Scope | Status |
|-------|-------|--------|
| Network sandbox | Outbound connection filtering, request validation | Implemented |
| Render sandbox | DOM isolation, cross-origin restrictions | Implemented |
| Content sandbox | File viewer isolation, path allow-listing | Implemented |
| Download sandbox | Quarantine dialog, file type warnings | Implemented |

### Cryptographic Primitives

| Function | Algorithm | Crate |
|----------|-----------|-------|
| Password vault encryption | ChaCha20-Poly1305 | chacha20poly1305 |
| Key derivation | Argon2id | argon2 |
| Identity keys | Ed25519 | ring |
| MCP token verification | Constant-time comparison | ring::constant_time |
| Update manifest signing | Ed25519 (minisign) | minisign-verify |
| API key storage | OS credential store | keyring |
| Key zeroization | Memory zeroing on drop | zeroize |

### TLS & Network Identity
- Chrome 132 JA3 fingerprint: cipher suites, signature schemes, GREASE, ALPN
- Defeats Cloudflare, Akamai, Imperva JA3 filters
- Runtime-switchable User-Agent with automatic cookie jar wipe
- Native OS certificate store support (rustls-native-certs) for enterprise proxy compatibility

### Anti-Fingerprinting
- Canvas fingerprint poisoning (conservative + aggressive modes)
- WebGL fingerprint randomization
- AudioContext fingerprint injection
- Font enumeration resistance
- Per-domain breakage tracking to auto-disable on sites that break

### MCP Security Model
- All MCP ingress (native WebSocket, stdio JSON-RPC, sync WebSocket) requires bearer token
- Token file created with 0600 permissions, atomic rename on write
- Constant-time token verification (`ring::constant_time`, plus `subtle` crate for cross-component comparisons)
- **A token now settles *who* is calling, not *what* they may do — new 2026-10-05, and it closes a real privilege gap.** The transport authenticated every client against the shared bearer token, and that was the whole authorisation story: **an agent legitimately allowed to read tabs was thereby allowed to run arbitrary script in the user's authenticated session.** The four commands whose blast radius reaches outside the page — `ExecuteScript`, `OpenFile`, `VaultQuery` and `Cookie Set`/`Delete` — are now refused with `PermissionDenied` until the user turns them on in a new **Browser Control** tab of the MCP Control Center (Ctrl+Shift+O). Default **off**, and session state rather than persisted config, so it does not survive a restart. The refusal names both the command and the switch, so an integrator can tell policy from misconfiguration. Two implementation details are worth the diligence reader's attention: the gate list is **one table with two consumers** (`MCP_PRIVILEGED_COMMANDS`, `browser_ui.rs:21273`), so the tab and the enforcement cannot drift apart; and a test at `browser_ui.rs:21390` **fails the build if the tab advertises a command as gated for which no call site enforces it.** That is the right shape for a security control — the UI cannot claim a protection the code does not implement
- Foreman policy engine: security/sandbox/auth/detection/crypto zones cannot be modified by MCP clients without explicit user approval
- **Foreman is deny-by-default.** Three real defects were closed in `foreman/policy.rs`, and they are worth naming because all three are the same failure mode — a policy engine that looked stricter than it was. Unmatched targets **fell through to `Allow`**, which inverts the intended posture for any feature nobody had written a rule for. The `[zones].open` table was declared in `foreman-policy.toml` and **never consulted**. And explicit feature rules did not reliably beat the open zone in both directions. `foreman/` has since grown to **3,624 lines and 80 tests** (from 2,675 / 63 at the prior refresh). **The "uncommitted" qualifier on this hardening is withdrawn — it is committed and on `origin/main` as of PR #51. It remains unpackaged and unreviewed:** it appears in no binary any user has, and it has never been seen by an auditor
- **Unified MCP wire protocol, `PROTOCOL_VERSION` 2 → 3.** Two 30-command vocabularies that overlapped in nine commands with incompatible field shapes are now one 43-command vocabulary. The security-relevant parts: tabs are addressed by **stable id rather than strip position**, so a command cannot silently act on a different tab than the caller meant after a drag, a close or a background-link open; the headless backend returns **`NotAvailable` naming the reason** where it cannot answer, rather than a plausible empty result a client would act on; and `FormValue` / `ClickTarget` replace a `serde_json::Value` and a four-way-ambiguous click payload, narrowing at the JSON boundary instead of trusting the wire. See Technical Architecture for the full change
- Encrypted MCP key vault: AI provider API keys live in the OS credential store (`keyring` crate), never plaintext in `ai.toml`. The xAI 2026-04-26 audit flagged plaintext storage as HIGH-severity; the keyring migration closed it
- Separate auth gate for the WireGuard / Tailscale sync channel; WireGuard primary per project policy

### Developer probe surfaces are now behind an off-by-default feature

New this refresh, and recorded here because the manifest states the reason in security terms rather than ergonomic ones. A **`diagnostics` Cargo feature, off by default**, gates probe panels and synthetic-event buttons that exist to exercise APIs by hand — a probe `UserManager`, an ephemeral crypto identity, simulated interaction/network/console events, and sample sync payloads. The manifest's own justification: *"several of those surfaces print overlay IPs, identity public keys, session/device ids and a one-time recovery key, which has no business being reachable in a shipped build."*

That is an accurate description of a credential-disclosure surface, and walling it off is the correct resolution. Two things keep it honest: CI compiles the gated code with `cargo check --features diagnostics`, so it cannot rot behind the flag, and the pattern is the opposite of the one that produced the voice-panel defect — a feature gate rather than a render-path probe. **It has never been reviewed, and it is in no packaged binary.** Note also what the gate implies about history: those surfaces *were* reachable in default builds until this change, including in `dist/sassy-browser-v0.13.1-windows-x64.exe`, the only artifact any user has.

## Audit History

### Mercury-2 Pass 1 -- Full Codebase (April 2026)
- Scope: Complete src/ directory, all 220 source files at the time of audit
- Findings: 5 CRITICAL items identified
- Resolution: All 5 CRITICAL items closed

### Mercury-2 Pass 2 -- MCP Hardening (April 2026)
- Scope: MCP protocol, authentication, file operations
- Findings: 7 follow-up items
- Resolution: 6 closed, 1 deferred (sandbox TOCTOU race requiring openat/O_NOFOLLOW -- tracked)

### Mercury-2 Pass 3 -- Verification (April 2026)
- Scope: Verification of Pass 2 closures
- Result: All 6 closures confirmed

### xAI Audit (April 26, 2026)
- Scope: Security review of the full codebase
- Key finding: API keys stored in plaintext in ai.toml flagged as HIGH severity
- Resolution: Implemented OS credential store (keyring crate) for encrypted-at-rest API key storage

### Mercury Rendering Gaps Report
- 1,092-line gap analysis mapping what works vs. what's needed for modern website compatibility
- Produced the work plan for reaching "can load most modern websites"

### Mercury-2 r3 Audit (May 17, 2026)
- Scope: Post-orchestration code audit covering 8 landed modules (m17-m24)
- Modules landed: multi-level positioned-ancestor walk, dynamic pseudo-classes, Photoshop-grade image viewer, timers + DOMContentLoaded, `::before`/`::after` pseudo-elements, `url()` background-image, DomBridge-NodeRef unification, `overflow:hidden` + z-index sort
- Gate state: GREEN -- cargo check OK, cargo build 7m23s, cargo test 965 passed / 0 failed / 13 ignored
- 6 fix-forwards applied during run; ~184 pre-existing clippy warnings unchanged
- Tracking item: over-commit `027c613` added ~130 stray demo/lock files (cleanup task open)

### Mercury-2 r4 Audit (May 17, 2026)
- Scope: 9-section follow-up audit on r3 module set
- Result: Same green gate; minor module fixes (m25-m28 DOM-bridge fallbacks, DCL listener reset, UTF-8 strip_comments rewrite)
- Confirms r3 closures held under re-test

### Mercury-2 r5 Render Diagnosis (May 17, 2026)
- Scope: Visual-regression diagnosis on Google home page render (4 documented symptoms)
- Root cause: m19 (`::before`/`::after`) forced pseudo-elements to `BoxType::Inline` regardless of computed display, collapsing inline flow and stacking all fragments at x=0; m20 z-index bucket ordering compounded occlusion
- Status: Closed in v0.10 -- render-collapse trilogy (L1 flex grow write-back, L2 paint zero-width clip guard, L3 FOUC-prevention strip) plus L4 (parse_color "invalid at computed value time" path) and L5/L5b (column-flex content.height + flex-basis:auto measurement). RAC body went from 790px tall to 3955px depth in a single test cycle; DuckDuckGo, GitHub, Twitter, and the Tailwind-style class of sites now render without the black-canvas regression

### Mercury r7 Render Collapse v1 + v2 (May 20, 2026)
- Scope: Two follow-up render-collapse audits after the v0.10.0 - v0.10.6 fixes
- Result: rem-before-em parse-order bug (v0.10.5) identified as the gating fix that unblocked every `rem` length site-wide; every Tailwind / MUI / Chakra / Bootstrap design-token site goes from collapsed-header to correct layout on the single-line fix
- Confirms the render-collapse trilogy closure held under broader test surface

### Final Warning Sweep + Real-Feature Wire-Up Audit (May 25, 2026)
- Scope: Full codebase sweep -- 44 commits, 81 unique files touched, +5,347 / -63 line delta
- Result: Compiler warnings 231 -> 0; `cargo check --workspace` clean (7.25s); `cargo build --workspace` clean (8m 06s); `cargo test --workspace` 1,020 pass / 4 pre-existing JS-interpreter fail / 16 ignored
- 33 `wire_module()` suppressor functions deleted; `src/browser/runner.rs`, `src/browser/webview.rs`, `src/markdown.rs`, and `devtools/mcp_orchestrator_exercise.rs` removed as dormant
- Real chrome features wired in this audit: per-tab mute/favicon, downloads pause/resume, bookmarks folders + domain chips, history per-entry delete, Print Ctrl+P with PageRange honoring, full-visibility Cookie Inventory (Ctrl+Shift+K), MCP Control Center (Ctrl+Shift+O), MCP diagnostics (Ctrl+Shift+M), Hunter Mode toggle, family device approval flow with WireGuard-aware VPN sync diagnostics, ScriptEngine `describe_expression` + `fire_window_event` probes
- Status: Closed

### Multi-Agent Full Codebase Audit (June 10, 2026)
- Scope: 19 subsystem auditors + adversarial verification of every high/critical finding across the full `src/` tree
- Result: **240 confirmed findings** -- 12 critical, 68 high, 113 medium, 47 low (lenses: 120 correctness, 59 W3C-conformance, 41 efficiency, 20 novelty). Machine-readable detail in `audits/2026-06-10-full-audit.json`
- Where the risk concentrates (honest assessment):
  - **JS engine semantics:** object/reference `===`/`==` defects, `try/finally` swallowing control flow, broken string relational comparison, `this`-binding leaks in callbacks, several page-reachable panics, and a no-GC closure-cycle leak. **Historical note:** the VM files were empty stubs at audit time on 2026-06-10, were built out through 0.12.x–0.15.0, and were **deleted entirely on 2026-10-05** without ever being DOM-wired. The production engine was the tree-walking `interpreter.rs` throughout and is now the only engine — **18,664 physical lines**. These findings therefore all land on code that is still live, and none of them was closed by the VM's removal
  - **JS parser:** multi-param arrow functions, default/destructuring params, switch/do-while/labeled statements not parsed; optional chaining mis-lowered; ASI absent
  - **CSS cascade:** shorthand/longhand applied in nondeterministic order (HashMap-backed); only ~8 of ~20 inherited properties propagate; an `!important` origin ordering bug
  - **Layout/paint:** hand-rolled (no taffy/parley/vello in the live path); no layout cache, no glyph cache, alpha-blending gaps on rounded/gradient fills, `position:fixed` scrolls with page
  - **Network/cookies:** SameSite-aware cookie path is dead on live requests, Set-Cookie Domain accepted without host validation (injection vector), Expires parser uses wrong date format, cross-origin redirects keep credentials
  - **DOM/engine:** event-listener callbacks run with `CURRENT_DOC` unset (handler `getElementById` returns null), timer/node registries never cleared on navigation (stale cross-document callbacks), hit-test regions not rebuilt after JS DOM mutation (SPA pages become unclickable), unconditional `Poll` spin pins a CPU core
- Status: Open -- this audit is the source of the current correctness work plan. Investors should read it as the candid engineering baseline: the codebase is broad and memory-safe, but rendering/JS fidelity on complex modern sites is still maturing. Some items flagged here (e.g. `script/fetch.rs` and `script/canvas.rs` being empty stubs) have since been implemented.

### Follow-on Audits (June 11 + 15, 2026)
- `2026-06-11-github-gap-analysis.json`: repo/release gap analysis
- `2026-06-15-spec-review-2-bugs.json` + `2026-06-15-js-completion-worklist.md`: JS spec-conformance worklist driving interpreter completion

### A new audit artifact exists — and it is a self-audit, not an independent one

**`audits/2026-08-08-js-engine-consolidation-and-efficiency.md`** is the first new file in `audits/` since 2026-06-15. Its filename is backdated to 2026-08-08; its **filesystem mtime is 2026-10-02**, so it arrived in the tree during this refresh window. 5.5 KB, four sections.

What it did, and it is substantive: it audited the two parallel JavaScript paths, found the bytecode VM unfinished and never DOM-wired, and **recommended and drove its deletion** — 14,937 lines across 22 files. It also went through the modules labelled *stub* or *minimal* in comments and found most of those labels **stale rather than accurate**: `Map`/`WeakMap`, `Set`/`WeakSet` and `URLSearchParams` are functional (member calls route through `__kind` dispatch to real implementations), and the doc comments were rewritten to describe actual behaviour. It identified one **genuine, deliberate, test-locked stub** — `WebSocket`, whose `readyState` is always `CLOSED` and whose `send`/`close` are no-ops, pinned by `wpt_subset::wpt_websocket_no_throw_on_construct_and_send` — and deliberately left it alone so the change stayed a consolidation rather than a behaviour change. It verified with `cargo check --workspace --all-targets` and `cargo test --workspace`.

**It is not an independent audit, and this chapter will not count it as one.** It is the founder's own review of his own consolidation, written in the same week as the change it approves. It carries no adversarial verification, no second reader, and no scope beyond the JS paths it was written to justify. Counting it as audit coverage would be exactly the category error this chapter exists to prevent.

**On the measure that matters: no independent audit since 2026-06-15 — sixteen weeks.** The 2026-06-10 multi-agent audit remains the current security and correctness baseline, and its 240 findings remain the open work plan. Investors should treat the security posture below as re-verified-by-inspection, not re-audited.

One thing the new artifact does change: it is **evidence that the self-audit habit produces real deletions rather than reassurance.** The largest single removal in the project's history came out of it. That is worth noting in the same breath as the observation that it cannot substitute for an outside reviewer.

### Code added since the last audit — explicitly unreviewed

**Two script-injection paths joined the unreviewed set this refresh, and one 15,000-line unreviewed module left it.** The net line count is roughly flat; the risk profile is not, because what arrived executes attacker-or-third-party script in the user's authenticated session and what left could not reach a page at all. Current inventory:

| Module | Files | Physical lines | `#[test]` | Notes |
|--------|------:|---------------:|----------:|-------|
| `src/viewers/formula/` | 15 | **8,889** | 64 | **Added to this table 2026-09-14.** A spreadsheet formula lexer, parser, evaluator and 255-function library, now on the live calculation path. It was previously listed under *Unwired code and attack surface* with the note that wiring it in would require treating it as new, unreviewed code — **that is exactly what has happened, and the note is hereby cashed.** Formula engines are an untrusted-input parser by another name: a spreadsheet cell is attacker-controlled text from any `.xlsx` a user opens. Specific things an audit must check here: recursion depth and stack exhaustion on nested expressions, the circular-reference terminator (there is a passing test, `circular_reference_terminates_with_an_error`, but a test is not a bound), integer and float overflow in the math and statistics libraries, range-size limits on aggregates, and whether any function reaches the filesystem or network |
| `src/viewers/presentation/` | 7 | 6,146 | 76 | Parses untrusted OOXML/ODP/legacy-binary/Keynote input — ZIP container handling, XML parsing, EMU geometry, embedded image decode, PDF export. **Untrusted-input parsers are the highest-risk category in this codebase and this one has never been reviewed.** |
| `src/files/` | 5 | **3,959** | 36 | Filesystem traversal with per-root access modes and a SQLite index. **Has a mutating surface** — New Folder, Rename, and two-click Delete, gated by `access_for` / `can_edit_cwd`. A traversal component that could only read was a confidentiality question; one that creates, renames, and deletes is an integrity question, and the gate that separates them has never been audited. |
| Save / Save As / Print across twelve viewers | 12 | +6,443 | — | Commit `eb17eb0` (2026-08-17). Adds **write paths** to modules that were previously read-only: audio, DICOM, ebook, font, IGES, image, Parasolid, PDF, spreadsheet, STEP, 3MF, video. A read-only parser that mis-handles input renders wrong; a write path that mis-handles input destroys the user's file — and exactly that defect was found and fixed in the Office save path a day earlier (`f834f8c`). |
| `src/foreman/` deny-by-default | 5 | **3,624** | 80 | A security control **changed** since the last audit, not merely added, and it has grown again (2,675 → 3,624 lines, 63 → 80 tests). See MCP Security Model above. Changed controls warrant review as much as new ones. |
| `src/extensions.rs` + content-script injection | 1 | **522** | 2 | **Now in the measured tree** — the prior edition's *"not in the tree measured by this binder"* caveat is withdrawn. `mod extensions;` at `main.rs:148`, `ExtensionManager` in `browser_core.rs` and `engine.rs`, `get_content_scripts(url)` called on the navigation path at `app.rs:2044` and `engine.rs:914` with per-navigation injection. **This is a code-execution-into-page path with 2 tests and no review.** What an audit must check: whether match patterns can be widened to `<all_urls>` by a crafted manifest, whether injected script is isolated from page script or shares a realm, what happens on `file://` and on privileged internal pages, and whether an extension's resources can be read cross-origin |
| `src/userscripts.rs` + `userscripts_host.rs` | 2 | **1,672** | 8 | **New to this table 2026-10-05, and it reverses a claim this chapter made.** A wired userscript manager with **15 `GM_*` APIs**, `get_scripts_for_url` on the live navigation path. The prior edition's *"no `GM_*` grant surface, no script-injection path in this tree"* is **withdrawn**. `GM_xmlhttpRequest` is a cross-origin fetch with the user's network position; `GM_setValue`/`GM_getValue`/`GM_listValues` are a persistent store; `GM_setClipboard` writes the clipboard; `GM_openInTab` navigates; `GM_addStyle` injects CSS. **Eight tests, no review.** What an audit must check: whether a userscript's match patterns are honoured strictly, whether `GM_*` grants are enforced per script from its metadata block or handed out wholesale, whether `GM_xmlhttpRequest` respects any origin policy at all, and whether the `GM_*` bridge is reachable from ordinary page script |
| `src/print_sheets.rs` + `print_kit.rs` | 2 | **2,650** | 25 | **New 2026-10-05.** Viewer printing across the chemical, IGES, STEP, Parasolid, 3MF and 3D-model viewers. Rendering untrusted geometry to a print surface; 25 tests, no review |
| `src/voice.rs` + `whisper_ffi.rs` + `whisper/whisper_wrapper.c` | 3 | **1,397** Rust + 3,453 bytes C | 24 | **New 2026-10-05, behind the off-by-default `whisper` feature.** An **FFI boundary into C** and the only non-Rust code in the project. It is off by default and unbuildable without unvendored upstream static libraries, so it is in no default build and reaches no user — but when it is enabled it is a hand-written C shim handling a large versioned struct, decoding attacker-supplied audio through symphonia. If this feature is ever turned on by default it needs review **first**, and the ten-minute per-call cap is a resource bound rather than a safety one |
| MCP protocol 3 + Browser Control gate | — | — | — | **New 2026-10-05.** A breaking wire change and a new authorisation control. The control is well-shaped (one table, two consumers, a test that fails the build on drift) and is **unreviewed**. An audit should confirm the four gated commands are the right four, and that no unlisted command reaches outside the page |
| `src/features.rs` + Print-to-PDF gate | 1 | 91 | 0 | **Present, not deleted.** The prior edition reported it deleted 2026-09-07; that was an artifact of measuring a tree 23 commits behind `origin/main`. It was never a security control (plaintext unlock file) and is not one now |
| `src/js/` bytecode VM | **−22** | **−14,937** | **−301** | **Left the unreviewed set by deletion.** ~15,000 lines of compiled, never-audited, never-DOM-wired second interpreter were in every shipped binary and are now gone. The only reduction in unreviewed surface this chapter has ever been able to report |

**Roughly 25,000 lines of compiled code remain unreviewed.** The figure is flat against the prior refresh rather than up, and the reason is arithmetic rather than diligence: the VM deletion subtracted about as much as userscripts, extensions, printing and the voice FFI added. **Flat is not progress here** — the composition got worse. What left was unreachable from any page; what arrived runs script in the user's authenticated session.

None of it inherits the reviewed status of the tree around it. All of it belongs in the scope of the next commissioned audit. **Priority order for that audit, revised this refresh by risk:**

1. **The two script-injection paths — userscripts (`GM_*`) and extension content scripts.** Newly at the top. Both execute third-party code against the user's live, authenticated pages; between them they carry 10 tests and zero review. Specifically: per-script grant enforcement, match-pattern strictness, realm isolation from page script, whether `GM_xmlhttpRequest` honours any origin policy, and whether the `GM_*` bridge is reachable from ordinary page script.
2. **`viewers/presentation/`** (untrusted-input parser; fuzz against malformed decks).
3. **`viewers/formula/`** (fuzz hostile expressions, oversized ranges, recursion depth, numeric overflow).
4. **The `src/files/` mutation gate** (symlink/junction/`..` traversal out of a granted root; whether `can_edit_cwd` is checked on *every* mutation path).
5. **The twelve viewer write paths plus the new print paths** (round-trip against real files).
6. **The Browser Control gate and MCP protocol 3** (are the four gated commands the right four).
7. **The build tooling** (other swallowed failures).

The `whisper` FFI is deliberately **not** in this list: it is off by default and cannot be built without unvendored upstream libraries, so it reaches no user. It moves to the top of the list the day anyone proposes enabling it by default.

### Build-state disclosure (2026-10-05)

`cargo check --release` at head of working tree: **0 errors, 1 warning**, 31.66s. **The zero-warning gate is still breached.** The single warning is `temporary_fallback` in `src/paths.rs:125`, never used.

**The prior two warnings were resolved, and the resolution was not recorded — which the project's own rule requires.** `set_current_document` and `clear_current_document` in `script_engine.rs` were flagged in the prior edition as possibly being the un-called fix for the 2026-06-10 audit's finding that *"event-listener callbacks run with `CURRENT_DOC` unset (handler `getElementById` returns null)."* They are gone from the warning list. **Whether they were wired into their call site or deleted is unknown, and the difference matters: in one case a known audit finding is now closed and nobody wrote it down; in the other it is still open.** This chapter does not guess. Determining which, and recording it, is a one-command task and it should be the first thing done after reading this paragraph.

Separately, `#[allow(dead_code)]` suppressions rose **20 → 27**. The prior edition defended the `script/` cluster as a storage API written ahead of its call sites — *"a defensible reason to suppress temporarily, and a reason that expires."* **It has had three weeks to expire and the count went up instead.** The three-refresh trend is 14 → 20 → 27. See *Verification status of build-quality claims* below.

**Full suite green against this tree (2026-10-05): 2,586 passed / 0 failed / 19 ignored** (2,605 run, 7.65s; 15m 34s release test build). This supersedes the 2026-09-14 figure of 2,645 passed, which could not have described this tree — it scored a binary containing the bytecode VM's 301 tests and missing roughly 80 that now exist.

Two readings of that run belong in a security chapter rather than a metrics one. **Zero `js::vm` or `js::compiler` cases appear in the run**, which is the strongest available confirmation that the VM is gone from the compiled artifact rather than merely unreferenced in source — 15,000 lines of unaudited interpreter are genuinely out of the binary. And **the 8 userscripts, 25 print and 24 voice tests all execute and pass**, which means the capabilities restored in this refresh are backed by running assertions rather than by call sites alone. That is the distinction the August overclaims turned on.

A green suite is not a security property — 2,586 first-party assertions pass against an engine carrying 240 open audit findings. A red one would block everything else in this chapter, and it is not red.

### An availability defect that shipped: crash on launch after reboot

This is the most serious defect this chapter has disclosed, and it belongs here rather than in the metrics chapter because availability is a security property.

`Instant - Duration` **panics** in Rust when the result would predate the clock's epoch. On Windows that epoch is **system boot**. Nineteen cutoff computations across ten modules — `engine.rs`, `network_monitor.rs`, `smart_history.rs`, `detection.rs`, `token_meter.rs`, `behavioral_mimicry.rs`, `sandbox/quarantine.rs`, `sandbox/popup.rs`, `ui/network_bar.rs`, `ui/popup.rs` — were written as a plain `Instant::now() - d`. Every one of them aborts the process when the machine has been up for less than the window they subtract. Launching the browser 220 seconds after a reboot killed it at startup with `overflow when subtracting duration from instant`.

Three things are worth stating plainly:

1. **It shipped.** The defect is present in `dist/sassy-browser-v0.13.1-windows-x64.exe`, the only packaged build, and in every build before it. Anyone evaluating the distributed artifact should expect the crash.
2. **The trigger is the modal case, not an edge case.** Booting a machine and opening a browser is close to the most common thing a desktop user does. This was not a rare-input bug; it fired on ordinary use and was survived only because most sessions start more than five minutes after boot.
3. **The affected modules are disproportionately security surfaces.** `sandbox/quarantine.rs`, `detection.rs`, `behavioral_mimicry.rs`, and `network_monitor.rs` all prune time-windowed records. A panic in a quarantine or detection path is a denial of the protection, not merely of the process.

Fixed in source 2026-08-31 by `src/monotonic.rs` (85 lines, 3 tests), whose `ago(d)` clamps to process start instead of panicking — also the semantically correct answer, since those cutoffs exist to prune records this process made and nothing it recorded can predate its own start. The project rule is now *never write `Instant::now() - d` directly.* **The fix is in no binary any user has.**

The general lesson for the next audit's scope: this was a whole-codebase pattern defect, invisible to type checking and to any test that did not run on a freshly booted machine. It is worth asking what other panicking standard-library operations are used unguarded across many sites — slice indexing, `unwrap` on time conversions, integer subtraction on unsigned counters.

### The file sidebar's permission model has a live mutating gate

`access_for` and `can_edit_cwd` drive the cwd view-only badge. **New Folder**, **Rename**, and two-click **Delete** are gated on Edit roots; View roots and mounted roots themselves refuse the mutation even where the OS would permit it. The module measures **3,959 lines and 36 tests** this refresh, down from 4,346 / 39 — it shrank, no cause was identified, and the figure is recorded rather than explained. **A security-relevant module that loses three tests between refreshes is worth a glance at what those three were covering.**

The security framing has changed with it, and should be stated rather than left implicit. Until this week the sidebar was a **read** surface: the risk was a traversal or an information disclosure. It is now a **write and delete** surface, and the only thing between an untrusted caller and a user's files is a permission check written by one person, never reviewed, and never exercised in a shipped binary. Three specific questions belong to the next audit: whether `can_edit_cwd` is checked on every mutation path rather than most of them; whether the Edit/View decision survives symlinks, junctions, and `..` traversal out of a granted root; and whether an MCP client can reach the mutation paths at all, given that Foreman's deny-by-default fix landed in the same uncommitted batch.

Until the sidebar ships in a packaged binary with the mutation set exercised, per-root permissions should not appear as a completed capability claim.

### A defect with a live cost was removed from the render path — and the engine behind it has now been deleted

Until 2026-08-27, `render_voice_panel` in `app/browser_ui.rs` contained a ~126-line block that constructed `VoiceSession`, `VoiceInput`, `MicrophoneCapture`, `VoiceActivityDetector`, `WhisperEngine` and `CloudTranscriber`, then ran their full lifecycles — `mic.start()` (spawns an OS thread and opens the audio input device), `engine.load_model()`, `download_model(None)`, and `CloudTranscriber::transcribe()` **with the user's real API key**. Every binding was discarded as `let _x =`. It existed only to mark those APIs as "used" so dead-code warnings stayed quiet.

Because the block sat on the paint path guarded solely by `voice_panel_visible`, opening the Voice panel re-executed all of it **every frame**. In security terms that is: an unbounded OS-thread and audio-device-handle leak triggered by a UI toggle, an unrequested microphone open, and an unrequested outbound request carrying a user credential, all at frame rate. It has been removed. A new code-quality rule follows from it — *never construct live subsystems on a render path to silence dead-code warnings; use a `#[cfg(test)]` exercise* — and is recorded in chapter 03.

Removing it exposed that the transcription pipeline was never wired to its panel at all, which is why `voice.rs` accounted for 30 of last refresh's 47 warnings. That capability claim was withdrawn from chapters 02 and 07 on 2026-08-31.

**Closed 2026-09-02.** The unreachable engine has been deleted rather than wired: `voice.rs` is down from 2,649 to 747 lines, `fn transcribe` matches zero times anywhere in `src/`, and `MicrophoneCapture`, `VoiceActivityDetector`, `download_model`, `load_model`, cloud transcription, and all ten audio-conversion helpers are gone. `CloudTranscriber` survives as a unit struct whose only method is `new()`, retained for the construction probe described above. From a security standpoint this is the better of the two available resolutions: it removes an unreviewed microphone-capture and credential-bearing network path from the compiled tree entirely, rather than wiring it and adding it to the audit backlog.

**Retracted finding, carried as history.** An intermediate draft of the 2026-08-23 refresh reported that the tree failed to compile (`E0061` at `browser_ui.rs:3554`, `E0063` at `data.rs:159`). Both were real against the 2026-08-17 tree and were fixed in source on 2026-08-21. The claim is withdrawn and recorded rather than deleted.

### Windows resource embedding — silent failure across every shipped build

Fixed 2026-08-27, disclosed here because the failure mode is instructive. `build.rs` pointed `set_icon` at `assets/icons/icon.ico`, a file never tracked in git. `rc.exe` failed on the missing file, and the failure was swallowed as `eprintln!("Warning: …")` — so the **entire resource block** was dropped from every Windows build. That included the application manifest, which is where per-monitor-v2 DPI awareness is declared, so DPI handling never took effect in any binary ever shipped. Two years of builds carried no icon, no version metadata, and no manifest, and nothing failed loudly enough to notice.

The fix makes resource failure fail the build (`SASSY_ALLOW_MISSING_RESOURCES=1` opts out) and locates `rc.exe` in the Windows SDK when it is not on `PATH`. `scripts/build-release.ps1` now verifies that the version baked into the exe resource matches `Cargo.toml`. The general lesson — a swallowed warning in a build script is a silent supply-chain-adjacent defect — is worth applying to the rest of the build tooling during the next audit.

### 0.13.2 security-relevant changes (2026-07-31, source only)

These come from the CHANGELOG and are worth flagging because they closed real at-rest gaps in onboarding:

- **Encryption is now unconditional.** Previously, skipping the optional PIN during onboarding meant *no at-rest encryption at all* — `persist_api_keys` refused to write and the wizard's final step was permanently disabled. Encryption is now always on, keyed off a per-install device secret (`auth::device_passphrase`, domain-separated from the `device.key` protection key). The PIN is an optional additional lock, not the root of trust.
- **API keys were written but never read back.** The wizard sealed keys into `mcp_keys.enc` and nothing loaded them, so the AI panel reported "no key" immediately after entry. `ai::resolve_key` now consults the vault between the OS keyring and the deprecated `ai.toml` plaintext path.
- **Wizard re-runs no longer orphan master keys.** Re-running onboarding previously created a duplicate admin profile, silently orphaning the prior master key and recovery key. It now offers to keep the existing profile.
- **PIN management after setup** — add, change, or remove a PIN at any time; the API-key vault is re-keyed to match.

### Verification status of build-quality claims

**The gate remains breached: 2 → 1.** It held 2026-05-25 → 2026-08-16, was breached 2026-08-17 → 2026-08-31 (peak 47), was clean on 2026-09-07, and has been breached on 2026-09-14 (2) and 2026-10-05 (1). **A smaller breach is not a restored gate.**

The measured detail, since a warning count means little without it:

| | 2026-09-07 | 2026-09-14 | 2026-10-05 |
|---|---:|---:|---:|
| `cargo check --release` warnings | 0 | 2 | **1** |
| `#[allow(…)]` in `src/` | 43 | 49 | **57** |
| of which `dead_code` | 14 | 20 | **27** |

**The suppression count has nearly doubled in three weeks while the warning count hovered near zero, and that relationship is the finding.** One warning on the board and 27 suppressions behind it is not a quiet codebase; it is a codebase whose noise has been moved somewhere the gate does not look. The prior edition wrote that temporary suppression of an API written ahead of its call sites is *"defensible engineering… and a reason that expires."* Three weeks on, the reason has not been cashed and the count rose by seven more.

This matters beyond tidiness for one specific reason, stated in the prior edition and now with a third data point: **suppression is the exact pattern that produced the voice-engine and userscript overclaims** — code that compiles, is silenced, and is reached by nothing. The safeguard is not to forbid suppression; it is to count it every refresh and to state what each one is waiting for. **The count is kept. The "waiting for" notes are not, and until they are, 27 suppressions are 27 unaudited assertions that something will be wired later.**

**The standing correction remains in force.** Chapter 03 listed *"No `#[allow(dead_code)]` suppressions"* as a rule for many refreshes, and this chapter cited it as evidence of rigor. It was never true. It is stated as an aspiration with a measured exception count — currently **27**.

**One genuine structural improvement belongs against all of that.** The project's largest-ever block of silenced, unreachable, compiled code — the 15,000-line bytecode VM — was not suppressed harder. It was deleted. That is the rule working at the scale where it matters most, in the same tree where it is being broken at the scale of 49 lines and 27 attributes.

A further qualifier on the 2026-05-25 through 2026-08-16 green period: part of it was purchased by the voice scaffolding described above, code whose only job was to keep the compiler quiet while doing real damage on the render path. That period's zero should be weighted accordingly.

### Unwired code and attack surface — empty for a second refresh, with two caveats

**Zero files in `src/` are unreachable.** The reachability walk from the three binary roots — now following the five `#[path]` attributes in `bin/mcp-client.rs`, which the prior edition's walk did not — reaches all **258**.

Two things qualify that, and both are new disclosures.

**First: 12 files are reachable and contain no code.** Eleven in `js/` (`ast.rs`, `async_fn.rs`, `class.rs`, `collections.rs`, `error.rs`, `json.rs`, `number_ext.rs`, `object.rs`, `promise.rs`, `strict_mode.rs`, `string_ext.rs`) plus `src/paint_backend.rs` — 4-5 lines each, a header and one doc line, **49 lines total, zero code**. They pass a reachability walk and carry no attack surface at all, so the security consequence is nil. The consequence for *this chapter's method* is not nil: a walk that counts declarations cannot distinguish a wired module from an empty one, which is a blind spot worth naming in the same section that relies on the walk.

**Second, and this is the real reversal: both of this section's standing favourable claims about script injection are withdrawn.**

The prior edition read: *"The security relevance for userscripts remains favourable: **no `GM_*` grant surface, no script-injection path in this tree**,"* with a note that extension content-script injection existed only on `origin/main`, *"in a tree this binder does not measure."*

**Both halves are now false.** The measured tree contains:

- a **wired userscript manager with 15 `GM_*` APIs**, `get_scripts_for_url` called on the live navigation path (`app.rs:1679`), surfaced in the DevTools **User Scripts** tab — which the prior edition described as *"an honest placeholder"* and which now renders the real UI (`panel.rs:520,563`);
- **extension content-script injection**, `get_content_scripts(url)` on the navigation path at `app.rs:2044` and `engine.rs:914`, per-navigation.

So the tree now has **two** independent paths that execute third-party JavaScript against the user's live, authenticated pages, where three weeks ago it had none. Between them: 10 tests, zero review. They are first and second in the next audit's priority order above, and the withdrawal of the favourable claim is the single most important line in this refresh of this chapter.

**The offsetting change, and it is genuinely large.** The 15,000-line bytecode VM left the unreviewed compiled set by deletion. It was in every binary ever shipped, had never been audited, and could not reach a page — the safest possible state for unaudited interpreter code, now improved to absent. **That is the first reduction in unreviewed surface this chapter has ever reported.** It is also why the ~25,000-line unreviewed total is flat rather than up: the subtraction and the additions are comparable in size and entirely incomparable in risk.

**History, carried:** `src/userscripts.rs` and `src/viewers/userscripts.rs` were deleted 2026-09-07 rather than wired; `userscripts.rs` has since been **rewritten and wired**, and `viewers/userscripts.rs` remains absent. `src/mcp_client.rs` was reported deleted in the same edition and is in fact **present**, reachable from `bin/mcp-client.rs` through a `#[path]` attribute the walk was not following. The standalone `mcp-client` binary is unaffected.


## Privacy Model

- Zero telemetry: no analytics, no crash reports, no user identifiers sent to Sassy Consulting LLC
- Single network contact: unauthenticated check for signed update manifests. As of a live check on **2026-10-05** that endpoint still returns 404, so in practice the shipped build phones home to nothing
- **Two new qualifications on "zero telemetry," both arriving with this refresh and both conditional.** `GM_xmlhttpRequest` gives any installed userscript a cross-origin fetch with the user's network position, and extension content scripts can do the same — neither is telemetry *from Sassy Consulting LLC*, and the claim above is specifically about us, but a reader should understand that installing a userscript or an extension creates outbound paths this claim does not cover. Separately, the `whisper` feature is **on-device by design** — it transcribes locally through static libraries, with no cloud endpoint — which is the right shape for the privacy claim, and is the opposite of the cloud-transcription path that was removed in August
- **One qualification, now closed.** Until 2026-08-27 the Voice panel could issue an outbound cloud-transcription request carrying the user's API key on every frame it was open (see Build-state disclosure). That path is removed. It was never reachable in a packaged binary — it postdates v0.13.1 — but the zero-telemetry claim above should be read as describing the shipped build and the current source, not as a claim that no such path has ever existed in the tree
- No accounts, no user IDs, no cookies/pixels/fingerprints from us
- All browsing data stored locally, user-deletable
- Built-in ad/tracker blocking (EasyList + EasyPrivacy)
- Smart history: 14.7-second delay with NSFW detection before committing URLs

## Vulnerability Reporting

Report via GitHub Issues or email shane@sassyconsultingllc.com. All versions supported.
