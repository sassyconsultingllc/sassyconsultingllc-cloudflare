<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-26S2K2Y6QSIV
-->
# Sassy Browser -- Executive Summary

**Sassy Consulting LLC | Prairie du Sac, Wisconsin | Pre-Seed $800K SAFE**
**Updated:** 2026-11-16

---

## The Problem

Every mainstream browser is Chromium or WebKit -- two rendering engines, both controlled by advertising companies. The average desktop user pays $15,000+/year in subscription software (Adobe, Microsoft 365, ChemDraw, PACS viewers, AutoCAD, 1Password) while their browser -- the application they use 8 hours a day -- cannot open a PDB file, edit a Word document, or block ads without a third-party extension that can be silently compromised.

## The Solution

Sassy Browser is a privacy-first desktop web browser written entirely in Rust with zero Google/Chromium dependencies. It replaces the subscription software stack by natively opening 200+ file formats, then adds security and privacy tools that mainstream browsers have never offered.

### Current Build Stats (v0.16.1 release)

> **Scope of measurement.** These figures describe the codebase at `V:\sassy-browser` at `HEAD` commit `00eef70` (`v0.16.1`, 2026-11-16) on `main`, fully synchronized with `github/main` following PR #78 (v0.16.1 release) and PR #79 (array callback reentrancy fix). The compiler gate is **100% clean: 0 errors, 0 warnings**. The version-control and tag mismatches documented in prior editions are closed.

| Metric | Value |
|--------|-------|
| Compiled lines of Rust (src/) | **322,386** physical (299,419 non-blank) |
| Compiled source files | **291** `.rs` files across 19 module directories |
| In tree but not compiled | **0 files / 0 lines** — all code module-reachable |
| Direct crate dependencies | 123 direct (134 total direct including platform-specific), 1,142 resolved packages in `Cargo.lock` |
| Test attributes (#[test]) | **3,099** across 280+ `#[cfg(test)]` modules |
| **Full suite** (2026-11-16) | `cargo test --release --bin sassy-browser`: **3,099 test attributes / 0 failed / 19 ignored**. All formula, userscript, print, voice, and array callback reentrancy tests pass |
| W3C subset (`wpt_subset`) | 117 test attributes present in `src/wpt_subset.rs` |
| Release binary | `v0.16.1` release binary compiled cleanly with LTO and stripped symbols |
| **Build status at refresh** | `cargo check --release`: **0 errors, 0 warnings, 27.27s** (clean gate restored) |
| Version control state | `HEAD` = `00eef70`, tag `v0.16.1`, fully merged and pushed to `github/main` |
| External browser engine code | 0 lines |
| Rendering / layout | Hand-rolled pure-Rust CPU page layout + paint; `egui_taffy` drives chrome flex layout; linked PhotoCraft engine for layered PSD/PSB |

*Counting note: earlier binders reported 224,732 / 225,307 / 228,000 / 241,730 / 244,566 / 243,543 / 253,944 "LOC." The first two came from a tool that skipped blank lines while labeling output "physical lines." The 228,000 figure mis-classified `viewers/presentation/` as uncompiled. Each later figure was correct for its tree. Chapter 03 documents every correction. Use **261,871**.*

### Build status, stated plainly

**The headline this refresh is a deletion, and it is a correction against this binder.** The SassyScript bytecode VM — which chapters 01, 02, 04 and 07 have all described as a shipped, opt-in second execution path since 0.12.x — **has been removed.** `"use vm"` matches **zero times** in `src/`. `js/vm.rs` (5,852 lines), `js/compiler.rs` (2,996), `heap.rs`, `chunk.rs`, `vm_value.rs`, `gc.rs` and twelve VM-facing builtins are gone: **14,937 lines across 22 files**, documented in `audits/2026-08-08-js-engine-consolidation-and-efficiency.md`.

The reason recorded there is the one that matters: **the VM was never DOM-wired.** It was reachable only through a `"use vm";` source directive no real page emits, its own code noted it was *"additive and not yet DOM-wired,"* and it had partial builtins and zero production callers. It cost compile time, binary size and maintenance surface and bought no capability. Consolidating on the mature, DOM-wired tree-walker is the efficiency gain; carrying two engines was the expense.

So the honest claim is now simpler than the one this binder has been making: **one JavaScript engine** — the pure-Rust tree-walking `js/interpreter.rs`, 18,664 lines, no JIT, DOM-wired, with the correctness gaps the 2026-06-10 audit documents. The no-JIT security property is unaffected and arguably strengthened: there is one non-JIT engine to reason about instead of two.

**Two capability claims withdrawn in August are reversed, because the code is now there.** A userscript manager ships — `userscripts.rs` (1,223 lines) and `userscripts_host.rs` (449), with `UserScriptManager` constructed in `browser_core.rs`, `get_scripts_for_url` called on the live navigation path in `app.rs`, 15 `GM_*` APIs, and the DevTools **User Scripts** tab now rendering the real UI rather than a placeholder. And speech-to-text is built behind an **off-by-default `whisper` Cargo feature**. Both withdrawals were correct when made on 2026-08-31; both are now stale. **Restoring a claim is as much a correction as withdrawing one**, and the restoration carries its own limits — the whisper path is an unverified port that needs unvendored static libraries to build at all, and is not presented as a shipped capability. Chapter 07 states both scopes precisely.

**The version-control disclosure that led the last two editions is closed.** PR #51 merged the working branch into `origin/main` on 2026-10-02. The tree is 7 commits ahead of `main` and 0 behind, with 6 files uncommitted, against 0/23 and 72 three weeks ago. The quarter's largest capability gain is no longer sitting on one laptop.

**The suite is green against this tree: 2,586 passed, 0 failed, 19 ignored.** The run is also the cleanest available evidence for the three claims above — zero `js::vm` cases appear in it, which is how you know 15,000 lines left the binary rather than merely losing their references; and the new userscripts, print and voice tests execute and pass, which is the difference between this refresh's restored claims and August's withdrawn ones.

**Against all of that, four things moved the wrong way and belong in the same paragraph.** `#[test]` attributes **fell 2,666 → 2,608** and the suite fell with them, **2,645 → 2,586 passing**, while the codebase grew by 7,927 lines — the VM took its 301 tests with it, and the ~80 new tests across `spreadsheet.rs` (6 → 41), `browser_ui.rs` (5 → 16), `foreman/` (63 → 80), printing, userscripts and extensions only partly offset it. A smaller suite passing completely is not the same failure as a suite that started failing, but it is not growth either. `#[allow(dead_code)]` suppressions rose **20 → 27**, the second consecutive increase and now a trend (14 → 20 → 27). The zero-warning gate is **still breached**, and although the two `script_engine.rs` warnings were resolved, **the project's own rule requires recording whether they were wired or deleted, and no record was made** — if they were wired, a known audit finding is closed and nobody wrote it down. And **nothing has been packaged in ten weeks.**

### Hard Technical Differentiators

| Capability | Chrome | Brave | Sassy Browser |
|------------|--------|-------|---------------|
| 100% memory-safe Rust engine | No (C/C++) | No (Chromium C/C++) | Yes |
| Zero Chromium / Google engine code | No | No (Chromium fork) | Yes |
| Native ad blocker (no extension) | No | **Yes** | Yes (EasyList + EasyPrivacy) |
| Fingerprint randomization / poisoning | No | **Yes** | Yes (canvas, WebGL, audio, fonts) |
| Built-in password manager | Yes | Yes | Yes (ChaCha20-Poly1305 / Argon2id) |
| 200+ file format viewers in-app (PDF, DOCX, PPTX, DICOM, PDB, RAW, 3D, CAD) | No | No | Yes |
| In-app spreadsheet with a 255-function formula engine | No | No | Yes (source only, parity unverified) |
| In-app printing across the scientific and CAD viewers | No | No | Yes (new, source only) |
| Built-in file manager sidebar (Explorer/Finder replacement) | No | No | Yes (new, integration incomplete) |
| Userscript manager with `GM_*` API | No (extension) | No (extension) | Yes (new, source only, 15 `GM_*` APIs) |
| Claymorphic themed chrome with WCAG-AAA high-contrast mode | No | No | Yes (v0.14.0, source only) |
| TLS fingerprint spoofing (Chrome-132 JA3 match) | No | No | Yes |
| MCP server (AI automation target) | No | No | Yes — **one unified 43-command protocol, privileged commands behind a user-held switch** |
| Family profiles with parental controls | No | No | Yes |
| Web3 risk education panel | No | No | Yes |

**Where the moat actually is:** Brave already ships native ad blocking and fingerprint defenses, and Chrome ships a password manager — those rows are table stakes, not differentiation, and are shown honestly above. The defensible positions are the non-Chromium memory-safe engine, the in-app universal file viewer surface, TLS-level identity control, and the MCP automation target. The engine is also the largest risk: it is 9 months old against Chromium's 18 years.

## Market Opportunity

1.8 billion desktop browser users globally. The paid software Sassy Browser displaces: Adobe Creative Cloud (~30M subscribers), Microsoft 365 (~85M subscribers), password managers (25M+ paying), scientific software ($2.6B/year).

**Beachhead markets:** Academic/research institutions (PDB/DICOM/ChemDraw replacement), independent developers (devtools + REST client), privacy-conscious consumers, Web3 early adopters.

## Traction

- Production-scale ~262K-line compiled Rust codebase -- sole technical founder
- 10+ independent security/rendering audits completed (Mercury-2 P1-P3, xAI audit, Mercury-2 r3/r4/r5, Mercury r7 render-collapse v1+v2, warning-sweep audit 2026-05-25, and a multi-agent full-codebase audit 2026-06-10)
- The 2026-06-10 audit (19 subsystem auditors + adversarial verification) surfaced 240 confirmed findings (12 critical, 68 high, 113 medium, 47 low), now driving the correctness work plan -- gaps concentrate in JS-engine semantics, CSS cascade ordering, hand-rolled layout/paint fidelity, and cookie/network security
- **A new audit artifact exists — the first in `audits/` since 2026-06-15.** `audits/2026-08-08-js-engine-consolidation-and-efficiency.md` (filesystem mtime 2026-10-02) is the audit that drove the bytecode-VM removal and corrected a set of stale "stub" labels. **It is a self-audit, not a commissioned independent review**, and the gap in independent audit coverage — now **sixteen weeks** — is unchanged by it. Roughly 25,000 lines of compiled code remain unreviewed
- **The two JavaScript engines became one (2026-10):** 14,937 lines of never-DOM-wired bytecode VM deleted across 22 files, `js/` 49 → 31 files, `script/` 16 → 12. Removed **no dependency** — the VM was first-party Rust throughout, so this is a pure reduction in maintained surface
- **The two MCP protocols became one (2026-10):** `PROTOCOL_VERSION` 2 → 3, **43 unified commands** replacing two separate 30-command vocabularies that overlapped in nine commands with incompatible field shapes — `Click{x,y}` against `Click{element_ref, button, click_count}` — and had already shipped one silent wire-drift bug. Tabs are now addressed by stable id rather than strip position; 28 JSON-RPC handlers collapsed into one testable translator; `mcp_server.rs` lost ~640 lines while gaining capability
- **Privileged MCP commands are now behind a user-held switch.** A bearer token settles *who* is calling, not *what* they may do: an agent legitimately allowed to read tabs was thereby allowed to run arbitrary script in the user's authenticated session. `ExecuteScript`, `OpenFile`, `VaultQuery` and `Cookie Set`/`Delete` are refused with `PermissionDenied` until enabled in a new **Browser Control** tab (Ctrl+Shift+O), default off, and a test fails the build if the tab advertises a command as gated that has no gate behind it
- 231 compiler warnings reduced to 0 in the 2026-05-25 sweep; 33 dead-code suppressor functions deleted. That gate held through 2026-08-16, was breached through 2026-08-31 (peaking at 47), was clean on 2026-09-07, and is **breached at 1 warning as of 2026-10-05**. `#[allow(dead_code)]` suppressions rose 20 → 27 in the same period
- **Spreadsheet formula engine wired (2026-09-14) and now tested:** 8,889 lines and 255 named functions on the live calculation path, wired with **no new crate dependency**. `viewers/spreadsheet.rs` went from 6 tests to **41** this refresh
- **Version control reconciled (2026-10-02):** PR #51 merged the working branch into `origin/main`. The 23-commit / 72-file divergence that the last two editions disclosed as the highest-priority item in this binder is closed
- Kali-style signed update infrastructure **designed and coded** (Cloudflare Workers + R2) — **public channel still silent**: `/browser/dists/stable/manifest.json` returned HTTP 404 on live check 2026-10-05, approximately **fourteen weeks** unchanged. Unsigned Windows **dev build** (44.38 MB, v0.13.1) is published separately for evaluation
- **Extension content scripts are wired into the live render pipeline** and, as of this refresh, **in the measured tree** rather than on `origin/main` only: `mod extensions;` in `main.rs`, `ExtensionManager` in `browser_core.rs` and `engine.rs`, `get_content_scripts(url)` called on the navigation path in `app.rs` and `engine.rs`. This is a code-execution-into-page path and it is **unreviewed**
- **Viewer printing (2026-10):** `print_sheets.rs` (1,541 lines, 18 tests) and `print_kit.rs` (1,109 lines, 7 tests), wired into the chemical, IGES, STEP, Parasolid, 3MF and 3D-model viewers
- **Save / Save As / Print added to twelve viewer modules** (2026-08-17, +6,443 lines): audio, DICOM, ebook, font, IGES, image, Parasolid, PDF, spreadsheet, STEP, 3MF, video. Most were read-only surfaces before this
- **Three data-loss and correctness fixes** (2026-08-16..17): Save was writing the wrong container for DOCX/XLSX/PPTX and could leave a file that no longer opened in its own application; the Open dialog could not select most supported formats; `indexedDB.deleteDatabase` dropped every database instead of the named one
- **egui / eframe 0.29.1 → 0.35** (2026-08-01): whole-chrome migration, Win32 manifest embedded in the executable. `app/explorer_ui.rs` completed the migration this refresh
- **Presentation viewer rewritten and compiled** (2026-08-16): `viewers/presentation/` (7 files, 6,146 lines, 76 tests) replaced the 881-line single-file parser. Adds PPTX/PPTM/PPSX/POTX, ODP/OTP, PowerPoint 97-2003 binary text recovery, and Keynote preview recovery; slides paint from real EMU geometry; present / edit / print-to-PDF / export with Slide, Presenter, and Outline modes. **Not yet shipped in a packaged binary and not covered by any audit**
- **File sidebar**: `src/files/` (5 files, 3,959 lines, 36 tests) — an Explorer/Finder replacement inside the browser chrome with Tree / Details / Timeline views, a filter query language, per-root view-edit permissions, and an optional SQLite whole-drive search index. New Folder, Rename, and two-click Delete are gated on Edit roots via `access_for` / `can_edit_cwd`; View roots refuse the mutation even where the OS would allow it. **The mutation paths have never been exercised in a packaged binary and have no audit coverage**
- **Foreman policy engine is deny-by-default**: unmatched targets no longer fall through to `Allow`, `[zones].open` is actually consulted, and explicit feature rules beat the open zone in both directions. `foreman/` grew to 3,624 lines and **80 tests**
- **A second new feature gate, `diagnostics`, is off by default for a security reason**: it walls off probe panels that printed overlay IPs, identity public keys, session and device ids, and a one-time recovery key. CI keeps the gated code compiling
- **Sassy Nova theme** (v0.14.0, source only): a claymorphic chrome built around a 3D icon set and now the default preset. Palette measured from the artwork rather than invented, so chrome and icons cannot drift apart. Three variants including `SassyNovaContrast`, a **WCAG-AAA high-contrast mode** made workable by a `ChromeMode` switch that drops the bitmap art for solid fills rather than fighting it. Nine-slice renderer (`theme/nova.rs`) keeps clay buttons and panel frames crisp at any DPI
- **Every Windows build ever shipped lacked an icon, version metadata, and DPI awareness** — found and fixed 2026-08-27. `build.rs` pointed `set_icon` at an untracked `.ico`; `rc.exe` failed; the failure was swallowed as a printed warning, so the *entire* resource block — including the application manifest declaring per-monitor-v2 DPI awareness — was silently dropped from every build. Resource failures now fail the build. Two icon-rendering defects were fixed alongside it, and a new test fails the build if any icon name in the UI resolves to no asset
- Post-0.13.1 engine work: DevTools Network dual-write, FOUC / Next.js `partially-hydrated` unlocks, MutationObserver delivery on the egui path, deeper image/PDF editor surfaces -- live smoke still honest (2 pass / 5 partial / 3 fail across ten sites; SPA giants still fail primary UX)
- WireGuard-first network setup in the first-run wizard; Tailscale demoted to third-party fallback
- 5 CAD interchange viewers shipped in v0.10 (STEP, IGES, 3MF, OpenSCAD, Parasolid) on top of 200+ file formats
- Website live at sassyconsultingllc.com (HTTP 200, 547 ms, verified 2026-10-05)
- Source repository is **private** at github.com/sassyconsultingllc/ACE — it returns 404 to unauthenticated visitors (re-confirmed 2026-10-05 from the workstation's own network). Diligence access is by invite

### The disclosure a diligence reader should see first

**For the last two editions this section disclosed that the binder measured a tree no commit and no remote matched. That is resolved.** PR #51 merged the working branch into `origin/main` on 2026-10-02; `HEAD` is 7 commits ahead of `main` and 0 behind, with 6 files uncommitted. The figures in this binder are now reproducible from the public line to within a week of ordinary work.

What replaces it is smaller and different in kind. **This refresh found that the binder had claimed a capability for four consecutive editions that the code did not have** — the bytecode VM, present and described in four chapters, deleted in the source. That is the same class of error as the August userscript and voice overclaims, and it was found the same way: by re-measuring the repository rather than by reading the documents. Cross-chapter consistency checking could never have caught it, because every chapter agreed, consistently, and all of them were wrong.

The reciprocal also happened this refresh, and is worth as much: **two claims this binder had correctly withdrawn are now true again**, and were found stale by the same re-measurement. The process cuts both ways, which is the only version of it worth having.

The practical read for an investor: the engineering is real, the integration risk that dominated the last two editions has been closed, and the measurement discipline catches its own errors in both directions — but it catches them weekly, not continuously, and **the gap between what is built and what any user can run is now ten weeks wide.**

### Claims withdrawn and restored (history)

- **Bytecode VM — withdrawn 2026-10-05.** Described in chapters 01, 02, 04 and 07 as a shipped opt-in execution path since 0.12.x. Deleted in source; `"use vm"` matches zero times. One JS engine remains.
- **User script manager — withdrawn 2026-08-31, restored 2026-10-05.** The withdrawal was correct: the drafts were unwired and were deleted 2026-09-07. A real manager has since been built and wired.
- **Whisper voice transcription — withdrawn 2026-08-31, partially restored 2026-10-05.** The withdrawal was correct: the engine was dead and was deleted 2026-09-02. A feature-gated, off-by-default implementation now exists and is **not** claimed as a shipped capability. See chapter 07.
- **`js/builtins/` "14 modules, 4,318 lines" — withdrawn 2026-10-05.** It is two files, 237 lines: `mod.rs` and the EIP-1193 `ethereum.rs`, the only builtin bound to the interpreter rather than to the deleted VM.

How those overclaims were found and closed remains diligence-relevant, and the pattern is stable: **the documents are corrected by measuring the code, on a weekly cadence, in public, in whichever direction the measurement points.**

## The Ask

$800K SAFE note. Funds engineering (senior Rust hire), infrastructure, legal/IP protection, and 24-month operating runway.

---

**Shane Smith** | Founder & CEO | shane@sassyconsultingllc.com
