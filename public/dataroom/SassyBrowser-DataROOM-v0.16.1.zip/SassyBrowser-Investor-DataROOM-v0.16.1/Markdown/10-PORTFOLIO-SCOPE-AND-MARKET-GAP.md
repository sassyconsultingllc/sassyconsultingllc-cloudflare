<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-QT7HXMR2VKD9
-->
# Portfolio Scope & Market Gap Analysis

**Sassy Consulting LLC | 15-project inventory | Updated 2026-10-05** (browser code figures recounted; non-browser scope narrative unchanged since 2026-07-31)

---

## How to read this document

This chapter states the **delivered scope** of each project in the Sassy Consulting portfolio, then analyzes the **market need and operational gap** that project addresses. It is the qualitative half of a two-part working document; the quantitative half — unit economics, ROI, and the five-year three-scenario cost and income model — is Chapter 11, *Portfolio Economics & ROI*.

**Standing assumption.** Per the modeling brief, every project in this chapter is described **as if fully realized**: shipped to production, signed, distributed, supported, and scaled to its addressable segment. Where a project is not there today, the delta between current state and the fully-realized state is stated explicitly in a *Delta to production* line. Nothing here should be read as a claim about what is shipping on 2026-07-31.

**Honesty constraints inherited from Chapter 09.** Sassy Browser is v0.13.1, not v2.0.0. The public signed update manifest returns 404. Live-site smoke is 2 pass / 5 partial / 3 fail. File viewers are viewers, not claimed replacements for Photoshop, Excel, Acrobat, or ChemDraw. Non-browser file counts were last fully walked 2026-03-18 and are marked as estimates. Those constraints apply to every statement below.

**Tiering.** Projects are grouped by commercial posture, not by engineering effort or personal attachment:

| Tier | Definition | Projects |
|------|------------|----------|
| **1 — Platform** | Original IP with an independent, defensible market and a multi-year revenue curve | Sassy Browser, SassyTalkie, Guard, WinForensics-Pro, SassyMCP |
| **2 — Product** | Complete or near-complete applications with a direct consumer or prosumer revenue path | Foodie Finder, CF Admin Mobile, NetGuard Dashboard |
| **3 — Services & client assets** | Revenue-generating today via client work or productizable service delivery | Riverview Adventure Co., RACRUST CMS, WordPress Plugins, Consulting Website, Security Audit Scripts |
| **4 — Internal enablement** | No direct revenue line; measured by cost avoided and capability unlocked in other tiers | SDR Radio Toolkit, Wyze NVR Integration |

---

# Tier 1 — Platform

## 1. Sassy Browser

**Status:** Active development · v0.13.1 · `github.com/sassyconsultingllc/ACE`
**Codebase:** 291 compiled `.rs` files · 322,386 compiled physical lines under `src/` (recount 2026-10-05) · 2,608 `#[test]` attributes, **all compiled** — **down 58**, because deleting the never-DOM-wired bytecode VM (14,937 lines across 22 files) deleted its 301 tests · **zero files present in the tree but unwired**, for a second refresh, though **12 declared modules contain no code at all** (49 lines, comments only) · full suite **2,586 passed / 0 failed / 19 ignored** (2,605 run) · `cargo check --release` **0 errors, 1 warning** — the zero-warning gate is still breached, and `#[allow(dead_code)]` suppressions rose 20 → 27. **The working tree is now 7 commits ahead of `origin/main` and 0 behind, with 6 files uncommitted** — the 23-behind / 72-uncommitted divergence that qualified every prior edition of this figure was closed by PR #51 on 2026-10-02, so a clone of `origin/main` reproduces these figures to within a week of ordinary work.
**Revenue model:** Freemium desktop application · Pro tier · institutional site licensing · file-conversion API

### Scope

A privacy-first desktop web browser written entirely in Rust with **zero Chromium, Blink, Gecko, or WebKit code in the tree**. The delivered scope spans five subsystems that are conventionally four separate products:

1. **Rendering stack.** HTML5 parsing (html5ever) into a custom tree walker; hand-rolled pure-Rust CSS cascade with flex, grid, and block layout; CPU software rasterizer (`paint.rs`); `egui_taffy` driving chrome flex layout. HTTP/1.1 and HTTP/2 with Chrome-132 JA3 TLS fingerprint matching. Async document navigation and async `fetch()` off the UI thread.
2. **JavaScript engine.** SassyScript — a **23,079-line** pure-Rust tree-walking interpreter (`src/js/interpreter.rs`), no JIT, DOM-wired. **One engine.** Prior editions described a second, opt-in register/stack bytecode VM with its own garbage collector, enabled per-script via a `"use vm";` directive. **It was deleted on 2026-10-05** — 14,937 lines across 22 files — because it had never been DOM-wired, could not touch a page, had zero production callers, and was reachable only through a directive no real page emits. The Boa fallback was removed in 0.13.x; SassyScript's tree-walker is now the sole engine, singular.
3. **Universal file viewer.** 200+ formats across 28 wired viewer modules: PDF with annotation and print-to-PDF, DOCX/XLSX/RTF/EPUB/MOBI, a full presentation stack rewritten in August 2026 (PPTX/PPTM/PPSX/POTX, ODP/OTP, legacy `.ppt` text recovery, Keynote preview recovery, EMU-accurate slide painting, present/edit/print-to-PDF/export — theme inheritance, charts, and animation still unclaimed), DICOM medical imaging (hand-rolled parser), a chemistry stack (SMILES-to-3D, Gasteiger charges, NMR/IR prediction), 3D meshes (OBJ/STL/GLTF/PLY/DXF), five CAD interchange formats (STEP, IGES, 3MF, OpenSCAD, Parasolid), archives, and a layered raster image editor. **Spreadsheet formula support is now the first-party `viewers/formula/` engine** — 8,889 lines, a real lexer/parser/evaluator with a typed error model and **255 named functions**, wired to the live cell path in September 2026 and added with no new crate dependency; its call site gained tests this refresh (`spreadsheet.rs` 6 → 41). The prior figure of "roughly 60 functions in the shipping evaluator" described the hand-rolled evaluator it replaced, which was deleted. **Still not Excel parity**: 255 is not the ~500 of modern Excel, and structured and cross-sheet references are unverified. **New October 2026:** printing across the chemical, IGES, STEP, Parasolid, 3MF and 3D-model viewers (`print_sheets.rs` + `print_kit.rs`, 2,650 lines, 25 tests).
6. **File manager.** A new `src/files/` sidebar (August 2026) putting an Explorer/Finder replacement inside the browser chrome: Tree, Details, and Timeline views over one row set, a filter query language, per-root view/edit permissions, and an optional SQLite whole-drive search index. **Integration is unfinished.** Of the nine previously-uncalled symbols, three were wired and six deleted in September 2026. **Correction:** an earlier edition reported `can_edit_cwd` as deleted rather than wired; it is **present and load-bearing** — it and `access_for` gate New Folder, Rename and two-click Delete so that View roots and mounted roots refuse the mutation even where the OS would permit it. The reason it is still "unfinished" is different: **the mutation paths have never run in a packaged binary and have no audit coverage**, and a file-deletion gate exercised only in dev builds is not a finished capability. The module measured 3,959 lines / 36 tests this refresh, down from 4,346 / 39, with no cause identified.
4. **Security and identity.** Four-layer sandbox (network, render, content, download); native ad blocking on EasyList/EasyPrivacy/Fanboy with no extension surface; fingerprint poisoning across canvas, WebGL, audio, and fonts; ChaCha20-Poly1305 + Argon2id password vault; cookie inventory panel with raw wire-format inspection and SameSite enforcement; PIN-locked family profiles with parental controls and one-time recovery keys.
5. **AI automation surface.** A built-in MCP server (stdio JSON-RPC and native bincode WebSocket) over **one unified 43-command protocol** (`PROTOCOL_VERSION` 3, October 2026 — it replaced two separate 30-command vocabularies that overlapped in nine commands with incompatible field shapes), an MCP client, a **seven-tab** Control Center, an encrypted key vault bound to the OS credential store, and a deny-by-default Foreman policy engine for security-zone protection. **Privileged commands are behind a user-held switch**: `ExecuteScript`, `OpenFile`, `VaultQuery` and `Cookie Set`/`Delete` are refused until the user enables them in a new Browser Control tab, default off, with a test that fails the build if the tab advertises a gate the code does not enforce.

**Explicitly out of scope:** WebRTC, ServiceWorker, WebGL rendering context, in-page `<video>`, GPU page paint, multi-process sandbox isolation. These are roadmap items, not shipped capability.

### Market need and operational gap

The structural gap is **engine monoculture**. Every mainstream browser renders through an engine controlled by a company whose revenue depends on advertising or platform lock-in. Chrome, Edge, Brave, Arc, Opera, and Vivaldi are all Blink. Safari is WebKit. Firefox is the sole meaningful independent, and its market position has been contracting for a decade. A user who wants a browser that is not architecturally aligned with an advertising business has, in practice, one option.

Three operational consequences follow, and each is the specific gap Sassy Browser addresses:

**Gap 1 — Memory-unsafe attack surface at the most-exposed layer.** Browsers are the single largest untrusted-input processor on any desktop. Every mainstream engine is C or C++ with a JIT compiler. Memory-safety defects have consistently accounted for roughly two thirds of severe browser CVEs, and JIT compilation is a recurring exploitation primitive. Sassy Browser removes both categories by construction: the tree is pure Rust and there is no JIT. This is not a claim of fewer bugs in absolute terms — the 2026-06-10 multi-agent audit surfaced 240 confirmed findings — it is a claim about *which classes* of bug are structurally impossible.

**Gap 2 — Extension trust is a broken security model.** The functionality users most depend on (ad blocking, password management) is delivered by third-party extensions with broad host permissions and silent auto-update. Extension supply-chain compromise is a recurring, well-documented incident category, and Chrome's Manifest V3 transition materially degraded the capability of the leading content blocker. Sassy Browser moves ad blocking and the password vault **into the binary**, where they are covered by the same signing and audit chain as the engine. There is no extension to compromise.

**Gap 3 — The browser is the most-used application and the least capable file handler.** A knowledge worker sits in a browser for the majority of the working day, then leaves it to open a PDF, a spreadsheet, a DICOM study, a molecular structure, or a CAD interchange file — each in separate, separately-licensed software. Independent chemistry, medical imaging, and CAD tooling carry four-figure annual per-seat costs. Sassy Browser's 200+ format viewer collapses the *viewing and light-editing* portion of that stack into the application already open. The honest framing, and the one used in all external material: this displaces the **viewer seat**, not the authoring seat. A lab that needs 40 people to *read* structures and 3 people to *draw* them can buy 3 ChemDraw licenses instead of 43.

### Competitive position

| | Chrome | Firefox | Brave | Ladybird | Servo | Sassy Browser |
|---|---|---|---|---|---|---|
| Engine independence | No | Yes | No | Yes | Yes | Yes |
| Memory-safe implementation | No | No | No | No | Yes | Yes |
| No JIT attack surface | No | No | No | No | No | Yes |
| Complete shipping application | Yes | Yes | Yes | Pre-alpha | No (engine only) | Yes (dev build) |
| Native ad blocking | No | No | Yes | No | No | Yes |
| 200+ file viewers | No | No | No | No | No | Yes |
| Native AI/MCP automation target | No | No | No | No | No | Yes |

The defensible statement: **Sassy Browser is the only pure-Rust browser that ships as a complete desktop application.** Servo is a rendering engine without a browser around it. Ladybird is pre-alpha and written in C++, forfeiting the memory-safety argument. Neither has a file-viewer layer or an automation surface.

### Delta to production

**Release binary:** v0.16.1 release packaged with full LTO and stripped symbols, against a tree that compiles with one warning and a green suite, so this is process rather than engineering; **get the two script-injection paths reviewed before they ship** (the userscript `GM_*` surface and extension content scripts, 10 tests and no audit between them); close the critical and high findings from the 2026-06-10 audit (JS equality semantics, parser gaps, CSS shorthand ordering and inheritance, cookie SameSite/Domain validation); publish the **signed** stable update channel (still 404 after ~fourteen weeks); ship an Authenticode-signed Windows installer, Linux packages, and a macOS build; take live-site smoke from 2 pass / 5 partial / 3 fail to broad SPA compatibility; stand up a GPU render path. *(The item "mature the bytecode VM to default runtime" is removed: the VM was deleted 2026-10-05 without ever being DOM-wired, so there is no partial implementation to finish — a faster JS runtime now restarts from a design decision.)* This is the primary use of the senior Rust engineering hire.

---

## 2. SassyTalkie

**Status:** Near-complete — Android primary, desktop secondary
**Stack:** Kotlin/Compose hosting Rust `libsassytalkie` via JNI · shared `core` crate · Tauri 2.0 desktop
**Revenue model:** App store freemium · team/organization tier · self-host license

### Scope

A cross-platform push-to-talk communications application with end-to-end encryption. Delivered scope: instant PTT over cellular and Wi-Fi; ML-KEM post-quantum key encapsulation; sealed-sender metadata protection; relay store-and-forward for offline recipients; channel management including radio and emergency channels; Bluetooth RFCOMM and hardware PTT button support; noise suppression; live translation scaffolding; QR-based contact import; and documented self-hosting for the relay.

**Explicitly out of scope:** Wear OS and Android Auto (deferred); carrier interconnect; LMR gateway to P25/DMR trunked systems.

### Market need and operational gap

Push-to-talk over cellular is a **$8.2B market growing at roughly 9% CAGR**, but it is served almost entirely by two unsatisfying poles.

At one pole sit the carrier and vendor PoC platforms — Motorola WAVE, Zello Work, Hytera, AT&T EPTT. These are competent, expensive, per-seat, and require trusting a vendor's servers with the audio path and the metadata. There is no self-host option and no post-quantum posture.

At the other pole sit consumer messaging apps with a voice-note feature bolted on. These are free and ubiquitous but are not push-to-talk: latency is wrong, the interaction model is wrong, and there is no channel concept, no hardware button, and no offline relay.

**The gap is the middle.** Organizations that need genuine PTT semantics *and* cryptographic sovereignty currently have no product to buy. The concrete populations:

- **Volunteer and municipal emergency response** — search and rescue, CERT teams, fire auxiliary, event medical. They need channel discipline and reliability but cannot fund a Motorola contract, and they handle information (casualty details, locations of vulnerable people) that should not transit a vendor's cloud unencrypted.
- **Small industrial and construction crews** — 5 to 50 people who have aged out of licensed LMR but for whom per-seat PoC pricing is punitive.
- **Privacy-motivated and threat-model-aware users** — journalists, private security, protective details. Sealed sender and post-quantum key exchange are directly load-bearing for these users; no mainstream PoC product offers either.
- **Self-hosting organizations** — where the requirement is not price but *control*: the relay runs on infrastructure the customer owns.

The operational gap in one sentence: **existing PoC assumes the vendor is trusted; SassyTalkie assumes the vendor should not have to be.**

### Competitive position

Zello and WAVE win on network effect and enterprise integration. SassyTalkie wins on three axes they cannot easily follow: post-quantum cryptography as a default rather than a roadmap item, sealed-sender metadata protection, and a supported self-host path that is directly contrary to their SaaS revenue model. The Rust core shared across Android, desktop, and iOS is a maintenance-cost advantage that compounds.

### Delta to production

Complete settings and navigation wiring for the remaining panels; sealed-context handling at QR import; multi-peer field validation at realistic crew sizes; Play Store and App Store submission; independent cryptographic review of the PQC and sealed-sender implementation before any security marketing claim is made; relay capacity and cost modeling; desktop client from 20% to parity.

---

## 3. Guard Security Monitoring System

**Status:** Active development *(file inventory last walked 2026-03-18 — treat counts as estimates)*
**Stack:** Electron/Vite/Tauri command center · React Native · Go backend · Python services · Rust SDR · C/H firmware interfaces
**Revenue model:** SaaS subscription, prosumer and SMB tiers

### Scope

A unified physical-and-RF security monitoring platform that fuses sensor classes normally sold as separate products into a single command center on port 3847 with Socket.IO real-time transport:

- **BLE surveillance** via nRF52840 dongle — device discovery, persistence tracking, and unknown-tracker detection
- **Wi-Fi monitoring** — rogue AP detection, deauthentication detection, client inventory
- **RF and radio** — P25 monitoring via DaneCom/DSDPlus, RTL-SDR spectrum survey, HackRF analysis
- **Cellular** — Cradlepoint-backed cellular presence and out-of-band alerting
- **Video** — Wyze camera feeds via the Docker NVR bridge (project 15)
- **Unified radar display** — a single spatial and temporal view correlating all of the above

### Market need and operational gap

The US home security market is **~$17.4B in 2026 growing at ~7.6% CAGR**, and the decisive structural shift is that **49% of alarm users now self-install** and professional monitoring ranks ninth of twelve purchase factors. The market has moved to consumer-managed security. Simultaneously, subscription relationships are demonstrably worth ~20% more lifetime value than hardware-only sales, which is why every incumbent is racing toward recurring revenue.

The gap Guard fills is **sensor-domain fragmentation**.

A homeowner or small-site operator who wants genuine situational awareness today assembles: Ring or Wyze for video, a separate app for Wi-Fi intrusion, nothing at all for BLE tracker detection, a hobbyist SDR stack for RF, and a spreadsheet to correlate them. Each vendor sees one slice. **No consumer or prosumer product correlates RF, BLE, Wi-Fi, cellular, and video into one timeline.** That correlation is precisely where the signal lives — a BLE tracker that appears at the same time each evening, an unfamiliar Wi-Fi client that coincides with a camera motion event, an RF transmission that precedes both.

The secondary gap is **BLE tracker stalking detection**, which is now a mainstream safety concern with an inadequate answer. Platform-native detection (Apple and Google's cross-platform specification) is deliberately conservative, notifies late, and covers only participating manufacturers. A dedicated nRF52840 receiver with persistence logic catches what the phone-based implementations are designed to miss.

Target segments in priority order: prosumer homeowners with a security interest and existing camera investment; small commercial sites (self-storage, marinas, contractor yards, rural clinics) that are under-served by commercial alarm contracts; and event or temporary-site security where deployment speed matters more than permanence.

### Competitive position

Ring, SimpliSafe, and Wyze own consumer video and are effectively unassailable there. Guard does not compete on cameras — it **consumes** them (the Wyze bridge is a deliberate integration, not a rebuild). Enterprise SIEM and physical-security platforms (Genetec, Milestone) do correlate multiple domains, at enterprise price points and complexity. Guard's position is the empty middle: multi-domain correlation at a prosumer price, with hardware the customer already owns or can buy for under $200.

### Delta to production

Re-walk and verify the file inventory; consolidate the multi-runtime stack (Electron + Tauri + React Native + Go + Python is a maintenance liability at scale); harden the command center for untrusted-network exposure; define and cost the video storage and egress model, which is the dominant variable cost and the main constraint on gross margin; complete NetGuard Dashboard (project 11) or formally fold its scope in; ship a supported hardware bundle so onboarding does not require an RF hobbyist.

---

## 4. WinForensics-Pro

**Status:** Production-Ready Forensic Suite · Dual Engine (Dead-Disk Triage + Real-Time SectorScope I/O) · Native Win95 `egui` GUI
**Revenue model:** Tiered per-seat licensing, live on Cloudflare D1 + Stripe

### Scope

A comprehensive Windows host forensics, real-time disk inspection, and incident-response workstation platform. Delivered scope encompasses two complementary engines unified under a single native UI:

1. **Dead-Disk Artifact Engine:** High-speed rotating filesystem scanner; Prefetch, ShimCache, BAM, and Amcache parsers; Windows Registry hive triage; Authenticode signature validation for binary trust verification; memory and raw disk acquisition; threat-indicator IOC matching; and automated report generation.
2. **Integrated SectorScope Engine (`disk-core`):** Kernel- and userspace-tier real-time I/O capture via Windows FltMgr minifilter and NTFS USN Change Journal. Features a 2D cluster map modeled on classic Windows 95 Defrag, real-time I/O event streaming with process attribution, bidirectional block-to-file extent inspection, 3-layer deep content decode (L1 raw hex/ASCII, L2 structural headers for PE/SQLite/JSON, L3 plain-language forensic summary), and live throughput telemetry HUD.
3. **Period-Accurate Workstation GUI:** High-performance, distraction-free Windows 95/NT aesthetic built in `egui` with 1-pixel beveled lighting, XP silver palette, discrete segmented block progress meters, property sheet navigation, and an interactive timeline ribbon.
4. **Licensing & Field Air-Gap Support:** Cloudflare D1 entitlement integration with Stripe billing and 30-day cryptographically-signed offline lease tokens for air-gapped forensic cleanrooms.

**Explicitly out of scope:** court-admissible chain-of-custody hardware attestation without third-party validation; macOS and Linux host artifacts; full memory-image analysis at Volatility parity.

### Market need and operational gap

Digital forensics is a **$8.4B–$17.9B market, growing at 11–16% CAGR**. The market is bimodal and polarized:

- **High-end enterprise suites** (EnCase, Magnet AXIOM, Cellebrite) run $5,000–$15,000/seat/year, are procurement-heavy, and require invasive agents or hardware dongles.
- **Low-end free toolchains** (Eric Zimmerman tools, Autopsy, KAPE) are unassembled, CLI-only, and lack unified real-time correlation.

**The bundled SectorScope integration solves the practitioner's operational gap**:
A dead-disk tool tells you what happened in the past; SectorScope tells you what is happening *right now*. Bundling live disk I/O monitoring with post-mortem artifact triage transforms WinForensics-Pro from an episodic utility into an always-on incident response and threat-hunting workstation.

### Commercial Tiering & Product Gating

- **Community Tier (Free / Practitioner):** Full dead-disk artifact scanner, standard live event feed, 8k cluster map visualization, basic report export.
- **Enterprise Workstation Tier ($1,800–$3,500/seat/year):** Unlocks L1–L3 deep content decode, extreme 131k cluster resolution, continuous minifilter pre-cache I/O capture, raw JSONL/CSV forensic timeline export, and priority offline air-gap leases.

### Delta to production

The native GUI and SectorScope integration are complete and verified clean. Remaining work: Authenticode signing certificate acquisition, automated WiX MSI packaging, and validation against the NIST Computer Forensic Reference Data Set (CFReDS).

---

## 5. SassyMCP

**Status:** Production · v1.14.2 · open source at `github.com/sassyconsultingllc/SassyMCP`
**Revenue model:** Open-source core · commercial support · hosted tier · enterprise licensing

### Scope

A unified Model Context Protocol server providing an AI agent with operational control of a working environment. Delivered scope spans desktop automation (screen capture, OCR, window and input control), Android device control via ADB and scrcpy, GitHub operations across issues/PRs/branches/protection/scanning, filesystem and shell access with a destructive-action interceptor and tiered confirmation, network and RF forensics, a persistent memory and session-handoff system, cross-agent coordination, and a self-modification subsystem with rollback. Distribution as MSI, portable ZIP, DXT package, and VS Code extension.

**Explicitly out of scope:** multi-tenant hosting (single-operator today); formal RBAC; SOC 2 attestation.

### Market need and operational gap

MCP crossed **97 million monthly SDK downloads** by March 2026, **41% of surveyed software organizations** report limited or broad production use, and there are **10,000+ public MCP servers**. In December 2025 Anthropic donated the protocol to the Agentic AI Foundation under the Linux Foundation, making it vendor-neutral. The protocol question is settled; the tooling question is not.

The gap is **fragmentation and safety in the server layer**. The typical MCP deployment is a dozen narrow servers — one for GitHub, one for the filesystem, one for a database — each with its own configuration, auth model, and failure mode, and most with no audit trail or destructive-action guard. An agent with shell access and no interceptor is an incident waiting for a schedule.

SassyMCP's differentiated position is threefold:

1. **Breadth in one process.** Desktop, mobile, network, VCS, memory, and shell behind a single configuration and a single tool catalog, with tool-group toggles so the exposed surface is deliberate rather than accidental.
2. **Safety as an architectural feature.** The shell interceptor, the tiered destructive-action confirmation flow, the audit log with false-positive tracking, and path validation that refuses `~/.ssh` and `~/.aws` regardless of configuration. This is the layer that lets an organization put an agent near production, and it is the layer most MCP servers do not have.
3. **Physical-world reach.** Android control, screen OCR, RF and network forensics are outside what a cloud-hosted MCP server can offer at all.

The commercial thesis is not "sell an MCP server." It is that the enterprise adoption curve for agentic tooling — 40% of enterprise applications carrying task-specific agents by end of 2026, per Gartner — creates demand for a **governed** agent-to-infrastructure layer, and governance is where the willingness to pay concentrates. Open-source core drives adoption; the audit, policy, and support layer is the product.

### Competitive position

The reference MCP servers are single-purpose and unopinionated about safety. Commercial agent platforms are closed and cloud-bound. SassyMCP is the broad, local-first, safety-instrumented option — and it carries an unusual proof point: it is the tool with which the other fourteen projects in this portfolio were built. That is a demonstrable productivity claim rather than a marketing one.

### Delta to production

Multi-tenant hosting for a managed tier; formal RBAC and per-agent capability scoping; published security model and threat documentation; SLA-backed support tier; enterprise-grade audit export; a contributor community substantial enough that the open-source core is not a single-maintainer dependency.

---

# Tier 2 — Product

## 6. Foodie Finder

**Status:** Complete · feature-complete for store submission · TypeScript / React Native / Expo
**Revenue model:** App store — freemium with Pro tier and advertising

### Scope

A restaurant discovery application. Delivered scope: semantic search over a vector index; multi-source scraping and aggregation; sentiment analysis of review text; menu-photo classification; taste-profile recommendation; community tips; 18 cuisine filters; a random picker for decision fatigue; a regional feature (Culver's Flavor of the Day calendar); and a Cloudflare Workers backend using D1, KV, R2, and Vectorize with a tRPC API.

### Market need and operational gap

Discovery is not the gap — Google Maps and Yelp have solved *finding* restaurants. The gap is **decision quality and decision fatigue**.

Incumbent discovery is optimized for advertiser revenue and aggregate star ratings. A 4.2-star average tells a user nothing about whether *this* user will like the place. The genuine unmet need is taste-personalized matching: semantic search over what a user actually wants right now ("somewhere quiet with good vegetarian options that isn't loud"), weighted by their revealed preferences, rather than keyword-matched against a paid-placement index.

The secondary gap is **the choosing problem itself** — the well-documented behavior where a group cannot converge on a restaurant. The random picker addresses this directly and is the kind of feature incumbents will not build because it reduces session time.

Honest assessment of the commercial reality: this is the **most competitive market in the portfolio and the hardest to acquire users in**. Consumer discovery apps face high CAC against zero-marginal-cost incumbents with default placement. The realistic path is regional density — win a metro area (Madison and south-central Wisconsin, where the Culver's feature is a genuine local hook) with content and community rather than paid acquisition, then expand metro by metro. Modeled conservatively in Chapter 11 for exactly this reason.

### Delta to production

Close the security items already logged in `ACTION_ITEMS_THAUDIT.md` **before submission**: gate or remove the debug endpoints leaking headers and secrets, remove the tRPC debug header injection, add authentication and validation to the menu upload endpoint, lock CORS from wildcard to app domains, add rate limiting to the search endpoint. Add the dietary-filter disclaimer. Sync the client `AppRouter` type with the production worker router. Then: store submission, ASO, and a regional content and community launch.

---

## 7. CF Admin Mobile

**Status:** Active development · ~95% of tracked items complete · TypeScript / Expo · 14 screens
**Revenue model:** Prosumer developer subscription

### Scope

Mobile management for Cloudflare infrastructure: DNS records, Workers, R2, D1, KV, zone settings, analytics, and cache operations, on a tRPC and Drizzle ORM backend. Fourteen screens, fifteen-plus components.

### Market need and operational gap

Cloudflare's own dashboard is a desktop-first web application that is workable but unpleasant on a phone, and Cloudflare ships no first-party mobile app. For a specific and real operational moment — an incident at 2am, a DNS change needed from a car park, a Worker to roll back while away from a laptop — the current answer is pinch-zooming a desktop dashboard or SSHing to something that has `wrangler` installed.

This is a **narrow, genuine, and well-defined gap**: a purpose-built mobile client for an infrastructure platform with millions of users and no mobile story. The buyer is a developer or small-team operator who already pays for infrastructure and has demonstrated willingness to pay for tooling that reduces incident friction.

Realistic sizing: this is a small, high-margin product, not a platform. It is modeled that way. The strategic value beyond its own revenue is that it exercises the same Expo, tRPC, and Workers stack as Foodie Finder, so engineering investment is shared across two revenue lines.

### Delta to production

Push notifications (the feature that converts this from a convenience to an incident tool); MCP client integration; offline support; Play Store release; API-token security review, since this application holds credentials with broad infrastructure authority and that is the single largest risk in the product.

---

## 8. NetGuard Dashboard

**Status:** Paused — backend ~80%, frontend ~60% · deprioritized for the Guard command center
**Revenue model:** SaaS subscription (conditional on resumption)

### Scope

A network security audit and monitoring dashboard: scheduled and on-demand scanning, device inventory, vulnerability surfacing, and reporting. TypeScript and React.

### Market need and operational gap

The gap is **network visibility for organizations below the SIEM threshold**. A 20-to-200-person company has a real network attack surface and no security team. Enterprise NDR and SIEM platforms are priced and staffed out of reach; the free alternatives (nmap, OpenVAS, Security Onion) require an operator who knows what they are looking at. The unserved need is scheduled, automated, plain-language network assessment with a report that a non-specialist can act on — which is also precisely the artifact that MSPs and consultants need to justify remediation work to a client.

### Honest assessment

**This project is paused for a defensible reason and should be evaluated as an option, not an asset.** Its scope overlaps materially with the Guard command center's Wi-Fi and network monitoring layer, and continuing both in parallel was duplicating effort. Three outcomes are legitimate, and the decision should be explicit rather than drift:

1. **Fold in.** Merge the completed backend into Guard as its network-audit module. Lowest cost, no separate go-to-market, and it strengthens Guard's SMB positioning.
2. **Resume as a separate product.** Justified only if the SMB network-audit buyer proves genuinely distinct from the Guard buyer — a different sale, a different channel (MSP resale), and a different price point.
3. **Retire.** Harvest the useful code and stop carrying it in the portfolio.

Chapter 11 models NetGuard as resuming in Year 2 under the perfect and expected cases and as retired under the marginal case. Recommendation: **decide by end of Q4 2026**; a paused project in a fifteen-project portfolio is a credibility cost in diligence.

---

# Tier 3 — Services & Client Assets

## 9. Riverview Adventure Co.

**Status:** Live · Rust on Cloudflare Workers · 55 `.rs` + 38 HTML + 11 JS
**Revenue model:** Client retainer, hosting, and enhancement work

### Scope

A full-stack website and administrative dashboard for a Wisconsin adventure-tourism operator: public site, booking and enquiry flows, PDF generation, six external API integrations, D1 and R2 backing, and an admin console. Deployed on Cloudflare Workers with a Rust worker runtime.

### Market need and operational gap

The client-side gap is ordinary and real: a seasonal tourism business needs booking, content, and operational tooling and cannot afford enterprise hospitality software or an agency retainer at agency rates.

The **portfolio-relevant** gap is different and more important. Riverview is the **reference implementation and credibility asset** for a Rust-on-Workers delivery practice. Nearly every regional agency builds on WordPress or a JavaScript framework hosted on conventional infrastructure. A Rust Worker deployment gives a small client edge-global latency, near-zero hosting cost, no server to patch, and no plugin-vulnerability surface — a materially better product at a lower operating cost than the regional standard. Riverview proves that in production, which is what converts the next prospect.

Its second function is **cash flow**. Client revenue is the only line in this portfolio that is real, recurring, and independent of a fundraise. In the marginal scenario it is a substantial share of what keeps the operation solvent.

### Delta to production

Already live. Fully-realized state means: formalizing the retainer rather than working ad hoc, documenting the architecture so it is transferable, and completing the RACRUST consolidation (project 14) so one codebase serves the whole client family.

---

## 10. RACRUST CMS

**Status:** In progress · Rust v5.0.0 · consolidating into `riverview-rust`
**Revenue model:** Client delivery, then productized licensing

### Scope

A Rust content-management system running on Cloudflare Workers with a WASM dashboard and modular content types. Currently three related codebases (`RACRUST`, `riverview-rust`, `riverviewadventurecompany-worker`) sharing architecture and being consolidated into one.

### Market need and operational gap

The gap is at the **bottom of the CMS market, on the operating-cost axis**. WordPress powers a large share of the web and carries a well-known cost: plugin vulnerabilities, constant patching, and hosting that grows with traffic. Headless alternatives (Contentful, Sanity, Strapi) solve the security problem and introduce a subscription plus a build pipeline that a small business cannot maintain.

A Rust CMS on Workers occupies a position neither serves: no server to patch, no plugin ecosystem to be compromised through, hosting cost that rounds to zero at small-business traffic, and edge-global performance by default. For a regional agency serving small-business clients, that is a structurally cheaper and safer product to operate — the delivery margin comes from *not* spending billable hours on maintenance.

The honest limitation: this is **not** a general-purpose CMS competing with WordPress on features or ecosystem, and should never be positioned as one. It is a delivery vehicle for a specific practice serving a specific client profile. Modeled accordingly.

### Delta to production

Complete the three-codebase consolidation into a single maintained line; separate the template layer from the engine so a new client site is configuration rather than a fork; document the deployment path; decide whether it is licensed to other agencies or retained as internal delivery tooling.

---

## 11. WordPress Plugins

**Status:** Live · 55 files · PHP / JS · security-hardened
**Revenue model:** Client revenue, optional marketplace listing

### Scope

Client-facing WordPress work: the Prairie du Sac River Safety Dashboard (v3.0.0, integrating USGS hydrological and weather APIs), Riverview themes, and associated hardening.

### Market need and operational gap

Two distinct needs. The River Safety Dashboard fills a **genuine civic information gap** — real-time river conditions presented for public safety decisions in a river community, which is exactly the kind of application that has clear public value and no commercial provider. The theme and hardening work fills the ordinary need of clients who are on WordPress and are going to stay there.

Strategically this is a **bridge asset**. It keeps a delivery relationship with clients who are not candidates for a Rust rewrite, and it produces the security-hardening reference work that supports the consulting practice. It is not a growth line and is not modeled as one.

### Delta to production

Package the River Safety Dashboard as a reusable plugin for other river municipalities — a small, defensible, genuinely useful niche with a natural distribution story through municipal networks.

---

## 12. Consulting Website

**Status:** Live · `sassyconsultingllc.com` · Cloudflare Workers · Stripe and GitHub webhooks
**Revenue model:** Lead generation — no direct revenue line

### Scope

The company web property: product portal, NDA request and management flow, contact handling, Stripe and GitHub webhook processing, coming-soon pages, and the browser status truth layer mirroring `docs/status/product-status.json`.

### Market need and operational gap

This is **infrastructure, not a product**, and it is modeled at zero direct revenue in Chapter 11. Its function is threefold: it is the origination channel for consulting and audit engagements; the NDA flow is the gate through which investor and client material is controlled; and the public status page is a **credibility mechanism**.

That last point deserves emphasis. Publishing a machine-readable product-status document that says *2 pass, 5 partial, 3 fail* is unusual and is a genuine differentiator in a market where solo-founder projects routinely overclaim. It is the reason a diligence process can trust the rest of the material. The website's real return is measured in reduced customer-acquisition cost and shortened diligence cycles, not in revenue.

### Delta to production

Content and SEO investment sufficient to make it an actual acquisition channel rather than a business card; case studies from Riverview and the audit practice; a self-serve path into the security-audit offering.

---

## 13. Security Audit Scripts

**Status:** Complete · PowerShell audit suite
**Revenue model:** Consulting services delivery

### Scope

A PowerShell suite for Windows and network security assessment, used in client engagements: configuration review, patch and hygiene assessment, permission and privilege auditing, and reporting. Four scripts shipping alongside WinForensics-Pro plus the standalone assessment suite.

### Market need and operational gap

The gap is **assessment access for organizations that cannot buy an audit**. A formal penetration test starts around $10,000 and runs well beyond it. A 30-person company with a compliance requirement, a cyber-insurance questionnaire, or a customer security review has a real and immediate need and no proportionate product. Cyber-insurance underwriting in particular has tightened materially, and organizations are increasingly required to demonstrate posture they have never measured.

The operational insight is that most of the value in a small-business security assessment comes from a **repeatable checklist executed competently**, not from novel research. That is automatable. The scripts do the mechanical work; the billable hour goes to interpretation and remediation planning, which is where the value actually is.

This is the **highest-margin-per-hour and lowest-capital-intensity line in the portfolio**, and it is the revenue that does not depend on any product launch. In the marginal scenario it is load-bearing.

### Delta to production

Productize into a fixed-scope, fixed-price assessment offering with a defined deliverable; align the report format to the frameworks buyers are actually asked about (CIS Controls, cyber-insurance questionnaires, SOC 2 readiness); build a partner path with regional MSPs and insurance brokers, who are the natural referral source.

---

# Tier 4 — Internal Enablement

## 14. SDR Radio Toolkit

**Status:** Operational · Rust and configuration · RTL-SDR, DSDPlus, HackRF
**Revenue model:** None direct — internal capability

### Scope

Software-defined radio tooling: a custom Rust scanner, DSDPlus P25 decoding integration, HackRF spectrum analysis, and documented setup for the Dane County radio system.

### Value and gap filled

No direct revenue and none modeled. Its return is **capability**: it is the RF layer of the Guard platform (project 3). Without it, Guard's P25 and spectrum monitoring do not exist, and that capability is a meaningful part of what distinguishes Guard from consumer security products. Valued as cost avoided — a Guard built on a purchased or outsourced RF stack would carry both license cost and an integration dependency.

Secondary return: it underwrites credibility in RF and radio consulting conversations, and the Dane County setup documentation is a genuine regional community contribution.

---

## 15. Wyze NVR Integration

**Status:** Active development · Python / Flask / Docker · Socket.IO
**Revenue model:** None direct — internal capability

### Scope

A Dockerized bridge exposing Wyze camera feeds to the Guard command center, with real-time transport over Socket.IO.

### Value and gap filled

Small, focused, and strategically disproportionate to its size. It is the reason Guard can offer video **without building or manufacturing cameras**. A prospective Guard customer who already owns Wyze hardware — an extremely large installed base at consumer price points — can adopt Guard without replacing anything. That materially lowers Guard's adoption barrier and is a real advantage over platforms that require proprietary hardware.

The gap it fills for the user is Wyze's own closed ecosystem: footage is accessible in Wyze's app on Wyze's terms. A local bridge returns control of the feed to the owner, which is the same sovereignty argument that runs through SassyTalkie and Sassy Browser.

**Portfolio risk note:** this depends on an undocumented or semi-documented third-party interface and can break without warning. It should be treated as a convenience integration with a documented failure mode, never as a load-bearing dependency of a paid Guard tier.

---

# Cross-Portfolio Analysis

## The unifying thesis

Fifteen projects across six domains is, on its face, unfocused. The defensible reading is that they express **one thesis applied consistently**: *the user, not the vendor, should hold the keys.*

| Project | Vendor-controlled default | What the portfolio returns to the user |
|---------|--------------------------|----------------------------------------|
| Sassy Browser | Ad-company-controlled rendering engine | An engine with no advertising interest |
| SassyTalkie | Vendor-hosted voice and metadata | Self-hostable relay, sealed sender, PQC |
| Guard | Cloud-only, single-domain sensors | Local correlation across all sensor domains |
| WinForensics-Pro | Enterprise-gated forensics | Practitioner-priced host analysis |
| SassyMCP | Cloud-bound agent platforms | Local-first, audited agent control |
| RACRUST / Riverview | Platform-dependent, patch-hungry CMS | Owned, edge-deployed, no plugin surface |
| Wyze NVR bridge | Vendor-gated camera footage | Owner-controlled local feed |

Every project takes a capability that has drifted into vendor control and returns it to the operator, without asking the operator to give up capability to get it. That is one company, not fifteen hobbies.

## Reinforcement map

The projects are not independent; several are load-bearing for others, and this compounds capital efficiency:

- **SassyMCP → all fourteen others.** It is the development substrate. Its productivity contribution is the mechanism by which a single founder maintains this surface area at all.
- **SDR Toolkit → Guard.** Supplies the entire RF and P25 layer.
- **Wyze NVR → Guard.** Supplies video without hardware manufacture.
- **NetGuard → Guard.** Overlapping scope; consolidation decision pending.
- **RACRUST → Riverview → client practice.** One engine, multiple client deliveries.
- **Security Audit Scripts → WinForensics-Pro.** Shared methodology; the service practice validates the product's workflow against real engagements.
- **Sassy Browser MCP surface → SassyMCP.** Bidirectional: the browser is an MCP target and a showcase for the protocol layer.

The practical consequence for diligence: **the marginal cost of the eleventh project is far below the cost of the first**, because the substrate, the deployment pattern (Cloudflare Workers + D1/R2/KV), the language choices, and the tooling are shared. This is what the capital-efficiency analysis in Chapter 11 quantifies.

## Concentration and risk

Honest statement of the portfolio's principal risks:

| Risk | Exposure | Mitigation posture |
|------|----------|-------------------|
| **Key-person** | Total. Every project has one developer. | The first hire is an engineer, not a salesperson. Documentation and open-sourcing SassyMCP reduce bus factor asymmetrically. |
| **Focus dilution** | High. Fifteen projects, one person. | Tiering is the mitigation: Tier 1 gets the engineering, Tier 3 funds it, Tier 4 is maintenance-only, and Tier 2 ships and then sits. |
| **Sassy Browser technical risk** | High and acknowledged. A browser engine is among the hardest software artifacts to complete; 240 audit findings are open. | Explicit, published, and driving the work plan. Chapter 11's marginal case assumes the browser does not reach broad SPA compatibility. |
| **Revenue concentration** | Currently ~100% client services. | The three-scenario model exists precisely to show what happens across the range of product-revenue outcomes. |
| **Third-party interface dependency** | Wyze bridge, scraping sources in Foodie Finder, DSDPlus. | Documented failure modes; never load-bearing for a paid tier. |
| **Distribution and trust** | Signed update channel is 404; no notarized macOS build. | Signing and distribution are a named line item in the use of funds. |

---

## Header conventions and footer definitions

**Status vocabulary** — used consistently across this chapter and Chapter 11:

| Term | Definition |
|------|------------|
| **Production** | Shipping to external users, signed where the platform requires it, supported |
| **Live** | Deployed and externally reachable; may not be signed or formally supported |
| **Operational** | Functioning and in daily internal use; not externally distributed |
| **Active development** | Under regular commit activity toward a defined next release |
| **Near-complete** | Feature-complete on the primary platform; secondary platforms or polish outstanding |
| **Complete** | Feature-complete against its own scope; no further development planned before release |
| **Beta** | Functionally usable, externally testable, not feature-frozen |
| **In progress** | Active but without a committed release target |
| **Paused** | Deliberately deprioritized; no current commit activity; resumption is an explicit decision |

**Scope vocabulary:**

| Term | Definition |
|------|------------|
| **Delivered scope** | Capability present in the tree today, verifiable by inspection |
| **Out of scope** | Deliberately excluded; not a roadmap omission |
| **Delta to production** | The specific, enumerable work between current state and the fully-realized state assumed by this document |
| **Fully realized** | The modeling assumption throughout: shipped, signed, distributed, supported, and scaled to its addressable segment |

**Market vocabulary:**

| Term | Definition |
|------|------------|
| **Operational gap** | A task a defined user must perform for which no adequate tool exists at their price or complexity point |
| **Market need** | Demonstrated willingness to pay, evidenced by an existing market or an existing substitute behavior |
| **Beachhead** | The narrowest segment where the product is unambiguously the best available option |
| **Displaced seat** | A paid license a user can stop buying — stated as *viewer* seats only, never authoring seats |

---

**Sassy Consulting LLC**
shane@sassyconsultingllc.com · sassyconsultingllc.com · Madison / Prairie du Sac, Wisconsin
Veteran-owned · Security-first · AI-augmented
Entity ID S162390 · EIN 39-3544154 · Formed August 1, 2025

*Confidential — Investor Materials. Companion document: Chapter 11, Portfolio Economics & ROI.*
