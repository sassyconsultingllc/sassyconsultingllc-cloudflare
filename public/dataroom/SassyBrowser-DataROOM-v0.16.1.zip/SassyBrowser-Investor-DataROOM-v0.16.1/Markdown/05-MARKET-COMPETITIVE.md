<!--
   Copyright (c) 2026 Shane Smith / Sassy Consulting LLC. All rights reserved.
   Proprietary source. This notice is Copyright Management Information (17 U.S.C. 1202); removal or alteration prohibited.
   CodeMark: SCLLC1-DataROOM-YJLLCAMLMDK4
-->
# Market & Competitive Landscape

**Sassy Browser v0.16.1 (source) | Updated 2026-11-16** (market narrative unchanged this refresh; no new market data. Version header synchronized to chapter 03. One competitive row changed — the extension/userscript line — and one must be struck from any deck: see the note on the bytecode VM below.)

---

> **Strike the JavaScript-performance line from any competitive material (new, 2026-10-05).** If a deck, datasheet or conversation has ever positioned Sassy Browser's JS execution against V8 on the strength of a bytecode VM with its own garbage collector, **that capability no longer exists** — it was deleted on 2026-10-05, 14,937 lines across 22 files, having never been DOM-wired. The defensible JS positioning is unchanged and was always the real one: **a memory-safe, pure-Rust, no-JIT engine with no Spectre/Meltdown class attack surface** — a *security* and *independence* argument, not a speed argument. Against Chromium on raw JS throughput, a tree-walking interpreter loses, and the binder should never have implied otherwise.
>
> **A competitive row changed in the product's favour, with a caveat (new, 2026-10-05).** Sassy Browser now ships a **userscript manager with a 15-API `GM_*` surface** and **extension content-script injection**, both wired. In the privacy-conscious and developer segments below, "customize pages without installing a third-party extension that can be silently compromised" is a genuine differentiator — Chrome and Brave both require an extension for this. **The caveat is procurement-relevant:** neither path has been reviewed by an auditor, neither has run in a packaged binary, and no Tampermonkey or Greasemonkey *compatibility* claim is defensible. The safe framing is *"a built-in userscript manager, no extension required"* — not *"runs your Tampermonkey scripts."*
>
> **Speech-to-text is not a competitive claim.** It exists in source behind an off-by-default feature, cannot be built without ~23 MB of unvendored upstream libraries per target, and has never been verified against real audio. **Keep it out of market material entirely until it ships.**

> **The spreadsheet displacement claim has code behind it (2026-09-14).** This chapter's thesis includes displacing per-seat subscription software, and the Microsoft 365 line of that argument had until recently rested on a viewer that could open `.xlsx` and evaluate roughly sixty hand-rolled functions — which is a file viewer, not a spreadsheet. The live calculation path is now `viewers/formula/`: **255 named functions** over a real lexer, parser, evaluator and typed value model, with 64 passing tests (re-confirmed 2026-10-05, and its call site gained 35 further tests this refresh). The competitive framing that changes is narrow but real: "opens your spreadsheets" becomes "recalculates your spreadsheets," which is the difference between a reader and a tool in the segments below.
>
> **The limits, stated with equal weight, because a procurement evaluator will find them within an hour.** 255 functions is not the roughly 500 of modern Excel. Structured (table) references and cross-sheet references are unverified. No round-trip against real-world workbooks has been performed. The engine ships in no packaged binary. **Do not put Excel parity in a deck, a datasheet, or a sales conversation** — the defensible claim is "a 255-function formula engine in the browser, no subscription, no upload," and that claim is strong enough on its own in the academic and SMB segments where the alternative is a paid seat for occasional recalculation.

> **Accessibility as a procurement lever (v0.14.0).** The Sassy Nova theme ships `SassyNovaContrast`, a **WCAG-AAA high-contrast chrome mode**. In the academic and enterprise segments described below, accessibility conformance is not a feature preference — it is a purchasing gate. US public institutions procure against Section 508 / WCAG 2.1 AA, and EU public bodies against EN 301 549. A browser that can demonstrate AAA-level chrome contrast clears a checkbox that competitors satisfy only through OS-level accommodations. This is not yet a claim of full conformance — no accessibility audit has been commissioned, and screen-reader and keyboard-navigation coverage are unmeasured — but the chrome architecture that makes conformance achievable (a `ChromeMode` switch that drops the bitmap art rather than fighting it) now exists. Commissioning a formal accessibility audit is a low-cost, high-leverage item for the institutional pathway in chapter 06.

## Market Size

### Total Addressable Market (TAM)
- 1.8 billion desktop browser users globally (StatCounter)
- Desktop software subscription market: $200B+/year
- Browser market revenue (search deals, enterprise licensing): ~$30B/year

### Serviceable Addressable Market (SAM)
- Privacy-conscious desktop users: ~50M globally
- Scientific/research software users: ~15M
- Developer tools users: ~25M
- Web3/crypto desktop users: ~10M

### Serviceable Obtainable Market (SOM) -- Year 1-2
- Privacy power users willing to switch browsers: ~500K
- Academic institutions seeking ChemDraw/PACS alternatives: ~50K seats
- Developer early adopters (Rust community, security researchers): ~100K

## Subscription Software Displaced

Sassy Browser's 200+ format viewer replaces paid software that costs users $15,000+/year in aggregate:

| Software | Annual Cost | Sassy Browser Replacement |
|----------|------------|--------------------------|
| Adobe Creative Cloud | $660/year | PhotoCraft engine: layered PSD/PSB edit/write, RAW processing, ImageJ analysis stack |
| Microsoft 365 | $100/year | DOCX/XLSX/PPTX viewing and basic editing |
| ChemDraw (PerkinElmer) | $2,500/year | SMILES/MOL/SDF/PDB molecular visualization |
| PACS Viewer (medical) | $5,000+/year | DICOM medical imaging viewer |
| AutoCAD LT | $1,800/year | DXF CAD file viewing |
| Postman | $144/year | Built-in REST API client |
| 1Password | $36/year | ChaCha20/Argon2id password vault |
| uBlock Origin (donation) | $0 | Native ad blocker (no extension risk) |

## Competitive Matrix

| Feature | Chrome | Firefox | Brave | Arc | Sassy Browser |
|---------|--------|---------|-------|-----|---------------|
| Engine | Blink (C++) | Gecko (C++) | Blink (C++) | Blink (C++) | Custom (Rust) |
| Memory safety | No | No | No | No | Yes (Rust) |
| Google telemetry | Yes | No | No | No | No |
| JIT attack surface | Yes | Yes | Yes | Yes | No |
| Native ad blocker | No | No | Yes | No | Yes |
| File viewers (200+) | No | No | No | No | Yes |
| Password vault | Yes (Google) | Yes (Mozilla) | No | No | Yes (local, ChaCha20) |
| Fingerprint poisoning | No | Partial | Partial | No | Yes (canvas/WebGL/audio/fonts) |
| TLS fingerprint control | No | No | No | No | Yes (Chrome-132 JA3) |
| MCP server (AI target) | No | No | No | No | Yes |
| Family profiles | No | No | No | No | Yes |
| Web3 education | No | No | Partial | No | Yes |
| Scientific viewers | No | No | No | No | Yes (DICOM, PDB, SMILES) |

### Emerging Competitors

| Project | Language | Status | Key Difference from Sassy |
|---------|----------|--------|--------------------------|
| Ladybird (SerenityOS) | C++ | Pre-alpha | C++ (not memory-safe), no file viewers |
| Servo (Linux Foundation) | Rust | Research | Rendering engine only, not a full browser |
| Nickel Browser | -- | Concept | Vaporware |

Sassy Browser is the only pure-Rust browser that ships as a complete desktop application with file viewing, security tooling, and MCP integration.

### The AI Browser Wave

A second competitive front opened in 2025-2026 that the matrix above does not
capture, because it does not compete on the engine at all. Perplexity's Comet,
OpenAI's browser efforts, and most recently **Polar** (founded by a former
Perplexity Comet engineer; $5.7M seed led by Madrona, July 2026) all ship
**Chromium** and differentiate purely on an embedded AI agent. Polar's pitch is
agentic knowledge work: it drives the sites you are already logged into --
clicking, typing, filling forms, updating spreadsheets -- and runs multi-step
tasks unattended for minutes to hours. It reports 4.5M actions run in its first
seven months.

This is a genuinely different product category, and it is important not to
mistake it for ours.

| Dimension | Polar (and the AI-browser wave) | Sassy Browser |
|-----------|--------------------------------|---------------|
| Engine | Chromium / Blink / V8 | Custom pure-Rust |
| Memory safety | No (C++ engine) | Yes |
| JIT attack surface | Yes (V8) | None -- SassyScript has no JIT |
| Differentiator | Embedded agent that operates the web for you | Engine independence + local data sovereignty |
| AI posture | Ships **one vendor's** agent, inside the browser | Ships an **MCP server** -- any agent can drive it |
| Local file handling | None | 200+ format viewers, native file browser |
| Works offline | No (agent requires cloud inference) | Yes -- viewers, vault, file browser are all local |
| Credential exposure | Agent acts inside your logged-in sessions | No agent touches your sessions |
| Site compatibility | Complete (it *is* Chrome) | Partial -- our real gap |
| Funding / team | $5.7M seed, funded team | Solo, unfunded |

**What Polar does that we do not.** Two things, honestly:

1. **Autonomous multi-step web automation.** We expose an MCP server so an
   external agent *can* drive the browser, but we ship no task-planning loop,
   no scheduled recurring workflows, and no saved-prompt library. Polar does.
2. **Site compatibility.** Polar inherits Chromium's rendering, so every site
   works. Our custom engine does not, and no amount of positioning changes
   that. This remains our single largest product risk.

**What we do that Polar structurally cannot.** Polar's advantages are
downstream of shipping Chromium, and so are its limits:

1. **It cannot claim engine independence.** Polar is a skin plus an agent on
   Google's engine, on Google's release cadence, with V8's JIT attack surface.
   The "novel browser" framing is about the agent, not the browser.
2. **It cannot be the local-data tool.** Polar has no file viewers. A user with
   a DICOM study, a STEP model, a PDB structure, or a 200MB spreadsheet is not
   a Polar user. That is the whole of our file-browser surface.
3. **Its trust model is the inverse of ours.** Polar's value *requires* an agent
   operating inside your authenticated sessions, which is precisely the posture
   our security chapter is built to refuse. For regulated, air-gapped, or
   privacy-motivated buyers, Polar's core feature is a disqualifier.
4. **Agent-agnostic beats agent-embedded.** Being an MCP *target* rather than
   an agent *vendor* means Sassy works with whatever model the customer already
   pays for. Polar bets the product on its own agent being the best one.

**Positioning conclusion.** Do not compete with Polar on agentic automation --
that is a funded race on commodity infrastructure. Compete where the Chromium
wave structurally cannot follow: **the engine-independent, local-first
workstation browser that opens anything on disk and never phones home.** The
file browser is the beachhead, not the web engine.

## Beachhead Strategy

### Phase 1: Academic & Research (Months 1-6)
- Target: University chemistry/biology departments, medical imaging labs
- Wedge: Free DICOM viewer ($5K/year PACS replacement), free PDB viewer ($2.5K/year ChemDraw alternative)
- Distribution: Direct outreach to department heads, conference demos
- Revenue: Institutional site licenses ($10-50/seat/year)

### Phase 2: Developer & Security (Months 6-12)
- Target: Rust developers, security researchers, penetration testers
- Wedge: MCP integration (AI-drivable browser), fingerprint poisoning, devtools
- Distribution: Hacker News, Rust community, security conferences
- Revenue: Pro tier subscriptions ($4.99/month)

### Phase 3: Privacy Consumer (Months 12-18)
- Target: Users leaving Chrome after MV3 (uBlock Origin degradation)
- Wedge: Native ad blocking, zero telemetry, password vault
- Distribution: Product Hunt, tech press, word of mouth
- Revenue: Freemium with Pro tier
